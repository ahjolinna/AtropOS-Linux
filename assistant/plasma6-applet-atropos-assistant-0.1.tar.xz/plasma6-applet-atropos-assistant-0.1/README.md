# Assistant

Chat with **Inkling 2 Mini**, Thinking Machines Lab's open-weight model,
running on this computer. Nothing you type leaves the machine. It comes
in three places:

- **A widget** on a panel or in the system tray. Click it, ask, and
  the answer streams in.
- **The Assistant window**, in the application menu, or **Open in
  Window** from the widget. The same chats, with the chat list beside them.
- **KRunner.** Type `ai` and a question. Enter answers in a
  notification with **Copy** and **Continue in Assistant**. Asked again,
  the answer shows right in KRunner.

## What it does

- Answers stream in as Markdown. Code blocks have their own copy button.
- The model's thinking shows as it happens and folds away when the
  answer starts. **Thinking** under the input sets how long it thinks,
  from Minimal to Maximum.
- Drop images or text files on it, or attach them. Images need the
  image encoder; text files go in front of the question.
- **This computer.** The model can look things up here: OS, kernel,
  CPU, GPU, memory, disks, uptime, Plasma versions, a package's version,
  failed services, recent errors, snapshots, network, busiest processes.
  These lookups only read and run at once. For anything else it can
  propose a shell command, which runs only after you press **Run**, as
  you and not as root, from your home folder, for at most a minute.
  Each question allows up to four rounds of this. Settings can turn it off.
- **Web search** (off until you turn it on with **Web** under the chat).
  Your question goes to DuckDuckGo first and the top 3 to 5 results
  (title, link, snippet) go to the model, which cites them as [1], [2].
  DuckDuckGo shows its plain results page to programs only now and then;
  when it asks for a robot check, the Assistant uses DuckDuckGo's
  official Instant Answer API instead (encyclopedia answers, not web
  results) and leaves the results page alone for ten minutes.
- Every chat is saved. The chat list groups them by Favorites, Today,
  the last 7 and 30 days, and Older, and searches all of them (Ctrl+F).
  Chats can be renamed, starred, duplicated, deleted, and exported to
  Markdown, text or JSON. JSON imports again.
- **Fork Chat Here** on an answer starts a new chat up to that point.
  **Edit** (or Up in an empty field) takes your last question back.
- A notification says when a long answer finishes while the popup is
  closed. Ctrl+N starts a new chat.
- The model starts when you send the first message, and its menu has
  **Stop Model and Free Memory**. An idle model unloads itself after
  30 minutes and loads again with the next message.

## Install

On AtropOS, install `plasma6-applet-atropos-assistant` with
`transactional-update pkg install` and reboot. Without the RPM, install
it for your user only:

```sh
./install.sh             # everything under ~/.local and ~/.config
./install.sh --uninstall
```

Then right-click the panel, choose **Add or Manage Widgets**, and add
**Assistant**. For the system tray instead, open the tray's settings,
**Entries**, and set **Assistant** to shown. In the tray its icon stays
in the overflow while the model is stopped and comes forward while it
runs, unless the tray settings say **Always shown**. After an upgrade, `systemctl --user restart
plasma-plasmashell` and `kquitapp6 krunner` load the new version.

## Download the model

The widget's first page downloads it. Pick a setup, and it shows
progress, speed and time left, and starts the model when it is done
(untick that to start it yourself). A download carries on with the
widget closed, and an interrupted one continues where it stopped.

| Setup | Size | File | Needs about |
|---|---|---|---|
| **Light** (default) | 7.8 GB | UD-IQ1_S | 9 GB of memory |
| Balanced | 11.7 GB | UD-IQ3_XXS | 13 GB |
| Quality | 17.6 GB | UD-Q4_K_XL, Unsloth's recommendation | 18 GB |
| Best | 22.9 GB | UD-Q8_K_XL | 24 GB |

**Other size** lists all ten of Unsloth's sizes. Memory means RAM and
graphics memory together; each setup says whether this computer has it.
Light runs on the most computers and is the default; the bigger ones
answer better. **Model Size…** in the widget's menu switches later: the
new size replaces the old one, and a running model restarts on it.

The same works in a terminal: `atropos-assistant-setup` (see `--help`)
downloads Light unless `--quant` names another size. It downloads
llama.cpp (build b12613, Vulkan) and Unsloth's `Inkling-2-Mini-GGUF`
into `~/.local/share/atropos-assistant`, checks both against their
published SHA-256 sums, and writes
`~/.config/atropos-assistant/server.conf`.

Mainline llama.cpp needs
[PR #32704](https://github.com/ggml-org/llama.cpp/pull/32704) for
Inkling 2 Mini, and b12613 has it. Builds without it load the model
and print gibberish.

## The model server

`atropos-assistant.service` is a systemd user service. It runs
`atropos-assistant-server`, which starts `llama-server` on
`127.0.0.1:18080` with Thinking Machines' sampling (temperature 1.0, no
top-p, top-k or min-p cut-off), a 32k context, and `--fit on` so
llama.cpp keeps what fits on the GPU and the MoE experts in RAM.

Two settings keep it inside a small GPU:

- `--no-op-offload`. With the experts in RAM, llama.cpp otherwise
  stages them on the GPU for prompt processing, a 7 GiB buffer for this
  model.
- An automatic `--ubatch-size`. llama.cpp has no flash-attention path
  for Inkling's attention, so the score matrices grow with the
  micro-batch and the context. The script picks the largest power of two
  that fits in a third of the free GPU memory: 64 on an 8 GB card with
  the desktop running.

```sh
systemctl --user start atropos-assistant
journalctl --user -u atropos-assistant -f
```

`server.conf` can set `PORT`, `CTX_SIZE`, `UBATCH`, `CACHE_RAM_MIB`,
`SLEEP_IDLE_SECONDS` (-1 keeps the model loaded) and `EXTRA_ARGS=(...)`
for any other llama-server option. llama-server's own web chat is at
http://127.0.0.1:18080 while it runs.

On a Ryzen 7 5700G with an RTX 3060 Ti (8 GB), UD-Q4_K_XL loads in
about 16 seconds and writes about 5.5 tokens a second.

## The Assistant service

`atropos-assistant-service` owns `org.atropos.Assistant` on the session
bus. D-Bus activation starts it and it exits after 15 idle minutes. It
does what QML cannot: the download, starting and stopping the model
server, the saved chats, reading attached text files, opening the
Assistant window, the KRunner runner, web searches, and the model's
lookups and approved commands. Chats are JSON files in
`~/.local/share/atropos-assistant/chats`, readable only by you.

The widget, the window and KRunner share their settings through
`~/.config/atropos-assistant/assistant.json`; change them in any of the
widget's settings.

## Another server

The settings start at **Inkling 2 Mini on this computer**. **Another
server** points the widget, the window and KRunner at any
OpenAI-compatible chat server instead: llama-server, LM Studio or vLLM,
on this computer or another one. The thinking level goes there as
`reasoning_effort`.

There is no Ollama setting. Ollama has `inkling-2-mini` from 0.40.17,
but that release runs it on Apple silicon only, so it cannot run the
model on an AtropOS desktop.

## Tests

```sh
tests/run-tests.sh          # the D-Bus service, then the chat logic, against a mock server
tests/run-tests.sh --lint   # plus qmllint against the Plasma QML modules
tests/visual-check.sh DIR   # screenshots of the window, offscreen, with the running model
```

`run-tests.sh` runs in a Tumbleweed container with podman: AtropOS has
no `qml` tool or `dbus-run-session`, and the tests must not touch the
running session. The service tests use fake `systemctl`, `journalctl`
and `plasmawindowed`.

## Layout

| Path | What it is |
|---|---|
| `package/` | the widget (`org.atropos.assistant`); the window is the same widget in `plasmawindowed` |
| `package/contents/ui/ChatSession.qml` | one conversation and its HTTP traffic, no Plasma imports |
| `package/contents/ui/AssistantService.qml` | the D-Bus calls |
| `package/contents/code/protocol.js` | request building, stream parsing, Markdown splitting |
| `server/` | the setup, server and D-Bus service scripts, and their units |
| `desktop/` | the menu entry, the KRunner plugin, the notification events |
| `tests/` | mock server, service tests, headless QML tests, visual check |

## License

GPL-2.0-or-later. Inkling 2 Mini itself is Apache-2.0 and is not part
of this package.
