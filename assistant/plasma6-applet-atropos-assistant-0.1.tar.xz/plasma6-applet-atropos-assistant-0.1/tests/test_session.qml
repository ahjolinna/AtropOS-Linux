// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later
//
// Drives ChatSession and ImageEncoder against mock_server.py.
// run-tests.sh starts the mock and runs this with qml, offscreen.
// Needs QML_XHR_ALLOW_FILE_READ=1 to read the logged requests.

import QtQuick

import "../package/contents/ui" as UI
import "../package/contents/code/protocol.js" as Protocol

Item {
    id: t
    width: 400
    height: 400

    readonly property string base: "http://127.0.0.1:18999"
    readonly property string logDir: "file:///tmp/assistant-test-log"
    property int failures: 0
    property int checks: 0
    property int step: -1
    property int requests: 0
    property int finished: 0

    function check(ok, what) {
        checks++;
        if (!ok) {
            failures++;
            console.log("FAIL:", what);
        } else {
            console.log("ok:", what);
        }
    }

    function readRequest(n) {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", logDir + "/request-" + n + ".json", false);
        xhr.send();
        return JSON.parse(xhr.responseText);
    }

    function last() {
        return session.messages.get(session.messages.count - 1);
    }

    // Poll cond every 20 ms; call then() when true, or fail after timeout.
    function waitFor(what, cond, then, timeout) {
        poller.what = what;
        poller.cond = cond;
        poller.then = then;
        poller.deadline = Date.now() + (timeout || 5000);
        poller.start();
    }

    Timer {
        id: poller
        interval: 20
        repeat: true
        property string what
        property var cond
        property var then
        property double deadline
        onTriggered: {
            if (cond()) {
                stop();
                then();
            } else if (Date.now() > deadline) {
                stop();
                t.check(false, "timed out waiting for " + what);
                t.next();
            }
        }
    }

    UI.ChatSession {
        id: session
        serverUrl: t.base
        systemPrompt: "Be brief."
        reasoningEffort: "low"
        onTurnFinished: t.finished++
    }

    UI.ImageEncoder {
        id: encoder
        property string result: ""
        property bool didFail: false
        onEncoded: (source, url) => result = url
        onFailed: source => didFail = true
    }

    Image {
        id: decoded
        visible: false
    }

    function next() {
        step++;
        if (step >= steps.length) {
            console.log(checks + " checks, " + failures + " failures");
            Qt.exit(failures === 0 ? 0 : 1);
            return;
        }
        console.log("--", steps[step].name);
        Qt.callLater(steps[step]);
    }

    readonly property var steps: [
        function protocolUnits() {
            check(Protocol.prettyModel("inkling-2-mini") === "Inkling 2 Mini", "prettyModel maps the alias");
            check(Protocol.prettyModel("Inkling-2-Mini-UD-Q4_K_XL.gguf") === "Inkling 2 Mini", "prettyModel maps a file name");
            check(Protocol.chatUrl("http://x:1/") === "http://x:1/v1/chat/completions", "chat URL drops the trailing slash");
            const p = new Protocol.StreamParser();
            p.feed('data: {"choices":[{"delta":{"content":"a"}}]}\n\ndata: {"choices":[{"delta":{"con');
            check(p.content === "a", "parser waits for a complete line");
            p.feed('data: {"choices":[{"delta":{"content":"a"}}]}\n\ndata: {"choices":[{"delta":{"content":"b"}}]}\n');
            check(p.content === "ab", "parser resumes at its offset");
            p.feed('data: {"choices":[{"delta":{"content":"a"}}]}\n\ndata: {"choices":[{"delta":{"content":"b"}}]}\n: keepalive\ndata: {"error":{"message":"boom"}}\n');
            check(p.error === "boom", "parser reports an in-stream error");
            check(Protocol.errorFromBody(500, '{"error":"x"}') === "x" && Protocol.errorFromBody(502, "") === "HTTP 502", "errorFromBody");

            let s = Protocol.splitMarkdown("Intro **b**\n\n```sh\necho hi\n```\nAfter");
            check(s.length === 3 && !s[0].code && s[1].code && s[1].lang === "sh" && s[1].text === "echo hi" && s[2].text === "After",
                  "splitMarkdown separates prose and code");
            s = Protocol.splitMarkdown("Text\n```py\nprint(1)\nprint(2");
            check(s.length === 2 && s[1].code && s[1].text === "print(1)\nprint(2", "an unclosed fence is code while streaming");
            s = Protocol.splitMarkdown("````md\n```\ninner\n```\n````");
            check(s.length === 1 && s[0].code && s[0].text === "```\ninner\n```", "a longer fence holds a shorter one");
            check(Protocol.splitMarkdown("").length === 0 && Protocol.splitMarkdown("plain").length === 1, "empty and plain");
            check(Protocol.withFiles("Q", [{ name: "a.txt", text: "x\n" }]) === "File: a.txt\n```\nx\n```\n\nQ", "files go before the question");
            check(Protocol.withFiles("", [{ name: "b.md", text: "```code```" }]).indexOf("~~~~") > 0, "a file with fences gets a tilde fence");
            check(Protocol.withSources("Q", [{ title: "T", url: "https://a/", snippet: "S" }])
                  === "Web search results from DuckDuckGo:\n[1] T (https://a/)\nS\n\nUse these results where they help and cite them as [1], [2] and so on.\n\nQ",
                  "search results go before the question");
            check(Protocol.withSources("Q", []) === "Q", "no results, no preamble");
            const tp = new Protocol.StreamParser();
            tp.feed('data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"a","function":{"name":"system_info","arguments":"{\\"to"}}]}}]}\n'
                  + 'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"pic\\":\\"os\\"}"}}]},"finish_reason":"tool_calls"}]}\n');
            check(tp.toolCalls.length === 1 && tp.toolCalls[0].arguments === '{"topic":"os"}' && tp.finishReason === "tool_calls",
                  "parser joins tool call pieces");
            const tb = Protocol.buildRequest({ tools: [{ type: "function" }] }, [
                { role: "user", content: "q" },
                { role: "assistant", content: "", toolCalls: [{ id: "a", name: "system_info", arguments: '{"topic":"os"}' }] },
                { role: "tool", toolCallId: "a", name: "system_info", content: "NAME=AtropOS" },
            ]);
            check(tb.tools.length === 1 && tb.messages[1].tool_calls[0].function.name === "system_info"
                  && tb.messages[2].tool_call_id === "a" && tb.messages[2].content === "NAME=AtropOS", "tool history in OpenAI form");
            next();
        },

        function status() {
            session.checkServer();
            waitFor("ready", () => session.serverState === "ready", () => {
                check(session.serverModel === "inkling-2-mini", "server model is the alias");
                check(session.modelName === "Inkling 2 Mini", "model name is pretty");
                next();
            });
        },

        function streamAnswer() {
            const before = finished;
            check(session.send("Hello"), "send accepted");
            check(session.busy && session.generating, "busy while streaming");
            requests++;
            waitFor("answer", () => finished > before, () => {
                check(session.messages.count === 2, "user and assistant entries");
                const a = last();
                check(a.role === "assistant" && !a.streaming, "assistant entry done");
                check(a.content.indexOf("**bold**") > 0 && a.content.indexOf("echo hi") > 0, "content streamed in full");
                check(a.thinking === "The user says hello. Answer briefly.", "thinking streamed in full");
                check(a.tokens === 42 && Math.abs(a.tokensPerSecond - 20.5) < 0.01, "timings read");
                check(a.finishReason === "stop", "finish reason");
                check(a.thinkSeconds >= 0, "thinking time measured");
                check(!session.busy, "idle afterwards");
                const r = readRequest(requests).body;
                check(r.stream === true && r.reasoning_effort === "low", "request streams with effort low");
                check(r.chat_template_kwargs.reasoning_effort === "low", "template kwargs carry the effort");
                check(r.model === undefined, "no model name sent to llama-server");
                check(r.messages[0].role === "system" && r.messages[0].content.indexOf("Today is") > 0, "system prompt has the date");
                check(r.messages[1].role === "user" && r.messages[1].content === "Hello", "user message sent");
                next();
            });
        },

        function secondTurnHistory() {
            const before = finished;
            session.send("And again");
            requests++;
            waitFor("second answer", () => finished > before, () => {
                const r = readRequest(requests).body;
                check(r.messages.length === 4, "system, user, assistant, user");
                check(r.messages[2].role === "assistant" && r.messages[2].reasoning_content === undefined, "earlier thinking not sent back");
                next();
            });
        },

        function regenerate() {
            const before = finished;
            const count = session.messages.count;
            session.regenerate();
            requests++;
            waitFor("regenerated", () => finished > before, () => {
                check(session.messages.count === count, "regenerate replaces the last answer");
                check(readRequest(requests).body.messages.length === 4, "regenerate resends the same history");
                next();
            });
        },

        function filesAndEdit() {
            session.clear();
            const before = finished;
            session.send("Summarize", [], [{ name: "notes.txt", text: "line one\nline two" }]);
            requests++;
            waitFor("file answer", () => finished > before, () => {
                const m = readRequest(requests).body.messages[1];
                check(m.content === "File: notes.txt\n```\nline one\nline two\n```\n\nSummarize", "file text sent before the question");
                check(JSON.parse(session.messages.get(0).files)[0].name === "notes.txt", "file kept on the entry");
                const taken = session.editFrom(0);
                check(taken && taken.text === "Summarize" && taken.files[0].text === "line one\nline two", "edit returns the question and its files");
                check(session.messages.count === 0, "edit removes the question and its answer");
                check(session.editFrom(0) === null, "nothing left to edit");
                next();
            });
        },

        function chatRoundTrip() {
            session.clear();
            const before = finished;
            session.send("Hello", ["data:image/png;base64,AAAA"]);
            requests++;
            waitFor("answer to save", () => finished > before, () => {
                session.title = "Greeting";
                session.favorite = true;
                const chat = session.toChat();
                check(chat.id === undefined && chat.title === "Greeting" && chat.favorite, "toChat without an id before saving");
                check(chat.messages.length === 2 && chat.messages[0].images[0] === "data:image/png;base64,AAAA", "images stay as an array");
                check(chat.messages[1].thinking.length > 0 && chat.messages[1].tokens === 42, "answer details kept");
                chat.id = "abc123";
                session.clear();
                check(session.chatId === "" && session.title === "" && session.messages.count === 0, "clear starts a new chat");
                session.loadChat(chat);
                check(session.chatId === "abc123" && session.title === "Greeting" && session.favorite, "loadChat sets the chat");
                check(session.messages.count === 2 && session.messages.get(0).imageCount === 1, "loadChat restores entries");
                check(session.messages.get(1).thinkSeconds >= 0 && session.messages.get(1).finishReason === "stop", "loadChat restores answer details");
                check(session.lastTurnDuration > 0, "turn duration measured");
                next();
            });
        },

        function webSearch() {
            session.clear();
            session.searchCount = 3;
            let asked = null;
            session.searchProvider = function (query, count, onResults, onError) {
                asked = { query: query, count: count };
                Qt.callLater(() => onResults([
                    { title: "T1", url: "https://a.example/1", snippet: "S1" },
                    { title: "T2", url: "https://a.example/2", snippet: "S2" },
                    { title: "T3", url: "https://a.example/3", snippet: "S3" },
                ].slice(0, count)));
            };
            const before = finished;
            session.send("what is new in Plasma?");
            check(session.searching && session.busy, "searching first, and busy");
            check(asked && asked.query === "what is new in Plasma?" && asked.count === 3, "the question is the query");
            requests++;
            waitFor("answer with results", () => finished > before, () => {
                const content = readRequest(requests).body.messages[1].content;
                check(content.indexOf("Web search results from DuckDuckGo:\n[1] T1 (https://a.example/1)\nS1\n[2] T2") === 0,
                      "results numbered in front");
                check(content.endsWith("\n\nwhat is new in Plasma?"), "the question last");
                check(JSON.parse(session.messages.get(0).sources).length === 3, "results kept on the question");
                check(session.toChat().messages[0].sources[2].url === "https://a.example/3", "results saved with the chat");
                next();
            });
        },

        function webSearchFails() {
            session.clear();
            session.searchProvider = function (query, count, onResults, onError) {
                Qt.callLater(() => onError("network down"));
            };
            const before = finished;
            session.send("still answer me");
            requests++;
            waitFor("answer without results", () => finished > before, () => {
                check(readRequest(requests).body.messages[1].content === "still answer me", "asked without results");
                check(session.messages.get(0).searchNote === "network down", "the failure is noted");
                next();
            });
        },

        function webSearchStopped() {
            session.clear();
            session.searchProvider = function () {};   // never answers
            const before = finished;
            session.send("never mind");
            check(session.searching, "waiting on the search");
            session.stop();
            check(!session.busy && finished === before + 1, "stop ends the search");
            check(session.messages.count === 1 && session.messages.get(0).role === "user", "no answer started");
            session.searchCount = 0;
            session.searchProvider = null;
            next();
        },

        function toolsApproved() {
            session.clear();
            const ran = [];
            const approvals = [];
            session.approvalNeeded.connect(i => approvals.push(i));
            session.toolDefinitions = [
                { type: "function", function: { name: "system_info" } },
                { type: "function", function: { name: "run_command" } },
            ];
            session.toolRunner = function (name, args, done) {
                ran.push({ name: name, args: args });
                Qt.callLater(() => done("OUT:" + name));
            };
            session.approvalTools = ["run_command"];
            session.maxToolRounds = 1;
            session.send("use tools please");
            requests++;
            const first = requests;
            const runIndex = () => {
                for (let i = 0; i < session.messages.count; ++i) {
                    if (session.messages.get(i).toolName === "run_command") {
                        return i;
                    }
                }
                return -1;
            };
            waitFor("a command waiting", () => runIndex() >= 0 && session.messages.get(runIndex() - 1).toolState === "done", () => {
                check(readRequest(first).body.tools.length === 2, "tools offered");
                const calls = JSON.parse(session.messages.get(1).toolCalls);
                check(calls.length === 2 && calls[0].id === "call_1" && calls[0].arguments === '{"topic":"memory"}',
                      "streamed tool call pieces put together");
                check(ran.length === 1 && ran[0].name === "system_info" && ran[0].args.topic === "memory", "the lookup ran by itself");
                check(session.messages.get(runIndex() - 1).content === "OUT:system_info", "lookup output kept");
                check(session.messages.get(runIndex()).toolState === "approval" && approvals.length === 1 && session.busy,
                      "the command waits for approval");
                session.approveTool(runIndex());
                requests++;
                waitFor("the answer after the tools", () => !session.busy && session.messages.get(session.messages.count - 1).role === "assistant", () => {
                    check(ran.length === 2 && ran[1].args.command === "echo hi", "the approved command ran");
                    const body = readRequest(requests).body;
                    const m = body.messages;
                    check(m[2].role === "assistant" && m[2].tool_calls[0].function.arguments === '{"topic":"memory"}', "tool calls sent back");
                    check(m[3].role === "tool" && m[3].tool_call_id === "call_1" && m[3].content === "OUT:system_info", "lookup result sent back");
                    check(m[4].role === "tool" && m[4].tool_call_id === "call_2" && m[4].name === "run_command", "command result sent back");
                    check(body.tools === undefined, "no tools after the last allowed round");
                    check(session.messages.get(session.messages.count - 1).content.indexOf("Hello!") === 0, "then it answers");
                    const chat = session.toChat();
                    check(chat.messages[2].toolName === "system_info" && chat.messages[2].toolArgs.topic === "memory", "tool steps saved");
                    chat.messages[3].toolState = "approval";
                    session.loadChat(chat);
                    check(session.messages.get(3).toolState === "denied" && session.messages.get(3).content === "Not run.",
                          "a saved step that never ran stays unrun");
                    next();
                }, 8000);
            });
        },

        function toolsDenied() {
            session.clear();
            session.maxToolRounds = 4;
            session.send("use tools again");
            requests++;
            const runIndex = () => session.messages.count > 3 && session.messages.get(3).toolState === "approval" ? 3 : -1;
            waitFor("a command waiting", () => runIndex() === 3, () => {
                session.denyTool(3);
                requests++;
                waitFor("the answer", () => !session.busy, () => {
                    const body = readRequest(requests).body;
                    check(body.messages[4].content === "The user chose not to run this command.", "the refusal goes back to the model");
                    check(body.tools.length === 2, "tools still offered within the round limit");
                    next();
                });
            });
        },

        function toolsStopped() {
            session.clear();
            session.send("use tools stop");
            requests++;
            waitFor("a command waiting", () => session.messages.count > 3 && session.messages.get(3).toolState === "approval", () => {
                const before = finished;
                session.stop();
                check(!session.busy && finished === before + 1, "stop ends the wait");
                check(session.messages.get(3).toolState === "denied" && session.messages.get(3).content === "Stopped before it ran.",
                      "the command is marked as not run");
                session.toolDefinitions = [];
                session.toolRunner = null;
                session.approvalTools = [];
                next();
            });
        },

        function serverError() {
            const before = finished;
            session.send("please error");
            requests++;
            waitFor("error", () => finished > before, () => {
                const e = last();
                check(e.role === "error" && e.kind === "server", "error entry of kind server");
                check(e.content === "mock refused", "server message kept");
                check(session.messages.get(session.messages.count - 2).role === "user", "no empty assistant entry left");
                next();
            });
        },

        function stopMidway() {
            session.clear();
            const before = finished;
            session.send("slow please");
            requests++;
            waitFor("first content", () => session.messages.count === 2 && last().content.length > 0, () => {
                session.stop();
                check(!session.busy, "stop ends the turn at once");
                const a = last();
                check(a.role === "assistant" && a.finishReason === "stopped", "partial answer marked stopped");
                check(a.content.length > 0 && a.content.length < 200, "partial content kept");
                check(finished > before, "turnFinished emitted");
                next();
            }, 8000);
        },

        function images() {
            session.clear();
            const before = finished;
            const url = "data:image/png;base64,iVBORw0KGgo=";
            session.send("What is this?", [url]);
            requests++;
            waitFor("image answer", () => finished > before, () => {
                const m = readRequest(requests).body.messages[1];
                check(Array.isArray(m.content) && m.content[0].type === "image_url" && m.content[0].image_url.url === url, "image sent as image_url part");
                check(m.content[1].type === "text" && m.content[1].text === "What is this?", "text part after the image");
                check(session.messages.get(0).imageCount === 1, "image count stored");
                next();
            });
        },

        function history() {
            const json = session.exportHistory();
            const saved = JSON.parse(json);
            check(saved.length === 2 && saved[0].imageCount === 1 && saved[0].images === undefined, "export drops image data");
            session.clear();
            session.importHistory(json);
            check(session.messages.count === 2 && session.messages.get(1).content.indexOf("Hello!") === 0, "import restores entries");
            check(session.messages.get(0).images === "[]" && session.messages.get(0).imageCount === 1, "imported user entry keeps the count only");
            session.importHistory("not json");
            check(session.messages.count === 2, "bad JSON is ignored");
            next();
        },

        function queueUntilReady() {
            session.clear();
            const before = finished;
            session.queueUntilReady = true;
            session.serverState = "offline";
            session.send("queued");
            check(session.busy && !session.generating, "queued, not sent");
            check(session.messages.count === 1, "user entry shown while queued");
            session.serverState = "ready";
            session.queueUntilReady = false;
            requests++;
            waitFor("queued answer", () => finished > before, () => {
                check(last().role === "assistant" && last().content.length > 0, "queued message answered once ready");
                next();
            });
        },

        function failQueued() {
            session.clear();
            session.queueUntilReady = true;
            session.serverState = "offline";
            session.send("never");
            session.failQueued("start", "unit failed");
            check(!session.busy && last().role === "error" && last().kind === "start" && last().content === "unit failed", "failQueued leaves an error");
            session.queueUntilReady = false;
            next();
        },

        function unreachable() {
            session.clear();
            session.serverUrl = "http://127.0.0.1:18998";
            const before = finished;
            session.send("anyone?");
            waitFor("unreachable", () => finished > before, () => {
                check(last().role === "error" && last().kind === "unreachable", "unreachable error");
                waitFor("offline", () => session.serverState === "offline", () => {
                    check(true, "status goes offline");
                    next();
                });
            });
        },

        function encodeImage() {
            encoder.add("file:///tmp/assistant-test-log/wide.png");
            waitFor("encoded", () => encoder.result !== "" || encoder.didFail, () => {
                check(!encoder.didFail, "encoder did not fail");
                check(encoder.result.indexOf("data:image/png;base64,") === 0, "PNG stays PNG");
                decoded.source = encoder.result;
                waitFor("decoded", () => decoded.status === Image.Ready || decoded.status === Image.Error, () => {
                    check(decoded.implicitWidth === 1536 && decoded.implicitHeight === 768,
                          "scaled to 1536 wide, got " + decoded.implicitWidth + "x" + decoded.implicitHeight);
                    next();
                });
            });
        },

        function encodeMissing() {
            encoder.result = "";
            encoder.didFail = false;
            encoder.add("file:///tmp/assistant-test-log/missing.png");
            waitFor("failure", () => encoder.result !== "" || encoder.didFail, () => {
                check(encoder.didFail && !encoder.working, "missing file fails cleanly");
                next();
            });
        },
    ]

    Component.onCompleted: next()
}
