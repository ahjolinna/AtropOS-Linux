#!/bin/bash
# SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
# SPDX-License-Identifier: GPL-2.0-or-later
#
# Screenshots of the Assistant window, rendered offscreen so nothing shows
# on the desktop. A copy of the widget under another id gets a small driver
# that asks the running model a question and grabs the window as it goes.
# Needs the installed service and a running model server.
#
#   tests/visual-check.sh OUTDIR "question" [web]
#
# With "web", the window searches DuckDuckGo first (3 results).

set -euo pipefail

src=$(cd "$(dirname "$0")/.." && pwd)
out=$(realpath "${1:?output directory}")
question=${2:-Write a one-line bash command that shows the five largest files in ~/Downloads, then explain it in two sentences.}
web=${3:-}
id=org.atropos.assistant.visualtest
work=$(mktemp -d)
rc=${XDG_CONFIG_HOME:-$HOME/.config}/plasmawindowedrc
had_rc=0
[ -e "$rc" ] && had_rc=1
mkdir -p "$out"

cleanup() {
    kpackagetool6 -t Plasma/Applet -r "$id" >/dev/null 2>&1 || true
    [ "$had_rc" = 1 ] || rm -f "$rc"
    rm -rf "$work"
}
trap cleanup EXIT

cp -a "$src/package" "$work/package"
python3 -I - "$work/package" "$id" "$out" "$question" "$web" <<'EOF'
import json, sys
pkg, plugin, out, question, web = sys.argv[1:]
meta = json.load(open(pkg + "/metadata.json"))
meta["KPlugin"]["Id"] = plugin
meta["KPlugin"]["Name"] = "Assistant (visual test)"
json.dump(meta, open(pkg + "/metadata.json", "w"), indent=4)
main = open(pkg + "/contents/ui/main.qml").read()
driver = """
    Timer {
        property int step: 0
        property double t0: 0
        property bool midShot: false
        property bool approvalShot: false
        property bool sized: false
        interval: 1000
        repeat: true
        running: true
        function grab(name) {
            const item = root.fullRepresentationItem;
            item.grabToImage(r => r.saveToFile(%(out)s + "/" + name + ".png"));
        }
        onTriggered: {
            const item = root.fullRepresentationItem;
            if (!item || !root.hasService || chatSession.serverState !== "ready") {
                return;
            }
            if (step === -1) {
                return;
            }
            if (step === 0 && !sized) {
                // Offscreen windows start tiny. Give it a desktop-sized window.
                item.Window.window.width = 1000;
                item.Window.window.height = 720;
                sized = true;
                return;
            }
            if (step === 0) {
                grab("1-start");
                root.submit(%(q)s, [], []);
                t0 = Date.now();
                step = 1;
            } else if (step === 1) {
                if (!midShot && chatSession.busy && Date.now() - t0 > 7000) {
                    grab("2-thinking");
                    midShot = true;
                }
                // A proposed command: screenshot it, then approve it only if it
                // is a plain read-only command; decline anything else.
                for (let i = 0; i < chatSession.messages.count; ++i) {
                    const m = chatSession.messages.get(i);
                    if (m.toolState !== "approval") {
                        continue;
                    }
                    if (!approvalShot) {
                        grab("2b-approval");
                        approvalShot = true;
                        return;
                    }
                    const cmd = String(JSON.parse(m.toolArgs || "{}").command || "");
                    const safe = /^(du|ls|df|wc|stat|find) /.test(cmd) && !/[;&|`$<>]/.test(cmd);
                    console.warn("visual-check:", safe ? "approving" : "declining", cmd);
                    if (safe) {
                        chatSession.approveTool(i);
                    } else {
                        chatSession.denyTool(i);
                    }
                    approvalShot = false;
                    return;
                }
                if (!chatSession.busy) {
                    step = 2;
                }
            } else if (step === 2) {
                // grabToImage captures on the next frame: change things a tick later.
                grab("3-answer");
                step = 24;
            } else if (step === 24) {
                item.setupRequested = true;
                step = 25;
            } else if (step === 25) {
                grab("4-sizes");
                step = 26;
            } else if (step === 26) {
                item.setupRequested = false;
                step = 3;
            } else if (step === 3) {
                root.deleteChat(chatSession.chatId);
                step = 4;
            } else {
                grab("done");
                step = -1;
            }
        }
    }
""" % {"out": json.dumps(out), "q": json.dumps(question)}
# The test copy keeps its own settings: no syncing with the shared file.
main = main.replace("function loadSharedSettings() {", "function loadSharedSettings() {\n        return;", 1)
main = main.replace("        svc.refresh();\n        chatSession.checkServer();",
                    "        Plasmoid.configuration.useLocal = true;\n"
                    "        Plasmoid.configuration.webSearch = %s;\n"
                    "        Plasmoid.configuration.webResults = 3;\n"
                    "        Plasmoid.configuration.tools = true;\n"
                    "        svc.refresh();\n        chatSession.checkServer();" % ("true" if web == "web" else "false"), 1)
assert "return;" in main and "useLocal = true" in main
i = main.rindex("}")
open(pkg + "/contents/ui/main.qml", "w").write(main[:i] + driver + main[i:])
EOF
kpackagetool6 -t Plasma/Applet -i "$work/package" >/dev/null
# Qt.quit() does nothing in plasmawindowed; the driver leaves done.png instead.
QT_QPA_PLATFORM=offscreen QT_QPA_PLATFORMTHEME=kde QT_QUICK_BACKEND=software QT_FORCE_STDERR_LOGGING=1 \
    plasmawindowed "$id" 2>"$out/plasmawindowed.log" &
pid=$!
for _ in $(seq 600); do
    [ -e "$out/done.png" ] && break
    kill -0 "$pid" 2>/dev/null || break
    sleep 1
done
kill "$pid" 2>/dev/null || true
wait "$pid" 2>/dev/null || true
rm -f "$out/done.png"
ls "$out"
