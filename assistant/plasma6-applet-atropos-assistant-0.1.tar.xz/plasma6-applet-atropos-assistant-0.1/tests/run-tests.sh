#!/bin/bash
# SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
# SPDX-License-Identifier: GPL-2.0-or-later
#
# Run the widget's tests in a Tumbleweed container. An AtropOS host has no
# qml tool, and the tests must not touch the running Plasma session.
#
#   tests/run-tests.sh          the D-Bus service, then ChatSession and ImageEncoder,
#                               against the mock server
#   tests/run-tests.sh --lint   also qmllint every file against the Plasma modules

set -euo pipefail

src=$(cd "$(dirname "$0")/.." && pwd)
image=${IMAGE:-registry.opensuse.org/opensuse/tumbleweed:latest}
lint=0
[ "${1:-}" = --lint ] && lint=1

podman run --rm -e LINT=$lint -v "$src:/src:ro,z" "$image" bash -euo pipefail -c '
pkgs="qt6-declarative-tools qt6-declarative-imports qt6-imageformats python3 python3-dbus-python python3-gobject dbus-1-daemon"
if [ "$LINT" = 1 ]; then
    pkgs="$pkgs libplasma6-components kf6-kirigami-imports kf6-kcmutils-imports kf6-knotifications-imports kf6-kcoreaddons-imports plasma6-workspace"
fi
zypper -n -q --gpg-auto-import-keys ref >/dev/null
zypper -n -q in --no-recommends $pkgs >/dev/null
rpm -q --qf "%{NAME} %{VERSION}\n" qt6-declarative-tools

echo "-- service"
service_status=0
dbus-run-session -- python3 -I /src/tests/test_service.py || service_status=1

log=/tmp/assistant-test-log
mkdir -p "$log"
# A 2000x1000 PNG for the encoder test.
python3 -I - "$log/wide.png" <<EOF
import struct, sys, zlib
w, h = 2000, 1000
row = b"\x00" + bytes([200, 60, 20]) * w
raw = row * h
def chunk(t, d):
    return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) \
    + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
open(sys.argv[1], "wb").write(png)
EOF

python3 -I /src/tests/mock_server.py 18999 "$log" &
for _ in $(seq 50); do
    python3 -I -c "import socket; socket.create_connection((\"127.0.0.1\", 18999), 1)" 2>/dev/null && break
    sleep 0.1
done

# openSUSE Qt logs to journald and drops debug output. console.log is debug.
export QT_FORCE_STDERR_LOGGING=1 QT_LOGGING_RULES="*.debug=true;qt.*.debug=false"
export QT_QPA_PLATFORM=offscreen QML_XHR_ALLOW_FILE_READ=1 LANG=C.UTF-8
set +e
/usr/lib64/qt6/bin/qml /src/tests/test_session.qml
status=$?
set -e
[ "$service_status" = 0 ] || status=1

if [ "$LINT" = 1 ]; then
    echo "-- qmllint"
    cd /src/package/contents/ui
    /usr/lib64/qt6/bin/qmllint -I /usr/lib64/qt6/qml --unqualified disable *.qml ../config/*.qml || status=1
fi
exit $status
'
