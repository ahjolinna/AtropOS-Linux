#!/usr/bin/python3
# SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
# SPDX-License-Identifier: GPL-2.0-or-later
#
# Runs atropos-assistant-service on a private session bus, with fake
# systemctl, journalctl, plasmawindowed and setup tools, so nothing touches
# the real model service, the desktop or the clipboard.
#
#   dbus-run-session -- python3 -I tests/test_service.py

import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time

import dbus

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(HERE)
PORT = 18997
failures = 0
checks = 0


def check(ok, what):
    global failures, checks
    checks += 1
    if ok:
        print("ok:", what)
    else:
        failures += 1
        print("FAIL:", what)


def wait(what, cond, timeout=10):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if cond():
            return True
        time.sleep(0.1)
    check(False, "timed out waiting for " + what)
    return False


tmp = tempfile.mkdtemp(prefix="assistant-service-test-")
fakebin = os.path.join(tmp, "bin")
os.makedirs(fakebin)
calls = os.path.join(tmp, "calls.log")


def fake(name, body):
    path = os.path.join(fakebin, name)
    with open(path, "w") as f:
        f.write("#!/bin/bash\n" + body + "\n")
    os.chmod(path, 0o755)


fake("systemctl", f"""echo "systemctl $*" >> {calls}
case "$*" in *show*) echo "ActiveState=$(cat {tmp}/state 2>/dev/null || echo inactive)"; echo LoadState=loaded ;; esac""")
fake("journalctl", 'echo "0.24.1 E srv    load_model: failed to create_context"')
fake("plasmawindowed", f'echo "plasmawindowed $* token=$XDG_ACTIVATION_TOKEN" >> {calls}')
fake("atropos-assistant-server", f'[ -e {tmp}/ready ] && exit 0; exit 2')
fake("atropos-assistant-setup", f"""echo "setup $*" >> {calls}
d=$XDG_DATA_HOME/atropos-assistant/models
mkdir -p "$d"
echo "{{\\"quant\\": \\"UD-Q4_K_XL\\", \\"plan\\": [{{\\"name\\": \\"a.bin\\", \\"dest\\": \\"$d/a.bin\\", \\"size\\": 4000}}, {{\\"name\\": \\"b.bin\\", \\"dest\\": \\"$d/b.bin\\", \\"size\\": 2000}}]}}"
echo '{{"phase": "download", "file": "a.bin"}}'
for i in 1 2 3 4; do head -c 1000 /dev/zero >> "$d/a.bin.part"; sleep 0.4; done
mv "$d/a.bin.part" "$d/a.bin"
echo '{{"phase": "download", "file": "b.bin"}}'
head -c 2000 /dev/zero > "$d/b.bin"
touch {tmp}/ready
echo '{{"done": true}}'""")

# The local server, as atropos-assistant-setup would describe it: the mock.
os.makedirs(os.path.join(tmp, "config", "atropos-assistant"))
with open(os.path.join(tmp, "model.gguf"), "wb") as f:
    f.write(b"\0" * 1234)
with open(os.path.join(tmp, "config", "atropos-assistant", "server.conf"), "w") as f:
    f.write("#PORT=1\nPORT=%d\nMODEL=%s\nMMPROJ=\n" % (PORT, os.path.join(tmp, "model.gguf")))

env = dict(os.environ)
env.update({
    "ATROPOS_ASSISTANT_SEARCH_URL": "http://127.0.0.1:%d/html/" % PORT,
    "ATROPOS_ASSISTANT_INSTANT_URL": "http://127.0.0.1:%d/instant" % PORT,
    "ATROPOS_ASSISTANT_GEO_URL": "http://127.0.0.1:%d/geo" % PORT,
    "ATROPOS_ASSISTANT_FORECAST_URL": "http://127.0.0.1:%d/forecast" % PORT,
    "PATH": fakebin + ":" + env["PATH"],
    "HOME": tmp,
    "ATROPOS_ASSISTANT_COMMAND_TIMEOUT": "2",
    "XDG_DATA_HOME": os.path.join(tmp, "data"),
    "XDG_CONFIG_HOME": os.path.join(tmp, "config"),
})
env.pop("WAYLAND_DISPLAY", None)
env.pop("DISPLAY", None)

mock = subprocess.Popen([sys.executable, "-I", os.path.join(HERE, "mock_server.py"), str(PORT), tmp])
service = subprocess.Popen([sys.executable, "-I", os.path.join(SRC, "server", "atropos-assistant-service")], env=env)
for _ in range(50):
    try:
        socket.create_connection(("127.0.0.1", PORT), 1).close()
        break
    except OSError:
        time.sleep(0.1)

bus = dbus.SessionBus()
wait("the service on the bus", lambda: bus.name_has_owner("org.atropos.Assistant"))
obj = bus.get_object("org.atropos.Assistant", "/org/atropos/Assistant")
api = dbus.Interface(obj, "org.atropos.Assistant1")
runner = dbus.Interface(obj, "org.kde.krunner1")


def status():
    return json.loads(api.Status())


def calls_log():
    try:
        return open(calls).read()
    except FileNotFoundError:
        return ""


try:
    print("-- status")
    s = status()
    check(s["setup"]["state"] == "missing", "setup missing before the download")
    check(s["server"]["state"] == "inactive", "server inactive")
    check(len(s["quants"]) == 10 and s["defaultQuant"] == "UD-IQ1_S", "ten sizes, the lightest by default")
    check(s["quants"][0]["needGiB"] == 9 and s["quants"][-1]["needGiB"] == 24, "memory needs from Unsloth's guide")
    check(all(q["fits"] == (q["needGiB"] <= s["budgetGiB"]) for q in s["quants"]), "fits follows the memory budget")
    check(s["localUrl"] == "http://127.0.0.1:%d" % PORT, "local address from server.conf, comments skipped")
    check(s["localModel"] == {"file": "model", "size": 1234, "vision": False}, "downloaded model described")

    print("-- download")
    api.Download("UD-Q4_K_XL", True, True)
    check(status()["setup"]["state"] == "downloading", "downloading")
    seen = []
    wait("progress", lambda: seen.append(status()["setup"]["progress"]) or seen[-1].get("received", 0) >= 2000)
    p = seen[-1]
    check(p["total"] == 6000 and p["file"] == "a.bin" and p["phase"] == "download", "progress names the file and total")
    wait("ready", lambda: status()["setup"]["state"] == "ready")
    check("--machine --quant UD-Q4_K_XL" in calls_log(), "setup ran in machine mode with the size")
    check("--no-block start atropos-assistant.service" in calls_log(), "the model starts after the download")

    print("-- cancel")
    os.remove(os.path.join(tmp, "ready"))
    shutil.rmtree(os.path.join(tmp, "data", "atropos-assistant", "models"))
    api.Download("", False, False)
    wait("first bytes", lambda: status()["setup"]["progress"].get("received", 0) > 0)
    check("--no-vision" in calls_log(), "no-vision passed through")
    api.CancelDownload()
    wait("cancelled", lambda: status()["setup"]["state"] == "missing")
    check(status()["setup"]["error"] == "", "cancelling is not an error")

    print("-- server errors")
    open(os.path.join(tmp, "state"), "w").write("failed")
    s = status()
    check(s["server"]["state"] == "failed" and "load_model" in s["server"]["error"], "failed server reports the journal")
    os.remove(os.path.join(tmp, "state"))

    print("-- chats")
    cid = api.SaveChat(json.dumps({"messages": [
        {"role": "user", "content": "How do I list btrfs snapshots?"},
        {"role": "assistant", "content": "Use `snapper list`.", "thinking": "snapper"},
        {"role": "user", "content": "And delete one?"},
        {"role": "assistant", "content": "`snapper delete N`"},
    ]}))
    chats = json.loads(api.ListChats())
    check(len(chats) == 1 and chats[0]["id"] == cid and chats[0]["title"] == "How do I list btrfs snapshots?", "saved chat listed with a title")
    check(chats[0]["count"] == 4 and not chats[0]["favorite"], "count and favorite")
    path = os.path.join(tmp, "data", "atropos-assistant", "chats", cid + ".json")
    check(oct(os.stat(path).st_mode & 0o777) == "0o600", "chat file is private")
    chat = json.loads(api.LoadChat(cid))
    check(chat["messages"][1]["thinking"] == "snapper", "load round-trips")
    api.RenameChat(cid, "  Snapper   help ")
    api.SetFavorite(cid, True)
    chats = json.loads(api.ListChats())
    check(chats[0]["title"] == "Snapper help" and chats[0]["favorite"], "rename and favorite")
    fork = api.DuplicateChat(cid, 1)
    forked = json.loads(api.LoadChat(fork))
    check(len(forked["messages"]) == 2 and forked["title"] == "Snapper help (fork)", "fork keeps messages up to the index")
    copy = json.loads(api.LoadChat(api.DuplicateChat(cid, -1)))
    check(len(copy["messages"]) == 4 and copy["title"].endswith("(copy)"), "duplicate copies everything")
    hits = json.loads(api.SearchChats("DELETE N"))
    check(len(hits) == 2 and "snapper delete N" in hits[0]["snippet"], "search is case-insensitive with a snippet")
    check(json.loads(api.SearchChats("nothing like this")) == [], "search with no hits")
    md = os.path.join(tmp, "out.md")
    api.ExportChat(cid, "md", "file://" + md)
    text = open(md).read()
    check(text.startswith("# Snapper help") and "## Inkling 2 Mini" in text and "`snapper list`" in text, "Markdown export")
    txt = os.path.join(tmp, "out.txt")
    api.ExportChat(cid, "txt", txt)
    check("You:" in open(txt).read() and "`" not in open(txt).read(), "text export drops Markdown")
    js = os.path.join(tmp, "out.json")
    api.ExportChat(cid, "json", js)
    imported = api.ImportChat("file://" + js)
    check(imported != cid and json.loads(api.LoadChat(imported))["title"] == "Snapper help", "JSON export imports as a new chat")
    try:
        api.ImportChat(md)
        check(False, "importing Markdown fails")
    except dbus.DBusException:
        check(True, "importing Markdown fails")
    try:
        api.LoadChat("../../etc/passwd")
        check(False, "path traversal rejected")
    except dbus.DBusException:
        check(True, "path traversal rejected")
    api.DeleteChat(imported)
    check(api.LoadChat(imported) == "", "deleted")

    print("-- text files")
    notes = os.path.join(tmp, "notes.txt")
    open(notes, "w").write("line one\nline two\n")
    check(api.ReadTextFile("file://" + notes) == "line one\nline two\n", "reads a text file from a URL")
    blob = os.path.join(tmp, "blob.bin")
    open(blob, "wb").write(b"\x00\x01\x02")
    try:
        api.ReadTextFile(blob)
        check(False, "binary file rejected")
    except dbus.DBusException as e:
        check("not a text file" in e.get_dbus_message(), "binary file rejected")

    print("-- web search")
    hits = json.loads(api.WebSearch("kde plasma", 3))
    check(len(hits) == 3 and hits[0]["url"] == "https://kde.org/plasma-desktop/", "three results, the ad skipped")
    check(hits[0]["snippet"] == "Plasma is KDE's desktop." and hits[0]["title"] == "Plasma - KDE Community", "title and snippet as text")
    check(hits[1]["url"] == "https://en.wikipedia.org/wiki/KDE_Plasma", "DuckDuckGo redirect unwrapped")
    check(len(json.loads(api.WebSearch("kde plasma", 9))) == 5, "at most five results")
    check(json.loads(api.WebSearch("   ", 3)) == [], "an empty query searches nothing")
    hits = json.loads(api.WebSearch("robot kde", 3))
    check(len(hits) == 2 and all(h.get("kind") == "instant" for h in hits) and hits[0]["title"] == "KDE Plasma",
          "a robot check falls back to instant answers")
    check(hits[1]["url"] == "https://duckduckgo.com/GNOME_Shell", "category links left out")
    hits = json.loads(api.WebSearch("kde desktop", 3))
    check(hits and hits[0].get("kind") == "instant", "the HTML page is left alone during the cool-down")
    hits = json.loads(api.WebSearch("kde plasma", 3))
    check(hits[0]["url"] == "https://kde.org/plasma-desktop/", "a repeated question reuses its results")
    try:
        api.WebSearch("robot nothing", 3)
        check(False, "no results at all is an error")
    except dbus.DBusException as e:
        check("limiting" in e.get_dbus_message(), "no results at all is an error")

    print("-- this computer")
    check("Linux" in api.SystemInfo("kernel", "") and api.SystemInfo("kernel", "").startswith("$ uname"), "kernel lookup")
    check("NAME=" in api.SystemInfo("os", ""), "os-release lookup")
    check("bash" in api.SystemInfo("package", "bash"), "package lookup")
    for topic, package, why in (("rm", "", "unknown topic"), ("package", "bash; rm -rf ~", "bad package name"),
                                ("package", "", "missing package name")):
        try:
            api.SystemInfo(topic, package)
            check(False, why + " rejected")
        except dbus.DBusException:
            check(True, why + " rejected")
    r = json.loads(api.RunCommand("echo hi; echo oops >&2; exit 3"))
    check(r["code"] == 3 and r["output"] == "hi\noops\n" and not r["timedOut"], "command output, errors and exit code")
    check(json.loads(api.RunCommand("pwd"))["output"].strip() == tmp, "commands run from the home folder")
    r = json.loads(api.RunCommand("sleep 10"))
    check(r["timedOut"] and r["code"] == -1 and r["seconds"] < 6, "a command that runs too long is stopped")
    r = json.loads(api.RunCommand("seq 1 5000"))
    check(r["truncated"] and "left out" in r["output"] and r["output"].endswith("5000\n"), "long output keeps its start and end")
    try:
        api.RunCommand("   ")
        check(False, "an empty command is rejected")
    except dbus.DBusException:
        check(True, "an empty command is rejected")

    print("-- weather")
    w = api.Weather("Testville")
    check(w.startswith("Weather for Testville, Test State, Testland from Open-Meteo"), "weather names the place")
    check("Now: 5.3 °C, feels like 1.3 °C, light rain, wind 16.6 km/h from W" in w, "current conditions in words")
    check("Today (2026-11-22): light rain showers, 2.1 to 5.6 °C" in w and "Tomorrow (2026-11-23): light snow" in w,
          "today and tomorrow")
    try:
        api.Weather("Nowhere")
        check(False, "an unknown place is an error")
    except dbus.DBusException as e:
        check("no place called Nowhere" in e.get_dbus_message(), "an unknown place is an error")

    print("-- chat list stamp")
    before = status()["chats"]
    api.DeleteChat(api.SaveChat(json.dumps({"messages": [{"role": "user", "content": "stamp"}]})))
    check(status()["chats"] != before, "saving and deleting change the stamp")

    print("-- settings")
    check(api.GetSettings() == "", "no settings before the first save")
    api.SetSettings(json.dumps({"remoteUrl": "http://192.168.1.20:8080", "bogus": 1, "backend": "ollama"}))
    s = json.loads(api.GetSettings())
    check(s["remoteUrl"] == "http://192.168.1.20:8080" and s["useLocal"] is True, "settings merge known keys")
    check("bogus" not in s and "backend" not in s and s["reasoningEffort"] == "low", "unknown and old keys dropped")

    print("-- krunner")
    check(list(runner.Actions()) == [("window", "Open in Assistant", "window-new")], "one action")
    check(list(runner.Match("ai")) == [] and list(runner.Match("aim high")) == [], "needs the ai trigger")
    m = runner.Match("ai what is KDE")
    check(len(m) == 1 and m[0][0] == "ask:what is KDE" and "what is KDE" in m[0][1], "ask match")
    runner.Run("ask:what is KDE", "")
    wait("background answer", lambda: len(runner.Match("ai what is KDE")) == 2)
    m = runner.Match("ai what is KDE")
    check(m[0][0].startswith("answer:") and m[0][5]["multiline"] and "Hello!" in m[0][1], "answer match comes first, multi-line")
    check("**" not in m[0][1] and "```" not in m[0][1], "answer shown without Markdown marks")
    kchat = json.loads(api.LoadChat(m[0][0].split(":", 1)[1]))
    check(kchat["source"] == "krunner" and kchat["messages"][1]["thinking"].startswith("The user"), "KRunner answer saved as a chat")
    req = json.load(open(os.path.join(tmp, sorted(f for f in os.listdir(tmp) if f.startswith("request-"))[-1])))
    check(req["body"]["stream"] is False and req["body"]["reasoning_effort"] == "low", "KRunner asks with the saved effort")
    runner.SetActivationToken("tok123")
    runner.Run(m[0][0], "window")
    wait("window launch", lambda: "plasmawindowed org.atropos.assistant token=tok123" in calls_log())
    check(json.loads(api.TakeRequest())["id"] == kchat["id"], "the window can take the request")
    check(api.TakeRequest() == "", "a request is taken once")
    runner.Run("ask:open this one", "window")
    r = json.loads(api.TakeRequest())
    check(r["autoSend"] and json.loads(api.LoadChat(r["id"]))["messages"][0]["content"] == "open this one", "Open in Assistant sends the question there")

    print("-- KRunner with web search and the weather")
    api.SetSettings(json.dumps({"webSearch": True, "webResults": 3, "weatherPlace": "Testville"}))
    # The bot-check test above started the cool-down, so this search gets
    # instant answers; the mock has those for questions about KDE.
    runner.Run("ask:what is the weather today for kde fans", "")

    def krunner_chat(question):
        for c in json.loads(api.ListChats()):
            chat = json.loads(api.LoadChat(c["id"]))
            if chat["messages"][0].get("content") == question and chat["messages"][-1]["role"] == "assistant" \
                    and chat["messages"][-1].get("content"):
                return chat
        return None
    wait("the weather answer", lambda: krunner_chat("what is the weather today for kde fans") is not None, timeout=15)
    chat = krunner_chat("what is the weather today for kde fans") or {"messages": [{}]}
    m = chat["messages"]
    check(len(m[0].get("sources", [])) == 2 and m[0]["sources"][0].get("kind") == "instant",
          "the question searched first (instant answers during the cool-down)")
    check(len(m) == 4 and m[1].get("toolCalls", [{}])[0].get("name") == "weather", "the model asked for the weather")
    check(m[2].get("role") == "tool" and m[2].get("toolState") == "done" and "Weather for Testville" in m[2].get("content", ""),
          "the weather step ran for the settings' place and was saved")
    req = json.load(open(os.path.join(tmp, sorted((f for f in os.listdir(tmp) if f.startswith("request-")),
                                                  key=lambda f: int(f[8:-5]))[-1])))
    check(req["body"]["messages"][-1]["role"] == "tool" and req["body"]["messages"][1]["content"].startswith("Web search results"),
          "the second request carries the search and the weather")
    api.SetSettings(json.dumps({"webSearch": False, "weatherPlace": ""}))

    print("-- an unreachable server fails fast")
    api.SetSettings(json.dumps({"useLocal": False, "remoteUrl": "http://127.0.0.1:9"}))
    runner.Run("ask:is anyone there", "")
    started = time.time()

    def failed():
        for c in json.loads(api.ListChats()):
            chat = json.loads(api.LoadChat(c["id"]))
            if chat["messages"][0].get("content") == "is anyone there" and len(chat["messages"]) > 1:
                return chat["messages"][1]
        return None
    wait("the error", lambda: failed() is not None, timeout=15)
    err = failed() or {}
    check(err.get("role") == "error" and "127.0.0.1:9" in err.get("content", ""), "error names the address")
    check(time.time() - started < 15, "no long wait for a server the service cannot start")
    check("start atropos-assistant.service" not in calls_log().split("--no-block start atropos-assistant.service", 1)[-1],
          "another server is not started through systemd")
    api.SetSettings(json.dumps({"useLocal": True}))

    print("-- restart keeps KRunner answers")
    service.terminate()
    service.wait(5)
    service = subprocess.Popen([sys.executable, "-I", os.path.join(SRC, "server", "atropos-assistant-service")], env=env)
    wait("the service again", lambda: bus.name_has_owner("org.atropos.Assistant"))
    obj = bus.get_object("org.atropos.Assistant", "/org/atropos/Assistant")
    runner = dbus.Interface(obj, "org.kde.krunner1")
    check(runner.Match("ai what is KDE")[0][0].startswith("answer:"), "answer found in saved chats")
finally:
    service.terminate()
    mock.terminate()
    shutil.rmtree(tmp, ignore_errors=True)

print("%d checks, %d failures" % (checks, failures))
sys.exit(1 if failures else 0)
