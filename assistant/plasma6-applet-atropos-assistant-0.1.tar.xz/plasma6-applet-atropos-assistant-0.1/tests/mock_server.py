#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
# SPDX-License-Identifier: GPL-2.0-or-later
#
# A stand-in for llama-server, for the widget's tests.
# It streams a fixed answer and writes each chat request body to
# <log dir>/request-<n>.json.
#
#   mock_server.py PORT LOGDIR
#
# The last user message steers it: "please error" answers 400,
# "slow" streams one chunk every 0.3 s.

import json
import os
import sys
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

THINKING = ["The user ", "says hello. ", "Answer briefly."]
ANSWER = ["Hello! ", "Here is **bold** text,\n\n", "- one\n- two\n\n", "```sh\necho hi\n```\n"]

# A DuckDuckGo HTML results page: an ad first, then six results, one of
# them behind DuckDuckGo's /l/?uddg= redirect.
def ddg_page(query):
    if "robot" in query:
        return "<html><body><div class='anomaly-modal'>Unfortunately, bots use DuckDuckGo too.</div></body></html>"
    def result(cls, href, title, snippet):
        return ('<div class="%s"><div class="links_main result__body"><h2 class="result__title">'
                '<a rel="nofollow" class="result__a" href="%s">%s</a></h2>'
                '<a class="result__snippet" href="%s">%s</a></div></div>' % (cls, href, title, href, snippet))
    rows = [result("result results_links result--ad", "https://ads.example/", "An ad", "Buy things")]
    rows.append(result("result results_links web-result", "https://kde.org/plasma-desktop/",
                       "Plasma - KDE Community", "<b>Plasma</b> is KDE&#x27;s desktop."))
    rows.append(result("result results_links web-result",
                       "//duckduckgo.com/l/?uddg=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FKDE_Plasma&amp;rut=abc",
                       "KDE Plasma - Wikipedia", "A graphical shell by the KDE community."))
    for i in range(4):
        rows.append(result("result results_links web-result", "https://example.org/%d" % i,
                           "Result %d for %s" % (i, query), "Snippet %d" % i))
    return "<html><body><div id='links' class='results'>%s</div></body></html>" % "".join(rows)


port = int(sys.argv[1])
log_dir = sys.argv[2]
count = 0


def last_user_text(body):
    for m in reversed(body.get("messages", [])):
        if m.get("role") == "user":
            c = m.get("content")
            if isinstance(c, list):
                return " ".join(p.get("text", "") for p in c if isinstance(p, dict))
            return c or ""
    return ""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def send_json(self, status, obj):
        data = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/geo"):
            # Open-Meteo geocoding: one known place.
            name = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("name", [""])[0]
            if name == "Testville":
                self.send_json(200, {"results": [{"name": "Testville", "admin1": "Test State", "country": "Testland",
                                                  "latitude": 60.17, "longitude": 24.94}]})
            else:
                self.send_json(200, {"generationtime_ms": 0.1})
            return
        if self.path.startswith("/forecast"):
            self.send_json(200, {
                "current": {"time": "2026-11-22T01:30", "temperature_2m": 5.3, "apparent_temperature": 1.3,
                            "relative_humidity_2m": 86, "precipitation": 0.4, "weather_code": 61,
                            "wind_speed_10m": 16.6, "wind_direction_10m": 272},
                "daily": {"time": ["2026-11-22", "2026-11-23", "2026-11-24"], "weather_code": [80, 71, 3],
                          "temperature_2m_max": [5.6, 3.3, 2.0], "temperature_2m_min": [2.1, -0.1, -1.0],
                          "precipitation_sum": [1.9, 0.19, 0.0], "precipitation_probability_max": [88, 33, 5],
                          "sunrise": ["2026-11-22T07:39", "2026-11-23T07:41", "2026-11-24T07:43"],
                          "sunset": ["2026-11-22T16:04", "2026-11-23T16:03", "2026-11-24T16:02"]}})
            return
        if self.path.startswith("/instant"):
            # DuckDuckGo's Instant Answer API: something for queries about KDE.
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("q", [""])[0]
            if "kde" in query.lower():
                self.send_json(200, {"Heading": "KDE Plasma", "AbstractURL": "https://en.wikipedia.org/wiki/KDE_Plasma",
                                     "AbstractText": "KDE Plasma is a graphical shell.", "Answer": "",
                                     "RelatedTopics": [
                                         {"FirstURL": "https://duckduckgo.com/c/KDE", "Text": "KDE Category"},
                                         {"FirstURL": "https://duckduckgo.com/GNOME_Shell", "Text": "GNOME Shell - Another shell."}]})
            else:
                self.send_json(200, {"Heading": "", "AbstractText": "", "AbstractURL": "", "Answer": "", "RelatedTopics": []})
            return
        if self.path == "/health":
            self.send_json(200, {"status": "ok"})
        elif self.path == "/v1/models":
            self.send_json(200, {"object": "list", "data": [{"id": "inkling-2-mini", "object": "model"}]})
        else:
            self.send_json(404, {"error": "not found"})

    def read_body(self):
        global count
        n = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(n) or b"{}")
        count += 1
        with open(os.path.join(log_dir, "request-%d.json" % count), "w") as f:
            json.dump({"path": self.path, "body": body}, f, indent=1)
        return body

    def stream_start(self, content_type):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

    def write(self, text):
        try:
            self.wfile.write(text.encode())
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError):
            return False

    def do_POST(self):
        if self.path.startswith("/html"):
            n = int(self.headers.get("Content-Length", "0"))
            query = urllib.parse.parse_qs(self.rfile.read(n).decode()).get("q", [""])[0]
            page = ddg_page(query).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(page)))
            self.end_headers()
            self.wfile.write(page)
            return
        body = self.read_body()
        text = last_user_text(body)
        if "please error" in text:
            self.send_json(400, {"error": {"code": 400, "message": "mock refused", "type": "invalid_request_error"}})
            return
        delay = 0.3 if "slow" in text else 0.01
        pieces = 40 if "slow" in text else 1

        if (self.path == "/v1/chat/completions" and body.get("stream") is False and body.get("tools")
                and "weather" in text and body["messages"][-1].get("role") != "tool"):
            self.send_json(200, {"object": "chat.completion", "choices": [{"index": 0, "finish_reason": "tool_calls",
                "message": {"role": "assistant", "content": "", "reasoning_content": "Check the weather.",
                            "tool_calls": [{"id": "w1", "type": "function",
                                            "function": {"name": "weather", "arguments": '{"place":""}'}}]}}]})
        elif self.path == "/v1/chat/completions" and body.get("stream") is False:
            self.send_json(200, {
                "object": "chat.completion",
                "choices": [{"index": 0, "finish_reason": "stop", "message": {
                    "role": "assistant", "content": "".join(ANSWER), "reasoning_content": "".join(THINKING)}}],
                "timings": {"predicted_n": 42, "predicted_per_second": 20.5},
            })
        elif self.path == "/v1/chat/completions" and "use tools" in text and body["messages"][-1].get("role") != "tool":
            # A tool round in llama-server's pieces: name first, then arguments.
            self.stream_start("text/event-stream")

            def calls(c, finish=None, extra=None):
                obj = {"choices": [{"index": 0, "delta": {"tool_calls": c} if c else {}, "finish_reason": finish}]}
                if extra:
                    obj.update(extra)
                self.write("data: " + json.dumps(obj) + "\n\n")

            self.write("data: " + json.dumps({"choices": [{"index": 0, "delta": {"reasoning_content": "Look it up."}}]}) + "\n\n")
            calls([{"index": 0, "id": "call_1", "type": "function", "function": {"name": "system_info", "arguments": ""}}])
            calls([{"index": 0, "function": {"arguments": '{"topic":'}}])
            calls([{"index": 0, "function": {"arguments": '"memory"}'}}])
            calls([{"index": 1, "id": "call_2", "type": "function",
                    "function": {"name": "run_command", "arguments": '{"command":"echo hi","reason":"to test"}'}}])
            calls(None, "tool_calls", {"timings": {"predicted_n": 20, "predicted_per_second": 10.0}})
            self.write("data: [DONE]\n\n")
            self.close_connection = True
        elif self.path == "/v1/chat/completions":
            self.stream_start("text/event-stream")

            def event(delta, finish=None, extra=None):
                obj = {"choices": [{"index": 0, "delta": delta, "finish_reason": finish}], "object": "chat.completion.chunk"}
                if extra:
                    obj.update(extra)
                return self.write("data: " + json.dumps(obj) + "\n\n")

            for t in THINKING:
                if not event({"reasoning_content": t}):
                    return
                time.sleep(delay)
            for _ in range(pieces):
                for t in ANSWER:
                    if not event({"content": t}):
                        return
                    time.sleep(delay)
            event({}, "stop", {"timings": {"predicted_n": 42, "predicted_per_second": 20.5}})
            self.write("data: [DONE]\n\n")
            self.close_connection = True

        else:
            self.send_json(404, {"error": "not found"})


ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
