#!/bin/bash
# SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
# SPDX-License-Identifier: GPL-2.0-or-later
#
# Install the Assistant for this user only, without the RPM: the widget,
# the Assistant window, the KRunner plugin, the scripts and the services,
# all under ~/.local and ~/.config.
#
#   ./install.sh               install or upgrade
#   ./install.sh --uninstall   remove them (the model and saved chats stay)

set -euo pipefail

here=$(cd "$(dirname "$0")" && pwd)
bin=$HOME/.local/bin
data=${XDG_DATA_HOME:-$HOME/.local/share}
units=${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user
id=org.atropos.assistant

files=(
    "$bin/atropos-assistant-server"
    "$bin/atropos-assistant-setup"
    "$bin/atropos-assistant-service"
    "$units/atropos-assistant.service"
    "$units/atropos-assistant-bus.service"
    "$data/dbus-1/services/org.atropos.Assistant.service"
    "$data/krunner/dbusplugins/$id.desktop"
    "$data/applications/$id.desktop"
    "$data/knotifications6/atropos-assistant.notifyrc"
)

reload() {
    systemctl --user daemon-reload
    busctl --user call org.freedesktop.DBus /org/freedesktop/DBus org.freedesktop.DBus ReloadConfig >/dev/null 2>&1 || true
}

if [ "${1:-}" = --uninstall ]; then
    systemctl --user stop atropos-assistant.service atropos-assistant-bus.service 2>/dev/null || true
    kpackagetool6 -t Plasma/Applet -r "$id" || true
    rm -f -- "${files[@]}"
    reload
    echo "Removed. The model and chats are still in $data/atropos-assistant."
    exit 0
fi

kpackagetool6 -t Plasma/Applet -u "$here/package" >/dev/null 2>&1 \
    || kpackagetool6 -t Plasma/Applet -i "$here/package"

install -d "$bin" "$units" "$data/dbus-1/services" "$data/krunner/dbusplugins" "$data/applications" "$data/knotifications6"
install -m 0755 "$here/server/atropos-assistant-server" "$here/server/atropos-assistant-setup" \
    "$here/server/atropos-assistant-service" "$bin/"
for f in atropos-assistant.service atropos-assistant-bus.service; do
    sed "s|/usr/bin/|$bin/|g" "$here/server/$f" >"$units/$f"
done
sed "s|/usr/bin/|$bin/|g" "$here/server/org.atropos.Assistant.service" >"$data/dbus-1/services/org.atropos.Assistant.service"
install -m 0644 "$here/desktop/krunner-$id.desktop" "$data/krunner/dbusplugins/$id.desktop"
install -m 0644 "$here/desktop/$id.desktop" "$data/applications/$id.desktop"
install -m 0644 "$here/desktop/atropos-assistant.notifyrc" "$data/knotifications6/"
reload
# A running service keeps the old code until it exits. Stop it; the next call starts the new one.
systemctl --user stop atropos-assistant-bus.service 2>/dev/null || true

echo "Installed. Add the widget to a panel: right-click the panel, Add or Manage Widgets, Assistant."
echo "The Assistant window is in the application menu. In KRunner, type: ai <question>"
echo "Plasma and KRunner pick up a new version after: systemctl --user restart plasma-plasmashell; kquitapp6 krunner"
