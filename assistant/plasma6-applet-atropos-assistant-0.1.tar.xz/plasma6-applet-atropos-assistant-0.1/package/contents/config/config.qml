import QtQuick

import org.kde.plasma.configuration

ConfigModel {
    ConfigCategory {
        name: i18n("General")
        icon: "dialog-messages"
        source: "ConfigGeneral.qml"
    }
}
