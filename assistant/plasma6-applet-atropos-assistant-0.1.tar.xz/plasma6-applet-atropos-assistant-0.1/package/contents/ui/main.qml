// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later

import QtQuick

import org.kde.notification
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.plasmoid

PlasmoidItem {
    id: root

    // plasmawindowed sets the Application form factor: the Assistant window.
    readonly property bool windowed: Plasmoid.formFactor === PlasmaCore.Types.Application
    // The system tray draws the popup's title and pin button itself.
    readonly property bool inTray: (Plasmoid.containmentDisplayHints & PlasmaCore.Types.ContainmentDrawsPlasmoidHeading) !== 0

    // Saved chats: [{ id, title, created, updated, favorite, source, count }]
    property var chats: []

    readonly property bool hasService: svc.available === true
    // ready, missing, downloading, error, unavailable, unmanaged, unknown
    readonly property string setupState: hasService ? svc.setupState : (svc.available === false ? "unmanaged" : "unknown")
    readonly property bool useLocal: Plasmoid.configuration.useLocal
    readonly property bool managed: hasService
        && useLocal
        && Plasmoid.configuration.manageServer
        && setupState !== "unavailable"
    readonly property bool canStart: managed && setupState === "ready"
    // Where atropos-assistant-server listens; server.conf can change the port.
    readonly property string localUrl: svc.status.localUrl || "http://127.0.0.1:18080"
    // The local model is set up but the settings point at another server.
    readonly property bool localAvailable: hasService && setupState === "ready" && !useLocal

    function useLocalModel() {
        Plasmoid.configuration.useLocal = true;
        Plasmoid.configuration.manageServer = true;
    }
    property bool startRequested: false
    property double startRequestedAt: 0
    readonly property bool starting: startRequested || (managed && svc.serverState === "activating")
    readonly property string startError: managed && svc.serverState === "failed"
        ? (svc.status.server.error || i18n("The model server stopped with an error.")) : ""

    // The file dialog takes focus from the popup. Keep the popup open meanwhile.
    hideOnWindowDeactivate: !pinned && !dialogOpen
    property bool pinned: false
    property bool dialogOpen: false

    Plasmoid.icon: "dialog-messages"
    Plasmoid.busy: chatSession.generating
    // In the system tray, Passive puts the icon in the overflow. Show it while
    // the model is running, answering or downloading.
    Plasmoid.status: chatSession.busy || svc.setupState === "downloading" || root.starting
        || svc.serverState === "active" || chatSession.serverState === "ready"
        ? PlasmaCore.Types.ActiveStatus : PlasmaCore.Types.PassiveStatus

    Binding {
        target: Plasmoid
        property: "title"
        when: root.windowed
        value: chatSession.title ? i18nc("window title: chat title — app", "%1 — Assistant", chatSession.title) : i18n("Assistant")
    }

    toolTipMainText: i18n("Assistant")
    toolTipSubText: {
        const name = chatSession.modelName || i18n("Local model");
        if (chatSession.generating) {
            return i18nc("%1 is the model name", "%1 is answering…", name);
        }
        if (svc.setupState === "downloading") {
            return i18nc("%1 is the model name", "Downloading %1…", name);
        }
        switch (chatSession.serverState) {
        case "ready":
            return i18nc("%1 is the model name", "%1 is ready", name);
        case "loading":
            return i18nc("%1 is the model name", "%1 is loading…", name);
        case "missing":
            return i18nc("%1 is the model name", "%1 is not downloaded", name);
        default:
            return i18nc("%1 is the model name", "%1 is not running", name);
        }
    }

    ChatSession {
        id: chatSession
        serverUrl: root.useLocal ? root.localUrl : Plasmoid.configuration.remoteUrl
        model: root.useLocal ? "" : Plasmoid.configuration.remoteModel
        reasoningEffort: Plasmoid.configuration.reasoningEffort
        systemPrompt: Plasmoid.configuration.systemPrompt + (toolsOn ? root.toolsPrompt : "")
        toolDefinitions: Plasmoid.configuration.tools && root.hasService ? root.toolDefinitions : []
        toolRunner: root.hasService ? root.runTool : null
        approvalTools: ["run_command"]
        onApprovalNeeded: index => root.askApproval(index)
        maxTokens: Plasmoid.configuration.maxTokens
        temperature: Plasmoid.configuration.temperature
        searchCount: Plasmoid.configuration.webSearch && root.hasService ? Plasmoid.configuration.webResults : 0
        searchProvider: function (query, count, onResults, onError) {
            svc.call("WebSearch", [query, count], "(si)", function (text) {
                onResults(svc.parse(text, []));
            }, onError);
        }
        polling: root.expanded || root.windowed || root.starting || chatSession.serverState === "loading" || chatSession.busy
        queueUntilReady: root.starting || chatSession.serverState === "loading"

        onTurnFinished: root.turnFinished()
        onServerStateChanged: {
            if (serverState === "ready" || serverState === "loading") {
                root.startRequested = false;
                startTimeout.stop();
            }
        }
    }

    AssistantService {
        id: svc
        polling: root.expanded || root.windowed || root.starting || svc.setupState === "downloading"
        fastPolling: root.starting || svc.setupState === "downloading"

        onAvailableChanged: {
            if (available === true) {
                root.refreshChats();
                root.loadSharedSettings();
            } else if (available === false && Plasmoid.configuration.rememberChat && chatSession.messages.count === 0) {
                // No service: keep one chat in the widget's own config, as before.
                chatSession.importHistory(Plasmoid.configuration.history);
            }
        }
        onServerStateChanged: {
            // A stale "failed" from before this start does not count.
            if (serverState === "failed" && root.startRequested && Date.now() - root.startRequestedAt > 3000) {
                root.startRequested = false;
                startTimeout.stop();
                chatSession.failQueued("start", root.startError);
            }
        }
    }

    // ------------------------------------------------------------ the model

    // Send, starting the server first when it is ours and not running.
    function submit(text, images, files) {
        ensureServer();
        return chatSession.send(text, images, files);
    }

    function regenerate() {
        ensureServer();
        chatSession.regenerate();
    }

    function ensureServer() {
        if (canStart && !starting && svc.serverState !== "active"
                && (chatSession.serverState === "offline" || chatSession.serverState === "unknown")) {
            startServer();
        }
    }

    function startServer() {
        if (starting) {
            return;
        }
        startRequested = true;
        startRequestedAt = Date.now();
        startTimeout.restart();
        svc.startServer(function (error) {
            root.startRequested = false;
            chatSession.failQueued("start", error);
        });
    }

    function stopServer() {
        chatSession.stop();
        startRequested = false;
        svc.stopServer();
        chatSession.checkServer();
    }

    function download(quant, vision, autostart) {
        svc.download(quant, vision, autostart);
    }

    // Loading from a slow disk takes a while. Give up after ten minutes.
    Timer {
        id: startTimeout
        interval: 10 * 60 * 1000
        onTriggered: {
            root.startRequested = false;
            chatSession.failQueued("start", i18n("The model server did not become ready in time."));
        }
    }

    // ------------------------------------------------------------ tools

    readonly property string toolsPrompt: "\n\nYou can look up facts about this computer with system_info, and propose "
        + "a shell command with run_command when the lookups do not cover it; the user sees each command and decides "
        + "whether it runs. Use them for questions about this computer, and answer from what they return."

    readonly property var toolDefinitions: [
        {
            type: "function",
            function: {
                name: "system_info",
                description: "Read facts about this computer. Read-only; runs at once.",
                parameters: {
                    type: "object",
                    properties: {
                        topic: {
                            type: "string",
                            enum: ["os", "kernel", "cpu", "gpu", "memory", "disk", "uptime", "plasma", "package",
                                   "failed_services", "errors", "snapshots", "network", "processes"],
                            description: "plasma: Plasma, KDE Frameworks and Qt versions. package: one package's version. "
                                + "errors: error messages since boot. processes: the busiest processes.",
                        },
                        package: { type: "string", description: "The package name, for topic package." },
                    },
                    required: ["topic"],
                },
            },
        },
        {
            type: "function",
            function: {
                name: "run_command",
                description: "Run a shell command as the user, not root, from their home folder, after the user approves it. "
                    + "Use it only when system_info does not cover the question. Prefer commands that only read.",
                parameters: {
                    type: "object",
                    properties: {
                        command: { type: "string", description: "One bash command line." },
                        reason: { type: "string", description: "One short sentence the user sees: why it is needed." },
                    },
                    required: ["command", "reason"],
                },
            },
        },
    ]

    function runTool(name, args, done) {
        if (name === "system_info") {
            svc.call("SystemInfo", [String(args.topic || ""), String(args.package || "")], "(ss)", done, function (error) {
                done("Error: " + error);
            });
        } else if (name === "run_command") {
            svc.call("RunCommand", [String(args.command || "")], "(s)", function (text) {
                const r = svc.parse(text, {});
                done((r.timedOut ? "Timed out; stopped after " + r.seconds + " s." : "Exit code " + r.code + ".")
                    + (r.truncated ? " The output is shortened." : "") + "\n" + (r.output || "(no output)"));
            }, function (error) {
                done("Error: " + error);
            });
        } else {
            done("Error: there is no tool called " + name + ".");
        }
    }

    // A command waits for Run or Don't Run. Say so when nobody is looking.
    function askApproval(index) {
        const hidden = windowed ? !(fullRepresentationItem && fullRepresentationItem.Window.active) : !expanded;
        if (hidden) {
            const args = JSON.parse(chatSession.messages.get(index).toolArgs || "{}");
            answerNotification.title = i18nc("%1 is the model name", "%1 wants to run a command", chatSession.modelName || i18n("The model"));
            answerNotification.text = args.command || "";
            answerNotification.sendEvent();
        }
    }

    // ------------------------------------------------------------ chats

    function refreshChats() {
        // svc.available, not hasService: this runs from availableChanged,
        // before the hasService binding has caught up.
        if (svc.available !== true) {
            return;
        }
        svc.call("ListChats", [], "", function (text) {
            root.chats = svc.parse(text, []);
            if (chatSession.chatId && !chatSession.title) {
                const mine = root.chats.find(c => c.id === chatSession.chatId);
                if (mine) {
                    chatSession.title = mine.title;
                }
            }
        }, function () {});
    }

    // Save the open chat, then call then(id). An empty chat is not saved.
    function saveChat(then) {
        const chat = chatSession.toChat();
        if (!hasService) {
            Plasmoid.configuration.history = Plasmoid.configuration.rememberChat ? chatSession.exportHistory() : "";
            if (then) {
                then("");
            }
            return;
        }
        if (chat.messages.length === 0) {
            if (then) {
                then(chatSession.chatId);
            }
            return;
        }
        svc.call("SaveChat", [JSON.stringify(chat)], "(s)", function (id) {
            chatSession.chatId = id;
            chatSession.created = chat.created;
            root.refreshChats();
            if (then) {
                then(id);
            }
        });
    }

    function turnFinished() {
        saveChat();
        const seconds = chatSession.lastTurnDuration / 1000;
        const hidden = windowed ? !(fullRepresentationItem && fullRepresentationItem.Window.active) : !expanded;
        // A round that ended in tool calls is not the answer yet.
        if (hidden && seconds > 15 && !chatSession.busy) {
            let last = "";
            for (let i = chatSession.messages.count - 1; i >= 0; --i) {
                const m = chatSession.messages.get(i);
                if (m.role === "assistant" || m.role === "error") {
                    last = m.role === "error" ? i18n("The answer stopped with an error.") : m.content;
                    break;
                }
            }
            answerNotification.title = chatSession.title || chatSession.modelName || i18n("Assistant");
            answerNotification.text = last.length > 240 ? last.substring(0, 240) + "…" : last;
            answerNotification.sendEvent();
        }
    }

    function openChat(id, autoSend) {
        if (!id) {
            return;
        }
        svc.call("LoadChat", [id], "(s)", function (text) {
            const chat = svc.parse(text, null);
            if (!chat) {
                root.refreshChats();
                return;
            }
            chatSession.loadChat(chat);
            const count = chatSession.messages.count;
            if (autoSend && count > 0 && chatSession.messages.get(count - 1).role === "user") {
                root.regenerate();
            }
        });
    }

    function newChat() {
        if (chatSession.busy) {
            chatSession.stop();
        }
        chatSession.clear();
    }

    function deleteChat(id) {
        if (id === chatSession.chatId) {
            chatSession.clear();
        }
        svc.call("DeleteChat", [id], "(s)", refreshChats);
    }

    function renameChat(id, title) {
        title = title.trim();
        if (!title) {
            return;
        }
        if (!id || id === chatSession.chatId) {
            chatSession.title = title;
        }
        if (id) {
            svc.call("RenameChat", [id, title], "(ss)", refreshChats);
        } else {
            saveChat();
        }
    }

    function setFavorite(id, favorite) {
        if (!id || id === chatSession.chatId) {
            chatSession.favorite = favorite;
        }
        if (id) {
            svc.call("SetFavorite", [id, favorite], "(sb)", refreshChats);
        } else {
            saveChat();
        }
    }

    function duplicateChat(id) {
        svc.call("DuplicateChat", [id, -1], "(si)", function (newId) {
            root.refreshChats();
            root.openChat(newId);
        });
    }

    // A new chat with the messages up to and including index.
    function forkChat(index) {
        saveChat(function (id) {
            if (!id) {
                return;
            }
            svc.call("DuplicateChat", [id, index], "(si)", function (newId) {
                root.refreshChats();
                root.openChat(newId);
            });
        });
    }

    function exportChat(id, format, url) {
        const go = function (chatId) {
            svc.call("ExportChat", [chatId, format, String(url)], "(sss)", null, function (error) {
                svc.lastError = i18n("Could not export the chat: %1", error);
            });
        };
        if (!id || id === chatSession.chatId) {
            saveChat(go);
        } else {
            go(id);
        }
    }

    function importChat(url) {
        svc.call("ImportChat", [String(url)], "(s)", function (id) {
            root.refreshChats();
            root.openChat(id);
        }, function (error) {
            svc.lastError = i18n("Could not import the chat: %1", error);
        });
    }

    function readTextFile(url, then) {
        svc.call("ReadTextFile", [String(url)], "(s)", then, function (error) {
            svc.lastError = i18n("Could not attach the file: %1", error);
        });
    }

    function searchChats(query, then) {
        svc.call("SearchChats", [query], "(s)", function (text) {
            then(svc.parse(text, []));
        }, function () {
            then([]);
        });
    }

    function openInWindow() {
        const open = function (id) {
            svc.call("OpenWindow", [id || "", false], "(sb)");
            root.expanded = false;
        };
        if (chatSession.busy) {
            // Let this answer finish here; the window opens the chat as it stands.
            open(chatSession.chatId);
        } else {
            saveChat(open);
        }
    }

    function raiseWindow() {
        const w = fullRepresentationItem ? fullRepresentationItem.Window.window : null;
        if (w) {
            w.raise();
            w.requestActivate();
        }
    }

    // The Assistant window takes chats that KRunner or the panel asked it to open.
    Timer {
        interval: 1500
        repeat: true
        running: root.windowed && root.hasService
        triggeredOnStart: true
        onTriggered: svc.call("TakeRequest", [], "", function (text) {
            const request = svc.parse(text, null);
            if (request) {
                if (request.id) {
                    root.openChat(request.id, request.autoSend);
                }
                root.raiseWindow();
            }
        }, function () {})
    }

    // ------------------------------------------------------------ settings

    // KRunner and the Assistant window read these from the service, so the
    // panel widget and the window agree.
    readonly property string sharedSettings: JSON.stringify({
        useLocal: Plasmoid.configuration.useLocal,
        remoteUrl: Plasmoid.configuration.remoteUrl,
        remoteModel: Plasmoid.configuration.remoteModel,
        reasoningEffort: Plasmoid.configuration.reasoningEffort,
        systemPrompt: Plasmoid.configuration.systemPrompt,
        maxTokens: Plasmoid.configuration.maxTokens,
        temperature: Plasmoid.configuration.temperature,
        showThinking: Plasmoid.configuration.showThinking,
        webSearch: Plasmoid.configuration.webSearch,
        webResults: Plasmoid.configuration.webResults,
        tools: Plasmoid.configuration.tools,
    })
    property bool sharedSettingsLoaded: false

    onSharedSettingsChanged: {
        if (sharedSettingsLoaded && hasService) {
            svc.call("SetSettings", [sharedSettings], "(s)", null, function () {});
        }
    }

    function loadSharedSettings() {
        svc.call("GetSettings", [], "", function (text) {
            const stored = svc.parse(text, null);
            if (stored) {
                for (const key in stored) {
                    if (Plasmoid.configuration[key] !== undefined && Plasmoid.configuration[key] !== stored[key]) {
                        Plasmoid.configuration[key] = stored[key];
                    }
                }
            }
            root.sharedSettingsLoaded = true;
            svc.call("SetSettings", [root.sharedSettings], "(s)", null, function () {});
        }, function () {
            root.sharedSettingsLoaded = true;
        });
    }

    // ------------------------------------------------------------ notification

    Notification {
        id: answerNotification
        componentName: "atropos-assistant"
        eventId: "answerReady"
        iconName: "dialog-messages"
        defaultAction: NotificationAction {
            label: i18n("Open")
            onActivated: {
                if (root.windowed) {
                    root.raiseWindow();
                } else {
                    root.expanded = true;
                }
            }
        }
    }

    // ------------------------------------------------------------ representations

    compactRepresentation: CompactRepresentation {
        plasmoidItem: root
        session: chatSession
    }

    fullRepresentation: FullRepresentation {
        plasmoidItem: root
        session: chatSession
        service: svc
    }

    Plasmoid.contextualActions: [
        PlasmaCore.Action {
            text: i18n("New Chat")
            icon.name: "document-new"
            enabled: chatSession.messages.count > 0
            onTriggered: root.newChat()
        },
        PlasmaCore.Action {
            text: i18n("Open in Window")
            icon.name: "window-new"
            visible: !root.windowed && root.hasService
            onTriggered: root.openInWindow()
        },
        PlasmaCore.Action {
            text: i18n("Start Model")
            icon.name: "media-playback-start"
            visible: root.managed
            enabled: root.canStart && !root.starting && svc.serverState !== "active"
            onTriggered: root.startServer()
        },
        PlasmaCore.Action {
            text: i18n("Stop Model and Free Memory")
            icon.name: "media-playback-stop"
            visible: root.managed
            enabled: svc.serverState === "active" || svc.serverState === "activating" || root.starting
            onTriggered: root.stopServer()
        }
    ]

    Component.onCompleted: {
        svc.refresh();
        chatSession.checkServer();
    }
}
