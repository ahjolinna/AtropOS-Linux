// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later

import QtQuick
import QtQuick.Layouts

import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents3

import "../code/protocol.js" as Protocol

Item {
    id: msg

    required property int index
    required property string role
    required property string kind
    required property string content
    required property string thinking
    required property string images
    required property int imageCount
    required property string files
    required property string sources
    required property string searchNote
    required property string toolCallId
    required property string toolName
    required property string toolArgs
    required property string toolState
    required property bool streaming
    required property real thinkSeconds
    required property real tokens
    required property real tokensPerSecond
    required property string finishReason

    property bool showThinking: true
    property bool isLast: false
    property bool isLastUser: false
    property bool canEdit: false
    property bool canFork: false
    property bool searching: false
    property string serverUrl: ""

    signal copyRequested(string text)
    signal regenerateRequested()
    signal editRequested()
    signal forkRequested()
    signal approveRequested()
    signal denyRequested()

    implicitHeight: loader.implicitHeight

    Loader {
        id: loader
        width: parent.width
        sourceComponent: msg.role === "user" ? userComponent
            : msg.role === "error" ? errorComponent
            : msg.role === "tool" ? toolComponent
            : assistantComponent
    }

    component SmallButton: PlasmaComponents3.ToolButton {
        icon.width: Kirigami.Units.iconSizes.small
        icon.height: Kirigami.Units.iconSizes.small
        display: PlasmaComponents3.AbstractButton.IconOnly
        PlasmaComponents3.ToolTip.text: text
        PlasmaComponents3.ToolTip.visible: hovered
        PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
    }

    Component {
        id: userComponent

        Item {
            id: userItem
            implicitHeight: bubble.height + (editRow.visible ? editRow.height : 0)

            readonly property var fileList: JSON.parse(msg.files || "[]")
            readonly property var sourceList: JSON.parse(msg.sources || "[]")

            HoverHandler {
                id: userHover
            }

            Rectangle {
                id: bubble

                readonly property real padding: Kirigami.Units.largeSpacing
                readonly property real maxWidth: Math.round(msg.width * 0.85)

                anchors.right: parent.right
                width: Math.min(maxWidth, Math.max(userText.implicitWidth, thumbs.implicitWidth, fileChips.implicitWidth,
                                                   webColumn.visible ? webColumn.implicitWidth : 0) + 2 * padding)
                height: column.implicitHeight + 2 * padding
                radius: Kirigami.Units.cornerRadius
                color: Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g,
                               Kirigami.Theme.highlightColor.b, 0.18)
                border.width: 1
                border.color: Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g,
                                      Kirigami.Theme.highlightColor.b, 0.35)

                ColumnLayout {
                    id: column
                    x: bubble.padding
                    y: bubble.padding
                    width: bubble.width - 2 * bubble.padding
                    spacing: Kirigami.Units.smallSpacing

                    Flow {
                        id: thumbs
                        Layout.fillWidth: true
                        visible: msg.imageCount > 0
                        spacing: Kirigami.Units.smallSpacing

                        readonly property var urls: JSON.parse(msg.images || "[]")

                        Repeater {
                            model: thumbs.urls
                            delegate: Image {
                                required property string modelData
                                width: Kirigami.Units.gridUnit * 4
                                height: width
                                source: modelData
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                smooth: true
                            }
                        }

                        // Images from a chat saved without them.
                        PlasmaComponents3.Label {
                            visible: thumbs.urls.length === 0
                            text: i18np("1 image", "%1 images", msg.imageCount)
                            opacity: 0.7
                            font: Kirigami.Theme.smallFont
                        }
                    }

                    Flow {
                        id: fileChips
                        Layout.fillWidth: true
                        visible: userItem.fileList.length > 0
                        spacing: Kirigami.Units.smallSpacing

                        Repeater {
                            model: userItem.fileList
                            delegate: RowLayout {
                                required property var modelData
                                spacing: Kirigami.Units.smallSpacing
                                Kirigami.Icon {
                                    source: "text-x-generic"
                                    Layout.preferredWidth: Kirigami.Units.iconSizes.small
                                    Layout.preferredHeight: Kirigami.Units.iconSizes.small
                                }
                                PlasmaComponents3.Label {
                                    text: modelData.name
                                    font: Kirigami.Theme.smallFont
                                }
                            }
                        }
                    }

                    TextEdit {
                        id: userText
                        Layout.fillWidth: true
                        visible: msg.content.length > 0
                        text: msg.content
                        readOnly: true
                        selectByMouse: true
                        wrapMode: TextEdit.Wrap
                        textFormat: TextEdit.PlainText
                        color: Kirigami.Theme.textColor
                        selectionColor: Kirigami.Theme.highlightColor
                        selectedTextColor: Kirigami.Theme.highlightedTextColor
                        font: Kirigami.Theme.defaultFont
                    }

                    // What the web search found, or that it is still searching.
                    ColumnLayout {
                        id: webColumn
                        Layout.fillWidth: true
                        visible: msg.searching || userItem.sourceList.length > 0 || msg.searchNote.length > 0
                        spacing: 0

                        RowLayout {
                            spacing: Kirigami.Units.smallSpacing
                            PlasmaComponents3.BusyIndicator {
                                visible: msg.searching
                                running: visible
                                Layout.preferredWidth: Kirigami.Units.iconSizes.small
                                Layout.preferredHeight: Kirigami.Units.iconSizes.small
                            }
                            Kirigami.Icon {
                                visible: !msg.searching
                                source: "globe"
                                Layout.preferredWidth: Kirigami.Units.iconSizes.small
                                Layout.preferredHeight: Kirigami.Units.iconSizes.small
                            }
                            PlasmaComponents3.Label {
                                font: Kirigami.Theme.smallFont
                                opacity: 0.8
                                text: msg.searching ? i18n("Searching DuckDuckGo…")
                                    : userItem.sourceList.length > 0 && userItem.sourceList[0].kind === "instant"
                                        ? i18np("1 instant answer (DuckDuckGo is limiting web results for now)",
                                                "%1 instant answers (DuckDuckGo is limiting web results for now)", userItem.sourceList.length)
                                    : userItem.sourceList.length > 0 ? i18np("1 web result", "%1 web results", userItem.sourceList.length)
                                    : msg.searchNote === "none" ? i18n("The web search found nothing")
                                    : i18n("The web search failed: %1", msg.searchNote)
                            }
                        }

                        Repeater {
                            model: userItem.sourceList
                            delegate: PlasmaComponents3.Label {
                                required property var modelData
                                required property int index
                                Layout.fillWidth: true
                                Layout.maximumWidth: Kirigami.Units.gridUnit * 22
                                font: Kirigami.Theme.smallFont
                                elide: Text.ElideRight
                                textFormat: Text.StyledText
                                linkColor: Kirigami.Theme.linkColor
                                text: "[" + (index + 1) + "] <a href=\"" + modelData.url.replace(/"/g, "%22") + "\">"
                                    + modelData.title.replace(/&/g, "&amp;").replace(/</g, "&lt;") + "</a> · "
                                    + (modelData.url.split("/")[2] || "")
                                onLinkActivated: link => Qt.openUrlExternally(link)

                                HoverHandler {
                                    cursorShape: parent.hoveredLink ? Qt.PointingHandCursor : Qt.ArrowCursor
                                }
                            }
                        }
                    }
                }
            }

            RowLayout {
                id: editRow
                anchors.top: bubble.bottom
                anchors.right: parent.right
                spacing: 0
                visible: msg.canEdit && msg.isLastUser

                SmallButton {
                    icon.name: "document-edit"
                    text: i18n("Edit")
                    onClicked: msg.editRequested()
                }
                SmallButton {
                    icon.name: "edit-copy"
                    text: i18n("Copy")
                    enabled: msg.content.length > 0
                    onClicked: msg.copyRequested(msg.content)
                }
            }
        }
    }

    Component {
        id: assistantComponent

        ColumnLayout {
            id: answer
            spacing: Kirigami.Units.smallSpacing

            property bool userToggled: false
            property bool userExpanded: false
            readonly property bool waiting: msg.streaming && msg.content.length === 0
            readonly property bool thinkingExpanded: msg.showThinking && msg.thinking.length > 0
                && (userToggled ? userExpanded : waiting)
            readonly property var segments: Protocol.splitMarkdown(msg.content)

            RowLayout {
                Layout.fillWidth: true
                spacing: Kirigami.Units.smallSpacing
                visible: answer.waiting || (msg.showThinking && msg.thinking.length > 0)

                PlasmaComponents3.BusyIndicator {
                    Layout.preferredWidth: Kirigami.Units.iconSizes.small
                    Layout.preferredHeight: Kirigami.Units.iconSizes.small
                    visible: answer.waiting
                    running: visible
                }

                PlasmaComponents3.ToolButton {
                    id: thinkingToggle
                    visible: msg.showThinking && msg.thinking.length > 0
                    flat: true
                    icon.width: Kirigami.Units.iconSizes.small
                    icon.height: Kirigami.Units.iconSizes.small
                    icon.name: answer.thinkingExpanded ? "arrow-down" : (Qt.locale().textDirection === Qt.RightToLeft ? "arrow-left" : "arrow-right")
                    text: answer.waiting ? i18n("Thinking…")
                        : msg.thinkSeconds >= 0 ? i18np("Thought for 1 second", "Thought for %1 seconds", Math.max(1, Math.round(msg.thinkSeconds)))
                        : i18n("Thoughts")
                    font: Kirigami.Theme.smallFont
                    onClicked: {
                        answer.userExpanded = !answer.thinkingExpanded;
                        answer.userToggled = true;
                    }
                }

                PlasmaComponents3.Label {
                    visible: answer.waiting && !thinkingToggle.visible
                    text: i18n("Thinking…")
                    opacity: 0.7
                    font: Kirigami.Theme.smallFont
                }

                Item { Layout.fillWidth: true }
            }

            Item {
                Layout.fillWidth: true
                visible: answer.thinkingExpanded
                implicitHeight: thinkingText.implicitHeight + 2 * Kirigami.Units.smallSpacing

                Rectangle {
                    width: 2
                    height: parent.height
                    color: Kirigami.Theme.disabledTextColor
                    opacity: 0.5
                }

                TextEdit {
                    id: thinkingText
                    x: Kirigami.Units.largeSpacing
                    y: Kirigami.Units.smallSpacing
                    width: parent.width - x
                    text: msg.thinking.trim()
                    readOnly: true
                    selectByMouse: true
                    wrapMode: TextEdit.Wrap
                    textFormat: TextEdit.PlainText
                    color: Kirigami.Theme.disabledTextColor
                    selectionColor: Kirigami.Theme.highlightColor
                    selectedTextColor: Kirigami.Theme.highlightedTextColor
                    font: Kirigami.Theme.smallFont
                }
            }

            // Prose as Markdown; fenced code in its own box with a copy button.
            // The Repeater counts segments, so growing text does not rebuild them.
            Repeater {
                model: answer.segments.length

                delegate: Loader {
                    required property int index
                    readonly property var part: answer.segments[index] || ({ code: false, lang: "", text: "" })
                    Layout.fillWidth: true
                    sourceComponent: part.code ? codeComponent : proseComponent
                }
            }

            Component {
                id: proseComponent

                TextEdit {
                    id: prose
                    text: parent ? parent.part.text : ""
                    readOnly: true
                    selectByMouse: true
                    wrapMode: TextEdit.Wrap
                    textFormat: TextEdit.MarkdownText
                    color: Kirigami.Theme.textColor
                    selectionColor: Kirigami.Theme.highlightColor
                    selectedTextColor: Kirigami.Theme.highlightedTextColor
                    font: Kirigami.Theme.defaultFont
                    onLinkActivated: link => Qt.openUrlExternally(link)

                    HoverHandler {
                        cursorShape: prose.hoveredLink ? Qt.PointingHandCursor : Qt.IBeamCursor
                    }
                }
            }

            Component {
                id: codeComponent

                Rectangle {
                    id: codeBox
                    readonly property var part: parent ? parent.part : ({ lang: "", text: "" })
                    implicitHeight: codeColumn.implicitHeight + Kirigami.Units.smallSpacing * 2
                    radius: Kirigami.Units.cornerRadius
                    color: Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.07)
                    border.width: 1
                    border.color: Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.12)

                    ColumnLayout {
                        id: codeColumn
                        x: Kirigami.Units.smallSpacing
                        y: Kirigami.Units.smallSpacing
                        width: codeBox.width - 2 * Kirigami.Units.smallSpacing
                        spacing: 0

                        RowLayout {
                            Layout.fillWidth: true
                            PlasmaComponents3.Label {
                                Layout.fillWidth: true
                                Layout.leftMargin: Kirigami.Units.smallSpacing
                                text: codeBox.part.lang
                                opacity: 0.6
                                font: Kirigami.Theme.smallFont
                            }
                            SmallButton {
                                icon.name: "edit-copy"
                                text: i18n("Copy Code")
                                onClicked: msg.copyRequested(codeBox.part.text)
                            }
                        }

                        TextEdit {
                            Layout.fillWidth: true
                            Layout.margins: Kirigami.Units.smallSpacing
                            text: codeBox.part.text
                            readOnly: true
                            selectByMouse: true
                            wrapMode: TextEdit.WrapAnywhere
                            textFormat: TextEdit.PlainText
                            color: Kirigami.Theme.textColor
                            selectionColor: Kirigami.Theme.highlightColor
                            selectedTextColor: Kirigami.Theme.highlightedTextColor
                            font.family: "monospace"
                            font.pointSize: Kirigami.Theme.defaultFont.pointSize
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                visible: !msg.streaming
                spacing: 0

                PlasmaComponents3.Label {
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                    opacity: 0.6
                    font: Kirigami.Theme.smallFont
                    text: {
                        const parts = [];
                        if (msg.tokens > 0) {
                            parts.push(i18np("1 token", "%1 tokens", msg.tokens));
                        }
                        if (msg.tokensPerSecond > 0) {
                            parts.push(i18nc("tokens per second", "%1 tok/s", msg.tokensPerSecond.toFixed(1)));
                        }
                        if (msg.thinkSeconds >= 0 && !msg.showThinking) {
                            parts.push(i18np("thought for 1 second", "thought for %1 seconds", Math.max(1, Math.round(msg.thinkSeconds))));
                        }
                        if (msg.finishReason === "length") {
                            parts.push(i18n("stopped at the length limit"));
                        } else if (msg.finishReason === "stopped") {
                            parts.push(i18n("stopped"));
                        }
                        return parts.join(" · ");
                    }
                }

                SmallButton {
                    icon.name: "edit-copy"
                    text: i18n("Copy")
                    enabled: msg.content.length > 0
                    onClicked: msg.copyRequested(msg.content)
                }

                SmallButton {
                    visible: msg.canFork
                    icon.name: "split"
                    text: i18n("Fork Chat Here")
                    onClicked: msg.forkRequested()
                }

                SmallButton {
                    visible: msg.isLast
                    icon.name: "view-refresh"
                    text: i18n("Answer Again")
                    onClicked: msg.regenerateRequested()
                }
            }
        }
    }

    // A tool step: a read-only lookup, or a command waiting for Run.
    Component {
        id: toolComponent

        Rectangle {
            id: card

            readonly property var args: JSON.parse(msg.toolArgs || "{}")
            readonly property bool isCommand: msg.toolName === "run_command"
            readonly property bool failed: isCommand && msg.toolState === "done" && !/^Exit code 0\./.test(msg.content)
            property bool showOutput: false

            readonly property string topic: {
                switch (args.topic) {
                case "os": return i18nc("system_info topic", "the operating system");
                case "kernel": return i18nc("system_info topic", "the kernel");
                case "cpu": return i18nc("system_info topic", "the processor");
                case "gpu": return i18nc("system_info topic", "the graphics card");
                case "memory": return i18nc("system_info topic", "the memory");
                case "disk": return i18nc("system_info topic", "the disks");
                case "uptime": return i18nc("system_info topic", "the uptime");
                case "plasma": return i18nc("system_info topic", "the Plasma and KDE versions");
                case "package": return i18nc("system_info topic, %1 is a package", "the package %1", args.package || "");
                case "failed_services": return i18nc("system_info topic", "for failed services");
                case "errors": return i18nc("system_info topic", "for recent errors");
                case "snapshots": return i18nc("system_info topic", "the snapshots");
                case "network": return i18nc("system_info topic", "the network");
                case "processes": return i18nc("system_info topic", "the busiest processes");
                default: return String(args.topic || "");
                }
            }

            implicitHeight: cardColumn.implicitHeight + 2 * Kirigami.Units.smallSpacing
            radius: Kirigami.Units.cornerRadius
            color: Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.05)
            border.width: msg.toolState === "approval" ? 2 : 1
            border.color: msg.toolState === "approval" ? Kirigami.Theme.neutralTextColor
                : Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.12)

            ColumnLayout {
                id: cardColumn
                x: Kirigami.Units.largeSpacing
                y: Kirigami.Units.smallSpacing
                width: card.width - 2 * Kirigami.Units.largeSpacing
                spacing: Kirigami.Units.smallSpacing

                RowLayout {
                    Layout.fillWidth: true
                    spacing: Kirigami.Units.smallSpacing

                    Kirigami.Icon {
                        source: card.isCommand ? "utilities-terminal" : "dialog-information"
                        Layout.preferredWidth: Kirigami.Units.iconSizes.small
                        Layout.preferredHeight: Kirigami.Units.iconSizes.small
                    }
                    PlasmaComponents3.Label {
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        font: Kirigami.Theme.smallFont
                        text: {
                            if (!card.isCommand) {
                                return msg.toolState === "running" ? i18nc("%1 is what it looks at", "Checking %1…", card.topic)
                                    : msg.toolState === "denied" ? i18nc("%1 is what it looks at", "Did not check %1", card.topic)
                                    : i18nc("%1 is what it looks at", "Checked %1", card.topic);
                            }
                            switch (msg.toolState) {
                            case "approval":
                                return i18n("The model wants to run this command:");
                            case "running":
                                return i18n("Running…");
                            case "denied":
                                return i18n("Not run");
                            default:
                                return card.failed ? i18n("Ran the command; it reported a problem") : i18n("Ran the command");
                            }
                        }
                    }
                    PlasmaComponents3.BusyIndicator {
                        visible: msg.toolState === "running"
                        running: visible
                        Layout.preferredWidth: Kirigami.Units.iconSizes.small
                        Layout.preferredHeight: Kirigami.Units.iconSizes.small
                    }
                    SmallButton {
                        visible: msg.toolState === "done" && msg.content.length > 0
                        icon.name: card.showOutput ? "arrow-up" : "arrow-down"
                        text: card.showOutput ? i18n("Hide Output") : i18n("Show Output")
                        onClicked: card.showOutput = !card.showOutput
                    }
                }

                TextEdit {
                    Layout.fillWidth: true
                    visible: card.isCommand
                    text: card.args.command || ""
                    readOnly: true
                    selectByMouse: true
                    wrapMode: TextEdit.WrapAnywhere
                    textFormat: TextEdit.PlainText
                    color: Kirigami.Theme.textColor
                    selectionColor: Kirigami.Theme.highlightColor
                    selectedTextColor: Kirigami.Theme.highlightedTextColor
                    font.family: "monospace"
                    font.pointSize: Kirigami.Theme.defaultFont.pointSize
                }

                PlasmaComponents3.Label {
                    Layout.fillWidth: true
                    visible: card.isCommand && !!card.args.reason
                    wrapMode: Text.Wrap
                    font: Kirigami.Theme.smallFont
                    opacity: 0.7
                    text: card.args.reason || ""
                }

                RowLayout {
                    Layout.fillWidth: true
                    visible: msg.toolState === "approval"
                    spacing: Kirigami.Units.smallSpacing

                    PlasmaComponents3.Label {
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        font: Kirigami.Theme.smallFont
                        opacity: 0.7
                        text: i18n("It runs as you, with access to your files.")
                    }
                    PlasmaComponents3.Button {
                        icon.name: "dialog-cancel"
                        text: i18n("Don't Run")
                        onClicked: msg.denyRequested()
                    }
                    PlasmaComponents3.Button {
                        icon.name: "media-playback-start"
                        text: i18n("Run")
                        onClicked: msg.approveRequested()
                    }
                }

                TextEdit {
                    Layout.fillWidth: true
                    visible: card.showOutput
                    text: msg.content
                    readOnly: true
                    selectByMouse: true
                    wrapMode: TextEdit.WrapAnywhere
                    textFormat: TextEdit.PlainText
                    color: Kirigami.Theme.textColor
                    opacity: 0.85
                    selectionColor: Kirigami.Theme.highlightColor
                    selectedTextColor: Kirigami.Theme.highlightedTextColor
                    font.family: "monospace"
                    font.pointSize: Kirigami.Theme.smallFont.pointSize
                }
            }
        }
    }

    Component {
        id: errorComponent

        Kirigami.InlineMessage {
            visible: true
            type: Kirigami.MessageType.Error
            text: {
                switch (msg.kind) {
                case "unreachable":
                    return i18n("Could not reach the model server at %1.", msg.serverUrl);
                case "loading":
                    return i18n("The model is still loading. Try again in a moment.");
                case "start":
                    return msg.content ? i18n("The model server could not start: %1", msg.content)
                                       : i18n("The model server could not start.");
                case "stream":
                    return i18n("The answer stopped with an error: %1", msg.content);
                default:
                    return i18n("The model server returned an error: %1", msg.content);
                }
            }
            actions: [
                Kirigami.Action {
                    visible: msg.isLast
                    text: i18n("Try Again")
                    icon.name: "view-refresh"
                    onTriggered: msg.regenerateRequested()
                }
            ]
        }
    }
}
