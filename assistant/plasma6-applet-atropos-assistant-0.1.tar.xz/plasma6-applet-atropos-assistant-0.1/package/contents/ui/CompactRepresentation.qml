// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later

import QtQuick

import org.kde.kirigami as Kirigami
import org.kde.plasma.plasmoid

MouseArea {
    id: compact

    required property var plasmoidItem
    required property ChatSession session

    property bool wasExpanded: false

    hoverEnabled: true
    acceptedButtons: Qt.LeftButton | Qt.MiddleButton

    onPressed: mouse => {
        wasExpanded = plasmoidItem.expanded;
    }
    onClicked: mouse => {
        if (mouse.button === Qt.MiddleButton) {
            session.clear();
            plasmoidItem.expanded = true;
        } else {
            plasmoidItem.expanded = !wasExpanded;
        }
    }

    Kirigami.Icon {
        anchors.fill: parent
        source: Plasmoid.icon
        active: compact.containsMouse
    }

    // A small dot while the model is answering or loading.
    Rectangle {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        width: Math.max(4, Math.round(parent.width / 4))
        height: width
        radius: width / 2
        visible: compact.session.generating || compact.session.serverState === "loading" || compact.plasmoidItem.starting
        color: compact.session.generating ? Kirigami.Theme.positiveTextColor : Kirigami.Theme.neutralTextColor

        SequentialAnimation on opacity {
            running: parent.visible
            loops: Animation.Infinite
            NumberAnimation { to: 0.3; duration: 700; easing.type: Easing.InOutQuad }
            NumberAnimation { to: 1.0; duration: 700; easing.type: Easing.InOutQuad }
        }
    }
}
