// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later

import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts

import org.kde.coreaddons as KCoreAddons
import org.kde.kcmutils as KCM
import org.kde.kirigami as Kirigami
import org.kde.plasma.workspace.dbus as DBus

KCM.SimpleKCM {
    id: page

    property alias cfg_useLocal: localButton.checked
    property alias cfg_remoteUrl: urlField.text
    property alias cfg_remoteModel: modelField.text
    property string cfg_reasoningEffort
    property alias cfg_systemPrompt: promptArea.text
    property alias cfg_maxTokens: maxTokensBox.value
    property real cfg_temperature
    property alias cfg_manageServer: manageBox.checked
    property alias cfg_showThinking: thinkingBox.checked
    property alias cfg_rememberChat: rememberBox.checked
    property alias cfg_tools: toolsBox.checked
    property alias cfg_webSearch: webBox.checked
    property alias cfg_webResults: webResultsBox.value

    // From the Assistant service: { file, size, vision }, or null.
    property var localModel: null
    // null until asked, then whether the service answered.
    property var serviceThere: null

    Component.onCompleted: {
        DBus.SessionBus.asyncCall({
            service: "org.atropos.Assistant",
            path: "/org/atropos/Assistant",
            iface: "org.atropos.Assistant1",
            member: "Status",
        }, function (reply) {
            try {
                page.localModel = JSON.parse(reply.value).localModel || null;
            } catch (e) {
                page.localModel = null;
            }
            page.serviceThere = true;
        }, function () {
            page.serviceThere = false;
        });
    }

    Kirigami.FormLayout {
        QQC2.ButtonGroup {
            id: whereGroup
        }

        QQC2.RadioButton {
            id: localButton
            Kirigami.FormData.label: i18n("Model:")
            QQC2.ButtonGroup.group: whereGroup
            text: i18n("Inkling 2 Mini on this computer")
        }

        QQC2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: Kirigami.Units.gridUnit * 24
            leftPadding: localButton.indicator ? localButton.indicator.width + localButton.spacing : 0
            visible: localButton.checked
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: {
                const m = page.localModel;
                if (m && m.file) {
                    const size = KCoreAddons.Format.formatByteSize(m.size, 1);
                    return m.vision ? i18nc("model file, size", "Downloaded: %1, %2, with image understanding.", m.file, size)
                                    : i18nc("model file, size", "Downloaded: %1, %2.", m.file, size);
                }
                if (page.serviceThere === false) {
                    return i18n("The Assistant service is not installed, so the widget cannot download or start the model.");
                }
                return page.serviceThere ? i18n("Not downloaded yet. The widget offers the download.") : "";
            }
        }

        QQC2.CheckBox {
            id: manageBox
            visible: localButton.checked
            leftPadding: localButton.indicator ? localButton.indicator.width + localButton.spacing : 0
            text: i18n("Start and stop it from the widget")
        }

        QQC2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: Kirigami.Units.gridUnit * 24
            leftPadding: localButton.indicator ? localButton.indicator.width + localButton.spacing : 0
            visible: localButton.checked
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: i18n("Sending a message starts it. It unloads after 30 minutes without a message and loads again with the next one.")
        }

        QQC2.RadioButton {
            id: remoteButton
            QQC2.ButtonGroup.group: whereGroup
            checked: !localButton.checked
            text: i18n("Another server")
        }

        QQC2.TextField {
            id: urlField
            Kirigami.FormData.label: i18n("Address:")
            Layout.fillWidth: true
            visible: remoteButton.checked
            placeholderText: "http://192.168.1.20:8080"
        }

        QQC2.TextField {
            id: modelField
            Kirigami.FormData.label: i18n("Model name:")
            Layout.fillWidth: true
            visible: remoteButton.checked
            placeholderText: i18n("The model the server has loaded")
        }

        QQC2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: Kirigami.Units.gridUnit * 24
            visible: remoteButton.checked
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: i18n("Any server with an OpenAI-compatible chat API, such as llama-server, LM Studio or vLLM, running Inkling 2 Mini or another model.")
        }

        Item {
            Kirigami.FormData.isSection: true
        }

        QQC2.ComboBox {
            id: effortBox
            Kirigami.FormData.label: i18n("Thinking:")
            readonly property var efforts: [
                { value: "minimal", text: i18nc("thinking effort", "Minimal") },
                { value: "low", text: i18nc("thinking effort", "Low") },
                { value: "medium", text: i18nc("thinking effort", "Medium") },
                { value: "high", text: i18nc("thinking effort", "High") },
                { value: "xhigh", text: i18nc("thinking effort", "Extra High") },
                { value: "max", text: i18nc("thinking effort", "Maximum") },
            ]
            textRole: "text"
            valueRole: "value"
            model: efforts
            currentIndex: Math.max(0, efforts.findIndex(e => e.value === page.cfg_reasoningEffort))
            onActivated: page.cfg_reasoningEffort = currentValue
        }

        QQC2.CheckBox {
            id: thinkingBox
            text: i18n("Show the model's thinking")
        }

        QQC2.SpinBox {
            id: maxTokensBox
            Kirigami.FormData.label: i18n("Longest answer:")
            from: 256
            to: 131072
            stepSize: 1024
            editable: true
            textFromValue: (value, locale) => i18np("%1 token", "%1 tokens", value)
            valueFromText: (text, locale) => parseInt(text.replace(/[^0-9]/g, "")) || 8192
        }

        QQC2.SpinBox {
            id: temperatureBox
            Kirigami.FormData.label: i18n("Temperature:")
            from: 0
            to: 200
            stepSize: 5
            editable: true
            value: Math.round(page.cfg_temperature * 100)
            textFromValue: (value, locale) => Number(value / 100).toLocaleString(locale, "f", 2)
            valueFromText: (text, locale) => Math.round(Number.fromLocaleString(locale, text) * 100)
            onValueModified: page.cfg_temperature = value / 100
        }

        QQC2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: Kirigami.Units.gridUnit * 24
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: i18n("Thinking Machines recommend 1.0 for Inkling 2 Mini.")
        }

        Item {
            Kirigami.FormData.isSection: true
        }

        QQC2.CheckBox {
            id: toolsBox
            Kirigami.FormData.label: i18n("This computer:")
            text: i18n("Let the model look things up and propose commands")
        }

        QQC2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: Kirigami.Units.gridUnit * 24
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: i18n("Lookups such as memory, disks, versions or failed services run at once; they only read, and nothing leaves the computer. A command the model proposes runs only after you press Run, as you and not as root.")
        }

        QQC2.CheckBox {
            id: webBox
            Kirigami.FormData.label: i18n("Web search:")
            text: i18n("Search DuckDuckGo before each new question")
        }

        QQC2.SpinBox {
            id: webResultsBox
            Kirigami.FormData.label: i18n("Results:")
            enabled: webBox.checked
            from: 3
            to: 5
        }

        QQC2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: Kirigami.Units.gridUnit * 24
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: i18n("When it is on, your question goes to DuckDuckGo, and the titles, links and snippets of the top results go to the model with it. Answers cite them as [1], [2]. More results mean more for the model to read before it answers. The Web button under the chat switches it too.")
        }

        Item {
            Kirigami.FormData.isSection: true
        }

        QQC2.ScrollView {
            Kirigami.FormData.label: i18n("Instructions:")
            Layout.fillWidth: true
            Layout.minimumWidth: Kirigami.Units.gridUnit * 20
            Layout.preferredHeight: Kirigami.Units.gridUnit * 6

            QQC2.TextArea {
                id: promptArea
                wrapMode: TextEdit.Wrap
                placeholderText: i18n("A system prompt sent before every conversation")
            }
        }

        QQC2.CheckBox {
            id: rememberBox
            text: i18n("Without the Assistant service, keep the last chat after a restart")
        }

        QQC2.Label {
            Layout.fillWidth: true
            Layout.maximumWidth: Kirigami.Units.gridUnit * 24
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: i18n("With the service, every chat is saved in ~/.local/share/atropos-assistant/chats and shared with the Assistant window. In KRunner, type “ai” and a question; Enter answers in a notification. These settings apply there too.")
        }
    }
}
