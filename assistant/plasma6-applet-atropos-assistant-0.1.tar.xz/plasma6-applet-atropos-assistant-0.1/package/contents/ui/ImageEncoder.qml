// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later
//
// Turns an image file into a data: URL, scaled so its longest side is at
// most maxSide. QML cannot read files into base64 on its own; Canvas can.
// PNG stays PNG so screenshots keep sharp text. Everything else becomes JPEG.

import QtQuick

Canvas {
    id: encoder

    property int maxSide: 1536
    readonly property bool working: _current !== "" || _queue.length > 0

    signal encoded(string source, string dataUrl)
    signal failed(string source)

    property var _queue: []
    property string _current: ""
    property string _type: "image/jpeg"
    property bool _drawPending: false

    width: 1
    height: 1
    opacity: 0
    z: -1
    renderStrategy: Canvas.Immediate
    renderTarget: Canvas.Image

    function add(url) {
        _queue = _queue.concat([String(url)]);
        _next();
    }

    function _next() {
        if (_current !== "" || _queue.length === 0) {
            return;
        }
        _current = _queue[0];
        _queue = _queue.slice(1);
        _type = /\.png$/i.test(_current) ? "image/png" : "image/jpeg";
        if (isImageLoaded(_current) || isImageError(_current)) {
            _draw();
        } else {
            loadImage(_current);
        }
    }

    onImageLoaded: {
        if (_current !== "" && !_drawPending && (isImageLoaded(_current) || isImageError(_current))) {
            _draw();
        }
    }

    function _draw() {
        if (isImageError(_current)) {
            _fail();
            return;
        }
        const data = getContext("2d").createImageData(_current);
        if (!data || data.width <= 0 || data.height <= 0) {
            _fail();
            return;
        }
        const scale = Math.min(1, maxSide / Math.max(data.width, data.height));
        width = Math.max(1, Math.round(data.width * scale));
        height = Math.max(1, Math.round(data.height * scale));
        _drawPending = true;
        requestPaint();
    }

    onPaint: {
        if (!_drawPending) {
            return;
        }
        const ctx = getContext("2d");
        ctx.reset();
        if (_type === "image/jpeg") {
            // JPEG has no alpha. Put transparent areas on white, not black.
            ctx.fillStyle = "white";
            ctx.fillRect(0, 0, width, height);
        }
        ctx.drawImage(_current, 0, 0, width, height);
    }

    onPainted: {
        if (!_drawPending) {
            return;
        }
        _drawPending = false;
        const url = toDataURL(_type);
        const source = _current;
        unloadImage(source);
        _current = "";
        width = 1;
        height = 1;
        if (url && url.length > 32) {
            encoded(source, url);
        } else {
            failed(source);
        }
        Qt.callLater(_next);
    }

    function _fail() {
        const source = _current;
        unloadImage(source);
        _current = "";
        failed(source);
        Qt.callLater(_next);
    }
}
