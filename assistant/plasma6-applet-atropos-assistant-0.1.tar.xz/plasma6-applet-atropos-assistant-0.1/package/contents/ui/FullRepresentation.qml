// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later

import QtQuick
import QtQuick.Layouts
import QtQuick.Dialogs as Dialogs

import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents3
import org.kde.plasma.extras as PlasmaExtras
import org.kde.plasma.plasmoid

PlasmaExtras.Representation {
    id: full

    // main.qml's root: a PlasmoidItem with chats, submit(), openChat() and so on.
    required property var plasmoidItem
    required property ChatSession session
    required property AssistantService service

    // [{ type: "image", url }] and [{ type: "file", name, text }]
    property var attachments: []
    readonly property bool windowed: plasmoidItem.windowed
    readonly property bool wide: width >= Kirigami.Units.gridUnit * 36
    // The chat list sits beside the chat when there is room, and replaces it
    // when there is not. Each width remembers its own open or closed.
    property bool wideListOpen: windowed
    property bool narrowListOpen: false
    readonly property bool sidebarOpen: wide ? wideListOpen : narrowListOpen
    readonly property bool sidebarBeside: sidebarOpen && wide
    readonly property bool sidebarOnly: sidebarOpen && !wide
    property bool renaming: false
    property string renameId: ""
    property string deleteId: ""
    property string deleteTitle: ""
    property string exportId: ""
    // The size page, opened from the menu with a model already there.
    property bool setupRequested: false

    // What the state of things means for the person: ready, loading, failed,
    // start, download, downloading, error, unreachable.
    readonly property string situation: {
        const setup = plasmoidItem.setupState;
        if (setup === "downloading") {
            return "downloading";
        }
        if (plasmoidItem.managed && (setup === "missing" || setup === "error")) {
            return "download";
        }
        if (session.serverState === "ready") {
            return "ready";
        }
        if (session.serverState === "loading" || plasmoidItem.starting) {
            return "loading";
        }
        if (plasmoidItem.startError) {
            return "failed";
        }
        if (session.serverState === "error") {
            return "error";
        }
        if (session.serverState === "unknown") {
            return "ready";
        }
        if (plasmoidItem.canStart) {
            return "start";
        }
        return "unreachable";
    }
    readonly property bool showSetup: setupRequested
        || ((situation === "download" || situation === "downloading") && session.messages.count === 0)
    readonly property string displayName: session.modelName || i18n("the model")

    Layout.minimumWidth: Kirigami.Units.gridUnit * 18
    Layout.minimumHeight: Kirigami.Units.gridUnit * 20
    Layout.preferredWidth: Kirigami.Units.gridUnit * (windowed ? 50 : 26)
    Layout.preferredHeight: Kirigami.Units.gridUnit * (windowed ? 36 : 34)

    collapseMarginsHint: true

    // A thinking level in the native menu. The current one carries a check
    // icon; a checkable QAction would untick itself when clicked again.
    component EffortItem: PlasmaExtras.MenuItem {
        required property string value
        icon: Plasmoid.configuration.reasoningEffort === value ? "checkmark" : ""
        onClicked: Plasmoid.configuration.reasoningEffort = value
    }

    function setSidebar(open) {
        if (wide) {
            wideListOpen = open;
        } else {
            narrowListOpen = open;
        }
    }

    function submit() {
        if (encoder.working) {
            return;
        }
        const images = attachments.filter(a => a.type === "image").map(a => a.url);
        const files = attachments.filter(a => a.type === "file").map(a => ({ name: a.name, text: a.text }));
        if (plasmoidItem.submit(input.text, images, files)) {
            input.clear();
            attachments = [];
            messageList.stick = true;
            if (sidebarOnly) {
                setSidebar(false);
            }
        }
    }

    function addFiles(urls) {
        for (const url of urls) {
            const s = String(url);
            if (/\.(png|jpe?g|webp|gif|bmp|tiff?)$/i.test(s)) {
                encoder.add(s);
            } else if (service.available === true) {
                const name = decodeURIComponent(s.substring(s.lastIndexOf("/") + 1));
                plasmoidItem.readTextFile(s, function (text) {
                    full.attachments = full.attachments.concat([{ type: "file", name: name, text: text }]);
                });
            }
        }
    }

    function editMessage(index) {
        const taken = session.editFrom(index);
        if (!taken) {
            return;
        }
        input.text = taken.text;
        attachments = taken.images.map(url => ({ type: "image", url: url }))
            .concat(taken.files.map(f => ({ type: "file", name: f.name, text: f.text })));
        input.forceActiveFocus();
        input.cursorPosition = input.length;
    }

    function copyText(text) {
        clipboardHelper.text = text;
        clipboardHelper.selectAll();
        clipboardHelper.copy();
        clipboardHelper.text = "";
    }

    function startRename(id) {
        if (id && id !== session.chatId) {
            plasmoidItem.openChat(id);
        }
        renameId = id || session.chatId;
        renaming = true;
        titleField.text = session.title;
        titleField.forceActiveFocus();
        titleField.selectAll();
    }

    function finishRename(accept) {
        if (!renaming) {
            return;
        }
        renaming = false;
        if (accept && titleField.text.trim()) {
            plasmoidItem.renameChat(renameId, titleField.text);
        }
        input.forceActiveFocus();
    }

    function startExport(id, title) {
        exportId = id || session.chatId;
        const name = (title || session.title || i18n("Chat")).replace(/[\/\\:*?"<>|]/g, " ").trim();
        exportDialog.selectedFile = exportDialog.currentFolder + "/" + name + ".md";
        exportDialog.open();
    }

    // A size change that finishes goes back to the chat.
    Connections {
        target: full.service
        property string last: ""
        function onSetupStateChanged() {
            if (last === "downloading" && full.service.setupState === "ready") {
                full.setupRequested = false;
            }
            last = full.service.setupState;
        }
    }

    Connections {
        target: full.plasmoidItem
        function onExpandedChanged() {
            if (full.plasmoidItem.expanded) {
                input.forceActiveFocus();
            }
        }
    }

    Shortcut {
        sequences: [StandardKey.New]
        onActivated: {
            full.plasmoidItem.newChat();
            input.forceActiveFocus();
        }
    }
    Shortcut {
        sequences: [StandardKey.Find]
        enabled: full.service.available === true
        onActivated: {
            full.setSidebar(true);
            chatList.focusSearch();
        }
    }

    header: PlasmaExtras.PlasmoidHeading {
        contentItem: RowLayout {
            spacing: Kirigami.Units.smallSpacing

            PlasmaComponents3.ToolButton {
                visible: full.service.available === true
                checkable: true
                checked: full.sidebarOpen
                icon.name: "sidebar-show-symbolic"
                display: PlasmaComponents3.AbstractButton.IconOnly
                text: i18n("Chats")
                onToggled: full.setSidebar(checked)
                PlasmaComponents3.ToolTip.text: i18n("Saved chats (Ctrl+F searches)")
                PlasmaComponents3.ToolTip.visible: hovered
                PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
            }

            Kirigami.Heading {
                Layout.fillWidth: true
                Layout.leftMargin: Kirigami.Units.smallSpacing
                visible: !full.renaming
                level: 3
                elide: Text.ElideRight
                text: full.session.title || full.session.modelName || i18n("Assistant")

                TapHandler {
                    enabled: full.session.messages.count > 0
                    onDoubleTapped: full.startRename("")
                }
            }

            PlasmaComponents3.TextField {
                id: titleField
                Layout.fillWidth: true
                visible: full.renaming
                placeholderText: i18n("Chat title")
                Keys.onReturnPressed: full.finishRename(true)
                Keys.onEnterPressed: full.finishRename(true)
                Keys.onEscapePressed: full.finishRename(false)
                onActiveFocusChanged: {
                    if (!activeFocus) {
                        full.finishRename(true);
                    }
                }
            }

            PlasmaComponents3.ToolButton {
                icon.name: "document-new"
                display: PlasmaComponents3.AbstractButton.IconOnly
                text: i18n("New Chat")
                enabled: full.session.messages.count > 0
                onClicked: {
                    full.plasmoidItem.newChat();
                    input.forceActiveFocus();
                }
                PlasmaComponents3.ToolTip.text: i18n("New Chat (Ctrl+N)")
                PlasmaComponents3.ToolTip.visible: hovered
                PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
            }

            PlasmaComponents3.ToolButton {
                visible: !full.windowed && full.service.available === true
                icon.name: "window-new"
                display: PlasmaComponents3.AbstractButton.IconOnly
                text: i18n("Open in Window")
                onClicked: full.plasmoidItem.openInWindow()
                PlasmaComponents3.ToolTip.text: text
                PlasmaComponents3.ToolTip.visible: hovered
                PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
            }

            PlasmaComponents3.ToolButton {
                visible: !full.windowed && !full.plasmoidItem.inTray
                checkable: true
                checked: full.plasmoidItem.pinned
                icon.name: "window-pin"
                display: PlasmaComponents3.AbstractButton.IconOnly
                text: i18n("Keep Open")
                onToggled: full.plasmoidItem.pinned = checked
                PlasmaComponents3.ToolTip.text: text
                PlasmaComponents3.ToolTip.visible: hovered
                PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
            }

            PlasmaComponents3.ToolButton {
                id: menuButton
                icon.name: "overflow-menu"
                display: PlasmaComponents3.AbstractButton.IconOnly
                text: i18n("More")
                down: chatMenu.status === PlasmaExtras.Menu.Open
                onClicked: chatMenu.openRelative()
            }
        }
    }

    // A real menu window in the system style, like other Plasma context
    // menus. An in-popup menu shares the popup's translucent frame without
    // its blur, and is hard to tell from what is behind it.
    PlasmaExtras.Menu {
        id: chatMenu

        readonly property bool hasChat: full.session.messages.count > 0
        readonly property bool saved: full.session.chatId !== ""
        readonly property bool withService: full.service.available === true

        visualParent: menuButton
        placement: PlasmaExtras.Menu.BottomPosedRightAlignedPopup

        PlasmaExtras.MenuItem {
            text: i18n("Rename…")
            icon: "edit-rename"
            enabled: chatMenu.hasChat
            onClicked: Qt.callLater(full.startRename, "")
        }
        PlasmaExtras.MenuItem {
            visible: chatMenu.withService
            text: full.session.favorite ? i18n("Remove from Favorites") : i18n("Add to Favorites")
            icon: full.session.favorite ? "non-starred-symbolic" : "starred-symbolic"
            enabled: chatMenu.hasChat
            onClicked: full.plasmoidItem.setFavorite(full.session.chatId, !full.session.favorite)
        }
        PlasmaExtras.MenuItem {
            visible: chatMenu.withService
            text: i18n("Duplicate")
            icon: "edit-copy"
            enabled: chatMenu.saved
            onClicked: full.plasmoidItem.duplicateChat(full.session.chatId)
        }
        PlasmaExtras.MenuItem {
            visible: chatMenu.withService
            text: i18n("Export…")
            icon: "document-export"
            enabled: chatMenu.hasChat
            onClicked: Qt.callLater(full.startExport, "", "")
        }
        PlasmaExtras.MenuItem {
            visible: chatMenu.withService
            text: i18n("Import…")
            icon: "document-import"
            onClicked: Qt.callLater(importDialog.open)
        }
        PlasmaExtras.MenuItem {
            visible: chatMenu.withService
            text: i18n("Delete…")
            icon: "edit-delete"
            enabled: chatMenu.saved
            onClicked: {
                full.deleteId = full.session.chatId;
                full.deleteTitle = full.session.title;
            }
        }
        PlasmaExtras.MenuItem {
            separator: true
            visible: full.plasmoidItem.managed
        }
        PlasmaExtras.MenuItem {
            visible: full.plasmoidItem.managed && full.service.serverState !== "active" && !full.plasmoidItem.starting
            text: i18n("Start Model")
            icon: "media-playback-start"
            enabled: full.plasmoidItem.canStart
            onClicked: full.plasmoidItem.startServer()
        }
        PlasmaExtras.MenuItem {
            visible: full.plasmoidItem.managed && (full.service.serverState === "active" || full.plasmoidItem.starting)
            text: i18n("Stop Model and Free Memory")
            icon: "media-playback-stop"
            onClicked: full.plasmoidItem.stopServer()
        }
        PlasmaExtras.MenuItem {
            visible: full.plasmoidItem.managed && full.plasmoidItem.setupState === "ready"
            text: i18n("Model Size…")
            icon: "download"
            onClicked: full.setupRequested = true
        }
        PlasmaExtras.MenuItem {
            separator: true
        }
        PlasmaExtras.MenuItem {
            text: i18n("Configure…")
            icon: "configure"
            onClicked: Plasmoid.internalAction("configure").trigger()
        }
    }

    contentItem: Item {
        DropArea {
            anchors.fill: parent
            onEntered: drag => drag.accept(Qt.CopyAction)
            onDropped: drop => {
                if (drop.hasUrls) {
                    full.addFiles(drop.urls);
                    drop.accept(Qt.CopyAction);
                }
            }
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Kirigami.Units.smallSpacing
            spacing: Kirigami.Units.smallSpacing

            Kirigami.InlineMessage {
                Layout.fillWidth: true
                visible: full.deleteId !== ""
                type: Kirigami.MessageType.Warning
                text: i18n("Delete “%1”? This cannot be undone.", full.deleteTitle || i18n("this chat"))
                actions: [
                    Kirigami.Action {
                        text: i18n("Delete")
                        icon.name: "edit-delete"
                        onTriggered: {
                            full.plasmoidItem.deleteChat(full.deleteId);
                            full.deleteId = "";
                        }
                    },
                    Kirigami.Action {
                        text: i18n("Cancel")
                        icon.name: "dialog-cancel"
                        onTriggered: full.deleteId = ""
                    }
                ]
            }

            Kirigami.InlineMessage {
                Layout.fillWidth: true
                visible: full.service.lastError.length > 0
                type: Kirigami.MessageType.Error
                text: full.service.lastError
                showCloseButton: true
                onVisibleChanged: {
                    if (!visible) {
                        full.service.lastError = "";
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: Kirigami.Units.smallSpacing

                ChatList {
                    id: chatList
                    visible: full.sidebarOpen && full.service.available === true
                    Layout.fillHeight: true
                    Layout.fillWidth: !full.sidebarBeside
                    Layout.preferredWidth: full.sidebarBeside ? Kirigami.Units.gridUnit * 15 : -1
                    Layout.maximumWidth: full.sidebarBeside ? Kirigami.Units.gridUnit * 18 : -1
                    plasmoidItem: full.plasmoidItem
                    session: full.session
                    onChatChosen: id => {
                        full.plasmoidItem.openChat(id);
                        if (full.sidebarOnly) {
                            full.setSidebar(false);
                        }
                        input.forceActiveFocus();
                    }
                    onRenameRequested: id => {
                        if (full.sidebarOnly) {
                            full.setSidebar(false);
                        }
                        full.startRename(id);
                    }
                    onDeleteRequested: (id, title) => {
                        full.deleteId = id;
                        full.deleteTitle = title;
                    }
                    onExportRequested: (id, title) => full.startExport(id, title)
                }

                Kirigami.Separator {
                    visible: full.sidebarBeside && chatList.visible
                    Layout.fillHeight: true
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    visible: !(full.sidebarOnly && chatList.visible)
                    spacing: Kirigami.Units.smallSpacing

                    // Shown above the conversation when the model is not usable.
                    Kirigami.InlineMessage {
                        Layout.fillWidth: true
                        visible: !full.showSetup && full.session.messages.count > 0
                            && ["ready", "loading"].indexOf(full.situation) < 0
                        type: full.situation === "error" || full.situation === "failed" ? Kirigami.MessageType.Error : Kirigami.MessageType.Warning
                        text: statusPlaceholder.text + (statusPlaceholder.explanation ? "\n" + statusPlaceholder.explanation : "")
                        actions: statusPlaceholder.helpfulAction ? [statusPlaceholder.helpfulAction] : []
                    }

                    SetupView {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        visible: full.showSetup
                        plasmoidItem: full.plasmoidItem
                        service: full.service
                        closable: full.setupRequested && full.service.setupState !== "downloading"
                        onClosed: full.setupRequested = false
                    }

                    PlasmaComponents3.ScrollView {
                        id: scroll
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        visible: !full.showSetup
                        PlasmaComponents3.ScrollBar.horizontal.policy: PlasmaComponents3.ScrollBar.AlwaysOff

                        ListView {
                            id: messageList

                            property bool stick: true
                            property bool autoScrolling: false
                            readonly property int lastUser: {
                                for (let i = count - 1; i >= 0; --i) {
                                    if (full.session.messages.get(i).role === "user") {
                                        return i;
                                    }
                                }
                                return -1;
                            }

                            model: full.session.messages
                            spacing: Kirigami.Units.largeSpacing
                            topMargin: Kirigami.Units.smallSpacing
                            bottomMargin: Kirigami.Units.smallSpacing
                            leftMargin: Kirigami.Units.smallSpacing
                            rightMargin: Kirigami.Units.smallSpacing
                            clip: true
                            reuseItems: false
                            boundsBehavior: Flickable.StopAtBounds

                            function scrollToEnd() {
                                autoScrolling = true;
                                positionViewAtEnd();
                                autoScrolling = false;
                            }

                            onContentHeightChanged: {
                                if (stick) {
                                    Qt.callLater(scrollToEnd);
                                }
                            }
                            onCountChanged: {
                                if (stick) {
                                    Qt.callLater(scrollToEnd);
                                }
                            }
                            // Growing content does not move contentY, so a change here is
                            // the person scrolling. Follow the answer only from the bottom.
                            onContentYChanged: {
                                if (!autoScrolling) {
                                    stick = (contentHeight + originY + bottomMargin) - (contentY + height) < Kirigami.Units.gridUnit;
                                }
                            }

                            delegate: MessageDelegate {
                                width: ListView.view.width - ListView.view.leftMargin - ListView.view.rightMargin
                                showThinking: Plasmoid.configuration.showThinking
                                isLast: index === ListView.view.count - 1
                                isLastUser: index === messageList.lastUser
                                searching: full.session.searching && index === messageList.lastUser
                                canEdit: !full.session.busy
                                canFork: full.service.available === true && !full.session.busy
                                serverUrl: full.session.serverUrl
                                onCopyRequested: text => full.copyText(text)
                                onEditRequested: full.editMessage(index)
                                onForkRequested: full.plasmoidItem.forkChat(index)
                                onApproveRequested: full.session.approveTool(index)
                                onDenyRequested: full.session.denyTool(index)
                                onRegenerateRequested: {
                                    messageList.stick = true;
                                    full.plasmoidItem.regenerate();
                                }
                            }

                            PlasmaExtras.PlaceholderMessage {
                                id: statusPlaceholder
                                anchors.centerIn: parent
                                width: parent.width - Kirigami.Units.gridUnit * 4
                                visible: messageList.count === 0

                                iconName: {
                                    switch (full.situation) {
                                    case "ready":
                                        return "dialog-messages";
                                    case "loading":
                                        return "content-loading-symbolic";
                                    case "failed":
                                    case "error":
                                        return "dialog-error";
                                    default:
                                        return "network-disconnect";
                                    }
                                }
                                text: {
                                    switch (full.situation) {
                                    case "ready":
                                        return i18nc("%1 is the model name", "Ask %1 anything", full.displayName);
                                    case "loading":
                                        return i18nc("%1 is the model name", "Loading %1…", full.displayName);
                                    case "start":
                                        return i18n("Inkling 2 Mini is not running");
                                    case "failed":
                                        return i18n("The model server could not start");
                                    case "download":
                                    case "downloading":
                                        return i18n("Inkling 2 Mini is not downloaded yet");
                                    case "error":
                                        return i18n("The model server returned an error");
                                    default:
                                        return i18n("Could not reach the model server");
                                    }
                                }
                                explanation: {
                                    switch (full.situation) {
                                    case "ready":
                                        return Plasmoid.configuration.webSearch && full.service.available === true
                                            ? i18n("It runs on this computer. Web search is on, so each question also goes to DuckDuckGo.")
                                            : i18n("It runs on this computer. What you type here stays here.");
                                    case "loading":
                                        return i18n("Loading reads the whole model from disk, so it can take a minute.");
                                    case "start":
                                        return i18n("It needs a lot of memory while it runs. Sending a message starts it as well.");
                                    case "failed":
                                        return full.plasmoidItem.startError;
                                    case "download":
                                    case "downloading":
                                        return "";
                                    case "error":
                                        return full.session.serverError;
                                    default:
                                        if (!full.plasmoidItem.useLocal) {
                                            return full.plasmoidItem.localAvailable
                                                ? i18n("Nothing answers at %1. Inkling 2 Mini is also downloaded on this computer.", full.session.serverUrl)
                                                : i18n("Nothing answers at %1. Start that server, or change the address in the settings.", full.session.serverUrl);
                                        }
                                        return i18n("The Assistant service is not installed, so nothing starts the model at %1.", full.session.serverUrl);
                                    }
                                }
                                helpfulAction: {
                                    switch (full.situation) {
                                    case "start":
                                    case "failed":
                                        return startAction;
                                    case "download":
                                    case "downloading":
                                        return showDownloadAction;
                                    case "unreachable":
                                    case "error":
                                        return full.plasmoidItem.localAvailable ? useLocalAction : configureAction;
                                    default:
                                        return null;
                                    }
                                }
                            }
                        }
                    }

                    Flow {
                        Layout.fillWidth: true
                        visible: full.attachments.length > 0 || encoder.working
                        spacing: Kirigami.Units.smallSpacing

                        Repeater {
                            model: full.attachments
                            delegate: Item {
                                id: attachment
                                required property var modelData
                                required property int index
                                width: modelData.type === "image" ? Kirigami.Units.gridUnit * 3 : fileChip.width
                                height: Kirigami.Units.gridUnit * 3

                                Image {
                                    anchors.fill: parent
                                    visible: attachment.modelData.type === "image"
                                    source: attachment.modelData.type === "image" ? attachment.modelData.url : ""
                                    fillMode: Image.PreserveAspectCrop
                                    asynchronous: true
                                }

                                Rectangle {
                                    id: fileChip
                                    visible: attachment.modelData.type === "file"
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: chipRow.implicitWidth + Kirigami.Units.largeSpacing * 2 + Kirigami.Units.iconSizes.small
                                    height: Kirigami.Units.gridUnit * 2
                                    radius: Kirigami.Units.cornerRadius
                                    color: Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.08)

                                    RowLayout {
                                        id: chipRow
                                        anchors.verticalCenter: parent.verticalCenter
                                        x: Kirigami.Units.largeSpacing
                                        Kirigami.Icon {
                                            source: "text-x-generic"
                                            Layout.preferredWidth: Kirigami.Units.iconSizes.small
                                            Layout.preferredHeight: Kirigami.Units.iconSizes.small
                                        }
                                        PlasmaComponents3.Label {
                                            text: attachment.modelData.name || ""
                                            Layout.maximumWidth: Kirigami.Units.gridUnit * 10
                                            elide: Text.ElideMiddle
                                        }
                                    }
                                }

                                PlasmaComponents3.ToolButton {
                                    anchors.top: parent.top
                                    anchors.right: parent.right
                                    anchors.topMargin: attachment.modelData.type === "file" ? Kirigami.Units.smallSpacing : 0
                                    width: Kirigami.Units.iconSizes.small + Kirigami.Units.smallSpacing * 2
                                    height: width
                                    icon.name: "edit-delete-remove"
                                    display: PlasmaComponents3.AbstractButton.IconOnly
                                    text: i18n("Remove")
                                    onClicked: {
                                        const list = full.attachments.slice();
                                        list.splice(attachment.index, 1);
                                        full.attachments = list;
                                    }
                                }
                            }
                        }

                        PlasmaComponents3.BusyIndicator {
                            visible: encoder.working
                            running: visible
                            width: Kirigami.Units.gridUnit * 2
                            height: width
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: Kirigami.Units.smallSpacing

                        PlasmaComponents3.ToolButton {
                            Layout.alignment: Qt.AlignBottom
                            icon.name: "mail-attachment"
                            display: PlasmaComponents3.AbstractButton.IconOnly
                            text: i18n("Attach…")
                            enabled: !full.session.busy
                            onClicked: attachDialog.open()
                            PlasmaComponents3.ToolTip.text: full.service.available === true
                                ? i18n("Attach images or text files. You can also drop them here.")
                                : i18n("Attach images. You can also drop them here.")
                            PlasmaComponents3.ToolTip.visible: hovered
                            PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
                        }

                        PlasmaComponents3.ScrollView {
                            Layout.fillWidth: true
                            Layout.maximumHeight: Kirigami.Units.gridUnit * 8

                            PlasmaComponents3.TextArea {
                                id: input
                                placeholderText: Plasmoid.configuration.webSearch && full.service.available === true
                                    ? i18nc("%1 is the model name", "Message %1, with web search…", full.displayName)
                                    : i18nc("%1 is the model name", "Message %1…", full.displayName)
                                wrapMode: TextEdit.Wrap
                                focus: true
                                Keys.onPressed: event => {
                                    if ((event.key === Qt.Key_Return || event.key === Qt.Key_Enter)
                                            && !(event.modifiers & Qt.ShiftModifier)) {
                                        event.accepted = true;
                                        if (!full.session.busy) {
                                            full.submit();
                                        }
                                    } else if (event.key === Qt.Key_Escape && full.session.busy) {
                                        event.accepted = true;
                                        full.session.stop();
                                    } else if (event.key === Qt.Key_Up && input.length === 0 && messageList.lastUser >= 0
                                               && messageList.lastUser >= messageList.count - 2 && !full.session.busy) {
                                        // Up in an empty field edits the last question.
                                        event.accepted = true;
                                        full.editMessage(messageList.lastUser);
                                    }
                                }
                            }
                        }

                        PlasmaComponents3.ToolButton {
                            Layout.alignment: Qt.AlignBottom
                            icon.name: full.session.busy ? "media-playback-stop" : "document-send"
                            display: PlasmaComponents3.AbstractButton.IconOnly
                            text: full.session.busy ? i18n("Stop") : i18n("Send")
                            enabled: full.session.busy || (!encoder.working && (input.text.trim().length > 0 || full.attachments.length > 0))
                            onClicked: full.session.busy ? full.session.stop() : full.submit()
                            PlasmaComponents3.ToolTip.text: full.session.busy ? i18n("Stop (Esc)") : i18n("Send (Enter). Shift+Enter starts a new line.")
                            PlasmaComponents3.ToolTip.visible: hovered
                            PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: Kirigami.Units.smallSpacing

                        PlasmaComponents3.Label {
                            text: i18nc("label for the thinking effort list", "Thinking:")
                            opacity: 0.7
                            font: Kirigami.Theme.smallFont
                        }

                        PlasmaComponents3.ToolButton {
                            id: effortButton

                            readonly property var efforts: [
                                { value: "minimal", text: i18nc("thinking effort", "Minimal") },
                                { value: "low", text: i18nc("thinking effort", "Low") },
                                { value: "medium", text: i18nc("thinking effort", "Medium") },
                                { value: "high", text: i18nc("thinking effort", "High") },
                                { value: "xhigh", text: i18nc("thinking effort", "Extra High") },
                                { value: "max", text: i18nc("thinking effort", "Maximum") },
                            ]
                            readonly property var current: efforts.find(e => e.value === Plasmoid.configuration.reasoningEffort) || efforts[1]

                            down: effortMenu.status === PlasmaExtras.Menu.Open
                            onClicked: effortMenu.openRelative()
                            Accessible.name: i18nc("@action:button %1 is a thinking effort", "Thinking: %1", current.text)

                            contentItem: RowLayout {
                                spacing: Kirigami.Units.smallSpacing
                                PlasmaComponents3.Label {
                                    text: effortButton.current.text
                                    font: Kirigami.Theme.smallFont
                                }
                                Kirigami.Icon {
                                    source: "arrow-down"
                                    Layout.preferredWidth: Kirigami.Units.iconSizes.small
                                    Layout.preferredHeight: Kirigami.Units.iconSizes.small
                                }
                            }

                            PlasmaComponents3.ToolTip.text: i18n("How long the model thinks before it answers")
                            PlasmaComponents3.ToolTip.visible: hovered && !down
                            PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay

                            PlasmaExtras.Menu {
                                id: effortMenu
                                visualParent: effortButton
                                placement: PlasmaExtras.Menu.TopPosedLeftAlignedPopup

                                EffortItem { value: "minimal"; text: effortButton.efforts[0].text }
                                EffortItem { value: "low"; text: effortButton.efforts[1].text }
                                EffortItem { value: "medium"; text: effortButton.efforts[2].text }
                                EffortItem { value: "high"; text: effortButton.efforts[3].text }
                                EffortItem { value: "xhigh"; text: effortButton.efforts[4].text }
                                EffortItem { value: "max"; text: effortButton.efforts[5].text }
                            }
                        }

                        PlasmaComponents3.ToolButton {
                            visible: full.service.available === true
                            checkable: true
                            checked: Plasmoid.configuration.webSearch
                            onToggled: Plasmoid.configuration.webSearch = checked
                            icon.name: "globe"
                            icon.width: Kirigami.Units.iconSizes.small
                            icon.height: Kirigami.Units.iconSizes.small
                            text: i18nc("@action:button web search", "Web")
                            font: Kirigami.Theme.smallFont
                            PlasmaComponents3.ToolTip.text: checked
                                ? i18np("Web search is on: each question goes to DuckDuckGo first, and the top result goes to the model.",
                                        "Web search is on: each question goes to DuckDuckGo first, and the top %1 results go to the model.",
                                        Plasmoid.configuration.webResults)
                                : i18n("Search DuckDuckGo before answering. Your question leaves this computer when this is on.")
                            PlasmaComponents3.ToolTip.visible: hovered
                            PlasmaComponents3.ToolTip.delay: Kirigami.Units.toolTipDelay
                        }

                        Item { Layout.fillWidth: true }

                        Rectangle {
                            Layout.preferredWidth: Kirigami.Units.smallSpacing * 2
                            Layout.preferredHeight: Kirigami.Units.smallSpacing * 2
                            radius: width / 2
                            color: full.situation === "ready" ? Kirigami.Theme.positiveTextColor
                                : full.situation === "loading" || full.situation === "downloading" ? Kirigami.Theme.neutralTextColor
                                : full.situation === "failed" ? Kirigami.Theme.negativeTextColor
                                : Kirigami.Theme.disabledTextColor
                        }

                        PlasmaComponents3.Label {
                            opacity: 0.7
                            font: Kirigami.Theme.smallFont
                            elide: Text.ElideRight
                            Layout.maximumWidth: Kirigami.Units.gridUnit * 14
                            text: {
                                switch (full.situation) {
                                case "ready":
                                    return full.displayName;
                                case "loading":
                                    return i18n("Loading…");
                                case "downloading":
                                    return i18n("Downloading…");
                                case "failed":
                                    return i18n("Failed to start");
                                default:
                                    return i18n("Not running");
                                }
                            }
                        }
                    }
                }
            }
        }

        ImageEncoder {
            id: encoder
            onEncoded: (source, dataUrl) => {
                full.attachments = full.attachments.concat([{ type: "image", url: dataUrl }]);
            }
        }

        // Copying goes through a hidden TextEdit. QML has no clipboard API.
        TextEdit {
            id: clipboardHelper
            visible: false
        }
    }

    Kirigami.Action {
        id: startAction
        text: full.situation === "failed" ? i18n("Try Again") : i18n("Start")
        icon.name: "media-playback-start"
        onTriggered: full.plasmoidItem.startServer()
    }

    Kirigami.Action {
        id: showDownloadAction
        text: i18n("Show Download")
        icon.name: "download"
        onTriggered: full.setupRequested = true
    }

    Kirigami.Action {
        id: useLocalAction
        text: i18n("Use Inkling 2 Mini on This Computer")
        icon.name: "dialog-messages"
        onTriggered: full.plasmoidItem.useLocalModel()
    }

    Kirigami.Action {
        id: configureAction
        text: i18n("Configure…")
        icon.name: "configure"
        onTriggered: Plasmoid.internalAction("configure").trigger()
    }

    Dialogs.FileDialog {
        id: attachDialog
        title: i18n("Attach Files")
        fileMode: Dialogs.FileDialog.OpenFiles
        nameFilters: full.service.available === true
            ? [i18n("Images and text (*.png *.jpg *.jpeg *.webp *.gif *.bmp *.tif *.tiff *.txt *.md *.log *.csv *.json *.xml *.yaml *.yml *.ini *.conf *.sh *.py *.js *.qml *.c *.cpp *.h *.rs *.go *.java *.spec *.diff *.patch)"),
               i18n("All files (*)")]
            : [i18n("Images (*.png *.jpg *.jpeg *.webp *.gif *.bmp *.tif *.tiff)")]
        onVisibleChanged: full.plasmoidItem.dialogOpen = visible
        onAccepted: full.addFiles(selectedFiles)
    }

    Dialogs.FileDialog {
        id: exportDialog
        title: i18n("Export Chat")
        fileMode: Dialogs.FileDialog.SaveFile
        nameFilters: [i18n("Markdown (*.md)"), i18n("Plain text (*.txt)"), i18n("Assistant chat, can be imported (*.json)")]
        onVisibleChanged: full.plasmoidItem.dialogOpen = visible
        onAccepted: full.plasmoidItem.exportChat(full.exportId, ["md", "txt", "json"][Math.max(0, selectedNameFilter.index)], selectedFile)
    }

    Dialogs.FileDialog {
        id: importDialog
        title: i18n("Import Chat")
        fileMode: Dialogs.FileDialog.OpenFile
        nameFilters: [i18n("Assistant chat (*.json)")]
        onVisibleChanged: full.plasmoidItem.dialogOpen = visible
        onAccepted: full.plasmoidItem.importChat(selectedFile)
    }

    Component.onCompleted: input.forceActiveFocus()
}
