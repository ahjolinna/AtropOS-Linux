// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later
//
// Saved chats: search, favorites first, then by age.

import QtQuick
import QtQuick.Layouts

import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents3
import org.kde.plasma.extras as PlasmaExtras

ColumnLayout {
    id: list

    required property var plasmoidItem
    required property ChatSession session

    signal chatChosen(string id)
    signal renameRequested(string id)
    signal deleteRequested(string id, string title)
    signal exportRequested(string id, string title)

    property var results: null   // search hits, or null when not searching

    spacing: Kirigami.Units.smallSpacing

    function focusSearch() {
        search.forceActiveFocus();
        search.selectAll();
    }

    function groupOf(chat) {
        if (chat.favorite && results === null) {
            return i18n("Favorites");
        }
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const day = 24 * 3600 * 1000;
        const t = chat.updated || 0;
        if (t >= today.getTime()) {
            return i18n("Today");
        }
        if (t >= today.getTime() - 7 * day) {
            return i18n("Previous 7 Days");
        }
        if (t >= today.getTime() - 30 * day) {
            return i18n("Previous 30 Days");
        }
        return i18n("Older");
    }

    function rebuild() {
        const source = results !== null ? results : plasmoidItem.chats;
        let sorted = source.slice();
        if (results === null) {
            // Favorites on top; the rest stay newest first.
            sorted.sort((a, b) => (b.favorite ? 1 : 0) - (a.favorite ? 1 : 0) || b.updated - a.updated);
        }
        chatModel.clear();
        for (const chat of sorted) {
            chatModel.append({
                chatId: chat.id,
                title: chat.title || i18n("Untitled"),
                favorite: !!chat.favorite,
                updated: chat.updated || 0,
                snippet: chat.snippet || "",
                group: groupOf(chat),
                fromKRunner: chat.source === "krunner",
            });
        }
    }

    Connections {
        target: list.plasmoidItem
        function onChatsChanged() {
            if (search.text.length > 0) {
                searchTimer.restart();
            } else {
                list.rebuild();
            }
        }
    }

    Component.onCompleted: rebuild()

    ListModel {
        id: chatModel
    }

    PlasmaExtras.SearchField {
        id: search
        Layout.fillWidth: true
        placeholderText: i18n("Search chats…")
        onTextChanged: searchTimer.restart()
        Keys.onDownPressed: chatView.forceActiveFocus()
    }

    Timer {
        id: searchTimer
        interval: 250
        onTriggered: {
            if (search.text.trim().length === 0) {
                list.results = null;
                list.rebuild();
            } else {
                const query = search.text;
                list.plasmoidItem.searchChats(query, function (hits) {
                    if (search.text === query) {
                        list.results = hits;
                        list.rebuild();
                    }
                });
            }
        }
    }

    PlasmaComponents3.ScrollView {
        Layout.fillWidth: true
        Layout.fillHeight: true
        PlasmaComponents3.ScrollBar.horizontal.policy: PlasmaComponents3.ScrollBar.AlwaysOff

        ListView {
            id: chatView
            model: chatModel
            clip: true
            reuseItems: true
            keyNavigationEnabled: true
            highlightMoveDuration: 0

            section.property: "group"
            section.delegate: PlasmaExtras.ListSectionHeader {
                required property string section
                width: ListView.view.width
                text: section
            }

            delegate: PlasmaComponents3.ItemDelegate {
                id: row

                required property int index
                required property string chatId
                required property string title
                required property bool favorite
                required property double updated
                required property string snippet
                required property bool fromKRunner

                width: ListView.view.width
                highlighted: chatId === list.session.chatId

                contentItem: RowLayout {
                    spacing: Kirigami.Units.smallSpacing

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 0

                        PlasmaComponents3.Label {
                            Layout.fillWidth: true
                            text: row.title
                            elide: Text.ElideRight
                            maximumLineCount: 1
                        }

                        PlasmaComponents3.Label {
                            Layout.fillWidth: true
                            text: row.snippet || (row.fromKRunner ? i18nc("%1 is a time", "%1 · from KRunner", list.when(row.updated)) : list.when(row.updated))
                            elide: Text.ElideRight
                            maximumLineCount: 1
                            opacity: 0.6
                            font: Kirigami.Theme.smallFont
                        }
                    }

                    Kirigami.Icon {
                        visible: row.favorite
                        source: "starred-symbolic"
                        Layout.preferredWidth: Kirigami.Units.iconSizes.small
                        Layout.preferredHeight: Kirigami.Units.iconSizes.small
                    }

                    PlasmaComponents3.ToolButton {
                        visible: row.hovered || row.highlighted || (chatMenu.status === PlasmaExtras.Menu.Open && chatMenu.chatId === row.chatId)
                        icon.name: "overflow-menu"
                        icon.width: Kirigami.Units.iconSizes.small
                        icon.height: Kirigami.Units.iconSizes.small
                        display: PlasmaComponents3.AbstractButton.IconOnly
                        text: i18n("Chat Actions")
                        onClicked: list.openMenu(row, this)
                    }
                }

                onClicked: list.chatChosen(chatId)

                TapHandler {
                    acceptedButtons: Qt.RightButton
                    onTapped: list.openMenu(row, row)
                }
            }

            PlasmaExtras.PlaceholderMessage {
                anchors.centerIn: parent
                width: parent.width - Kirigami.Units.gridUnit * 2
                visible: chatView.count === 0
                iconName: list.results !== null ? "edit-none" : "dialog-messages"
                text: list.results !== null ? i18n("No chats match") : i18n("No saved chats yet")
                explanation: list.results !== null ? "" : i18n("Chats are saved here after the first answer.")
            }
        }
    }

    function when(ms) {
        const d = new Date(ms);
        const today = new Date();
        if (d.toDateString() === today.toDateString()) {
            return Qt.formatTime(d, Qt.locale().timeFormat(Locale.ShortFormat));
        }
        return Qt.formatDate(d, Qt.locale().dateFormat(Locale.ShortFormat));
    }

    function openMenu(row, anchor) {
        chatMenu.chatId = row.chatId;
        chatMenu.chatTitle = row.title;
        chatMenu.favorite = row.favorite;
        chatMenu.visualParent = anchor;
        chatMenu.openRelative();
    }

    // A real menu window in the system style; see FullRepresentation.qml.
    PlasmaExtras.Menu {
        id: chatMenu

        property string chatId
        property string chatTitle
        property bool favorite

        placement: PlasmaExtras.Menu.BottomPosedLeftAlignedPopup

        PlasmaExtras.MenuItem {
            text: i18n("Rename…")
            icon: "edit-rename"
            onClicked: Qt.callLater(list.renameRequested, chatMenu.chatId)
        }
        PlasmaExtras.MenuItem {
            text: chatMenu.favorite ? i18n("Remove from Favorites") : i18n("Add to Favorites")
            icon: chatMenu.favorite ? "non-starred-symbolic" : "starred-symbolic"
            onClicked: list.plasmoidItem.setFavorite(chatMenu.chatId, !chatMenu.favorite)
        }
        PlasmaExtras.MenuItem {
            text: i18n("Duplicate")
            icon: "edit-copy"
            onClicked: list.plasmoidItem.duplicateChat(chatMenu.chatId)
        }
        PlasmaExtras.MenuItem {
            text: i18n("Export…")
            icon: "document-export"
            onClicked: Qt.callLater(list.exportRequested, chatMenu.chatId, chatMenu.chatTitle)
        }
        PlasmaExtras.MenuItem {
            separator: true
        }
        PlasmaExtras.MenuItem {
            text: i18n("Delete…")
            icon: "edit-delete"
            onClicked: list.deleteRequested(chatMenu.chatId, chatMenu.chatTitle)
        }
    }
}
