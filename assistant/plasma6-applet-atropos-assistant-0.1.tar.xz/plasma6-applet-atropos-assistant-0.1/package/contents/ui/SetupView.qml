// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later
//
// Download Inkling 2 Mini from the widget, or another size of it: pick a
// setup, watch the progress, and start the model when it is done. The
// lightest size is the default; it runs on the most computers.

import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts

import org.kde.coreaddons as KCoreAddons
import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents3

ColumnLayout {
    id: setup

    required property var plasmoidItem
    required property AssistantService service
    // Opened from the menu to change the size; offers a way back.
    property bool closable: false

    signal closed()

    readonly property var status: service.status
    readonly property var progress: status.setup && status.setup.progress ? status.setup.progress : ({})
    readonly property bool downloading: service.setupState === "downloading"
    readonly property string error: status.setup ? status.setup.error : ""
    readonly property var quants: status.quants || []
    readonly property var installed: status.localModel || null
    readonly property string installedQuant: installed ? installed.file.replace(/^Inkling-2-Mini-/, "") : ""

    // Named setups for common computers. "Other size" lists every size.
    readonly property var presets: [
        { quant: "UD-IQ1_S", title: i18nc("model size setup", "Light"),
          note: i18n("For most computers. Answers are rougher than with the bigger sizes.") },
        { quant: "UD-IQ3_XXS", title: i18nc("model size setup", "Balanced"),
          note: i18n("A middle ground for computers with 16 GB of memory.") },
        { quant: "UD-Q4_K_XL", title: i18nc("model size setup", "Quality"),
          note: i18n("Unsloth's recommendation.") },
        { quant: "UD-Q8_K_XL", title: i18nc("model size setup", "Best"),
          note: i18n("Closest to the original model.") },
    ]
    property string chosenQuant: ""
    readonly property string effectiveQuant: chosenQuant || status.defaultQuant || "UD-IQ1_S"
    readonly property var chosen: quants.find(q => q.name === effectiveQuant) || null
    readonly property real needed: (chosen ? chosen.size : 0) + (visionBox.checked ? 639348160 : 0) + 40e6
    readonly property bool roomOnDisk: !status.diskFree || status.diskFree > needed
    readonly property bool alreadyThere: installedQuant === effectiveQuant && !!installed && installed.vision === visionBox.checked

    spacing: Kirigami.Units.largeSpacing

    // Model sizes in decimal GB, as Unsloth and atropos-assistant-setup give them.
    function gb(n) {
        return i18nc("gigabytes", "%1 GB", (n / 1e9).toLocaleString(Qt.locale(), "f", 1));
    }

    function bytes(n) {
        return KCoreAddons.Format.formatByteSize(n, 1);
    }

    function quantInfo(name) {
        return quants.find(q => q.name === name) || null;
    }

    function fitText(q) {
        if (!q) {
            return "";
        }
        return q.fits ? i18nc("@info model size", "Needs about %1 GB of memory, which this computer has.", q.needGiB)
                      : i18nc("@info model size", "Needs about %1 GB of memory, more than this computer may have free.", q.needGiB);
    }

    Item { Layout.fillHeight: true }

    Kirigami.Icon {
        Layout.alignment: Qt.AlignHCenter
        Layout.preferredWidth: Kirigami.Units.iconSizes.huge
        Layout.preferredHeight: Kirigami.Units.iconSizes.huge
        source: setup.downloading ? "download" : "dialog-messages"
    }

    Kirigami.Heading {
        Layout.fillWidth: true
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        level: 2
        text: setup.downloading ? i18n("Downloading Inkling 2 Mini")
            : setup.installed ? i18n("Change the Model Size")
            : i18n("Download Inkling 2 Mini")
    }

    PlasmaComponents3.Label {
        Layout.fillWidth: true
        Layout.leftMargin: Kirigami.Units.gridUnit
        Layout.rightMargin: Kirigami.Units.gridUnit
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        opacity: 0.8
        visible: !setup.downloading
        text: {
            const memory = setup.status.vramGiB > 0
                ? i18n("This computer has %1 GB of memory and %2 GB of graphics memory.", setup.status.memGiB, setup.status.vramGiB)
                : i18n("This computer has %1 GB of memory.", setup.status.memGiB || "?");
            const now = setup.installed
                ? " " + i18nc("model size name, file size", "Now: %1, %2. A new size replaces it.", setup.installedQuant.replace("UD-", ""), setup.gb(setup.installed.size))
                : " " + i18n("It runs on this computer, so nothing you type leaves it.");
            return memory + now;
        }
    }

    // ---------------------------------------------------------------- choose

    QQC2.ButtonGroup {
        id: sizeGroup
    }

    ColumnLayout {
        Layout.alignment: Qt.AlignHCenter
        Layout.maximumWidth: Kirigami.Units.gridUnit * 24
        Layout.leftMargin: Kirigami.Units.gridUnit
        Layout.rightMargin: Kirigami.Units.gridUnit
        visible: !setup.downloading
        spacing: Kirigami.Units.smallSpacing

        Repeater {
            model: setup.presets

            delegate: ColumnLayout {
                id: preset
                required property var modelData
                readonly property var info: setup.quantInfo(modelData.quant)
                Layout.fillWidth: true
                spacing: 0

                PlasmaComponents3.RadioButton {
                    id: presetButton
                    Layout.fillWidth: true
                    QQC2.ButtonGroup.group: sizeGroup
                    checked: setup.effectiveQuant === preset.modelData.quant
                    text: preset.info
                        ? i18nc("setup name, file size", "%1, %2", preset.modelData.title, setup.gb(preset.info.size))
                        : preset.modelData.title
                    onToggled: {
                        if (checked) {
                            setup.chosenQuant = preset.modelData.quant;
                        }
                    }
                }

                PlasmaComponents3.Label {
                    Layout.fillWidth: true
                    leftPadding: presetButton.indicator ? presetButton.indicator.width + presetButton.spacing : 0
                    wrapMode: Text.Wrap
                    font: Kirigami.Theme.smallFont
                    opacity: 0.7
                    text: preset.modelData.note + " " + setup.fitText(preset.info)
                        + (setup.installedQuant === preset.modelData.quant ? " " + i18n("(downloaded)") : "")
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true

            PlasmaComponents3.RadioButton {
                id: otherButton
                QQC2.ButtonGroup.group: sizeGroup
                checked: !setup.presets.some(p => p.quant === setup.effectiveQuant)
                text: i18n("Other size:")
                onToggled: {
                    if (checked) {
                        setup.chosenQuant = otherBox.currentValue || "UD-IQ2_XXS";
                    }
                }
            }

            PlasmaComponents3.ComboBox {
                id: otherBox
                Layout.fillWidth: true
                enabled: otherButton.checked
                textRole: "text"
                valueRole: "value"
                model: setup.quants.map(q => ({
                    value: q.name,
                    text: i18nc("model size name, file size", "%1, %2", q.name.replace("UD-", ""), setup.gb(q.size)),
                }))
                currentIndex: Math.max(0, setup.quants.findIndex(q => q.name === (otherButton.checked ? setup.effectiveQuant : "UD-IQ2_XXS")))
                onActivated: setup.chosenQuant = currentValue
            }
        }

        PlasmaComponents3.Label {
            Layout.fillWidth: true
            leftPadding: otherButton.indicator ? otherButton.indicator.width + otherButton.spacing : 0
            visible: otherButton.checked
            wrapMode: Text.Wrap
            font: Kirigami.Theme.smallFont
            opacity: 0.7
            text: setup.fitText(setup.chosen)
        }

        Item { implicitHeight: Kirigami.Units.smallSpacing }

        PlasmaComponents3.CheckBox {
            id: visionBox
            checked: setup.installed ? setup.installed.vision : true
            text: i18n("Understand images (639 MB more)")
        }

        PlasmaComponents3.CheckBox {
            id: autostartBox
            checked: true
            text: setup.installed ? i18n("Switch to it when the download finishes")
                                  : i18n("Start the model when the download finishes")
        }
    }

    Kirigami.InlineMessage {
        Layout.fillWidth: true
        Layout.leftMargin: Kirigami.Units.gridUnit
        Layout.rightMargin: Kirigami.Units.gridUnit
        visible: !setup.downloading && !setup.roomOnDisk
        type: Kirigami.MessageType.Warning
        text: i18n("This needs %1 of disk space, and %2 is free.", setup.gb(setup.needed), setup.gb(setup.status.diskFree))
    }

    Kirigami.InlineMessage {
        Layout.fillWidth: true
        Layout.leftMargin: Kirigami.Units.gridUnit
        Layout.rightMargin: Kirigami.Units.gridUnit
        visible: !setup.downloading && setup.error.length > 0
        type: Kirigami.MessageType.Error
        text: i18n("The download stopped: %1. Downloading again continues where it stopped.", setup.error)
    }

    RowLayout {
        Layout.alignment: Qt.AlignHCenter
        visible: !setup.downloading
        spacing: Kirigami.Units.largeSpacing

        PlasmaComponents3.Button {
            visible: setup.closable
            icon.name: "go-previous"
            text: i18n("Back")
            onClicked: setup.closed()
        }

        PlasmaComponents3.Button {
            enabled: setup.chosen !== null && setup.roomOnDisk && !setup.alreadyThere
            icon.name: "download"
            text: setup.alreadyThere ? i18n("Already Downloaded")
                : setup.error ? i18n("Download Again")
                : i18n("Download %1", setup.chosen ? setup.gb(setup.needed) : "")
            onClicked: setup.plasmoidItem.download(setup.chosen.name, visionBox.checked, autostartBox.checked)
        }
    }

    // ---------------------------------------------------------------- progress

    PlasmaComponents3.ProgressBar {
        Layout.fillWidth: true
        Layout.leftMargin: Kirigami.Units.gridUnit * 2
        Layout.rightMargin: Kirigami.Units.gridUnit * 2
        visible: setup.downloading
        from: 0
        to: Math.max(1, setup.progress.total || 1)
        value: setup.progress.received || 0
        indeterminate: !setup.progress.total
    }

    PlasmaComponents3.Label {
        Layout.fillWidth: true
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        visible: setup.downloading
        text: {
            const p = setup.progress;
            switch (p.phase) {
            case "verify":
                return i18n("Checking %1…", p.file);
            case "extract":
                return i18n("Unpacking llama.cpp…");
            case "download":
                return i18n("Downloading %1…", p.file);
            default:
                return i18n("Getting ready…");
            }
        }
    }

    PlasmaComponents3.Label {
        Layout.fillWidth: true
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        opacity: 0.7
        font: Kirigami.Theme.smallFont
        visible: setup.downloading && setup.progress.total > 0
        text: {
            const p = setup.progress;
            const parts = [i18nc("downloaded of total", "%1 of %2", setup.bytes(p.received), setup.bytes(p.total))];
            if (p.speed > 0) {
                parts.push(i18nc("download speed", "%1/s", setup.bytes(p.speed)));
                const left = (p.total - p.received) / p.speed * 1000;
                parts.push(i18nc("time left", "%1 left", KCoreAddons.Format.formatSpelloutDuration(left)));
            }
            return parts.join(" · ");
        }
    }

    PlasmaComponents3.Button {
        Layout.alignment: Qt.AlignHCenter
        visible: setup.downloading
        icon.name: "dialog-cancel"
        text: i18n("Cancel")
        onClicked: setup.service.cancelDownload()
    }

    PlasmaComponents3.Label {
        Layout.fillWidth: true
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        opacity: 0.6
        font: Kirigami.Theme.smallFont
        visible: setup.downloading
        text: i18n("You can close this. The download carries on.")
    }

    Item { Layout.fillHeight: true }
}
