// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later
//
// One conversation and its HTTP traffic. No Plasma imports and no
// user-visible strings, so the tests can run it under plain qml.
// Errors are list entries with role "error". Their kind is one of
// "unreachable", "loading", "server", "stream" or "start", and the UI words them.
// Images and files are stored on each entry as JSON text, because a
// ListModel role keeps one type.

import QtQuick

import "../code/protocol.js" as Protocol

QtObject {
    id: session

    property string serverUrl: "http://127.0.0.1:18080"
    property string model: ""
    property string reasoningEffort: "low"
    property string systemPrompt: ""
    property int maxTokens: 8192
    property real temperature: 1.0

    // Poll the server while this is true.
    property bool polling: false
    // Hold a sent message until the server is ready, instead of failing.
    property bool queueUntilReady: false
    // Web search before each new question: how many results (0 is off), and
    // function (query, count, onResults, onError) that does it.
    property int searchCount: 0
    property var searchProvider: null
    // Tools: OpenAI definitions, function (name, args, onOutput) that runs
    // one, and the names that wait for the person's Run before they run.
    property var toolDefinitions: []
    property var toolRunner: null
    property var approvalTools: []
    // Tool rounds per question. The model card warns about loops; after
    // this many, the model is asked without tools and has to answer.
    property int maxToolRounds: 4
    readonly property bool toolsOn: toolDefinitions.length > 0 && toolRunner !== null

    // The saved chat this conversation is, or "" before the first save.
    property string chatId: ""
    property string title: ""
    property bool favorite: false
    property double created: 0

    readonly property ListModel messages: ListModel {}

    readonly property bool busy: _xhr !== null || _queued || searching || _pendingTools > 0
    readonly property bool searching: _searchIndex >= 0
    readonly property bool generating: _xhr !== null
    // unknown, offline, loading, ready, error
    property string serverState: "unknown"
    property string serverModel: ""
    property string serverError: ""
    readonly property string modelName: Protocol.prettyModel(model || serverModel)
    // When the last answer started, and how long it took, in ms.
    property double lastTurnStarted: 0
    property double lastTurnDuration: 0

    // A turn ended: answered, stopped, or failed. The chat is worth saving.
    signal turnFinished()
    // A tool step waits for the person's Run or Don't Run.
    signal approvalNeeded(int index)

    property var _xhr: null
    property var _statusXhr: null
    property var _parser: null
    property int _index: -1
    property bool _queued: false
    property int _searchIndex: -1
    property int _pendingTools: 0
    property int _toolRound: 0
    property bool _aborted: false
    property bool _dirty: false
    property double _thinkStart: 0
    property double _thinkEnd: 0

    onServerUrlChanged: {
        serverModel = "";
        _recheck();
    }
    onModelChanged: _recheck()

    onServerStateChanged: {
        if (serverState === "ready" && _queued) {
            _queued = false;
            _request();
        }
    }

    // Model updates are batched so Markdown is not re-laid out per token.
    property Timer _flushTimer: Timer {
        interval: 60
        repeat: true
        running: session.generating
        onTriggered: session._flush()
    }

    property Timer _pollTimer: Timer {
        interval: session.serverState === "ready" ? 15000 : 2000
        repeat: true
        running: session.polling
        triggeredOnStart: true
        onTriggered: session.checkServer()
    }

    // XMLHttpRequest has no timeout here. Give up on a status check that hangs.
    property Timer _statusTimeout: Timer {
        interval: 5000
        onTriggered: {
            if (session._statusXhr) {
                const xhr = session._statusXhr;
                session._statusXhr = null;
                xhr.abort();
                session._setServer("offline", "");
            }
        }
    }

    // images: [dataUrl]. files: [{ name, text }].
    function send(text, images, files) {
        text = (text || "").trim();
        images = images || [];
        files = files || [];
        if (busy || (!text && images.length === 0 && files.length === 0)) {
            return false;
        }
        _toolRound = 0;
        messages.append(_entry({
            role: "user",
            content: text,
            images: JSON.stringify(images),
            imageCount: images.length,
            files: JSON.stringify(files),
        }));
        if (searchCount > 0 && searchProvider && text) {
            _search(messages.count - 1, text);
        } else {
            _requestWhenReady();
        }
        return true;
    }

    function _requestWhenReady() {
        if (queueUntilReady && serverState !== "ready") {
            _queued = true;
        } else {
            _request();
        }
    }

    function _search(index, query) {
        _searchIndex = index;
        const done = function (sources, note) {
            if (session._searchIndex !== index) {
                return; // stopped meanwhile
            }
            session._searchIndex = -1;
            session.messages.setProperty(index, "sources", JSON.stringify(sources || []));
            session.messages.setProperty(index, "searchNote", note || "");
            session._requestWhenReady();
        };
        searchProvider(query, searchCount, function (results) {
            done(results, results && results.length ? "" : "none");
        }, function (error) {
            done([], error || "failed");
        });
    }

    // Drop the last answer (or error) and ask again.
    function regenerate() {
        if (busy) {
            return;
        }
        while (messages.count > 0 && messages.get(messages.count - 1).role !== "user") {
            messages.remove(messages.count - 1);
        }
        _toolRound = 0;
        if (messages.count > 0) {
            if (queueUntilReady && serverState !== "ready") {
                _queued = true;
            } else {
                _request();
            }
        }
    }

    // Take a user message back for editing: it and everything after it go.
    // Returns { text, images, files } for the input field.
    function editFrom(index) {
        if (busy || index < 0 || index >= messages.count || messages.get(index).role !== "user") {
            return null;
        }
        const m = messages.get(index);
        const taken = {
            text: m.content,
            images: JSON.parse(m.images || "[]"),
            files: JSON.parse(m.files || "[]"),
        };
        while (messages.count > index) {
            messages.remove(messages.count - 1);
        }
        return taken;
    }

    // Run a tool step that waits for approval.
    function approveTool(index) {
        if (index >= 0 && index < messages.count && messages.get(index).toolState === "approval") {
            _runTool(index);
        }
    }

    function denyTool(index) {
        if (index >= 0 && index < messages.count && messages.get(index).toolState === "approval") {
            _toolDone(index, "The user chose not to run this command.", "denied");
        }
    }

    function stop() {
        if (_pendingTools > 0) {
            for (let i = 0; i < messages.count; ++i) {
                const state = messages.get(i).toolState;
                if (state === "approval" || state === "running") {
                    messages.set(i, { toolState: "denied", content: "Stopped before it ran." });
                }
            }
            _pendingTools = 0;
            turnFinished();
            return;
        }
        if (_searchIndex >= 0) {
            _searchIndex = -1;
            turnFinished();
            return;
        }
        if (_queued) {
            _queued = false;
            turnFinished();
            return;
        }
        const xhr = _xhr;
        if (!xhr) {
            return;
        }
        _aborted = true;
        xhr.abort();
        // abort() may or may not report DONE. Finish here if it did not.
        if (_xhr === xhr) {
            _finishTurn("", "");
        }
    }

    // Fail a queued message, for example when the server could not start.
    function failQueued(kind, detail) {
        if (!_queued) {
            return;
        }
        _queued = false;
        messages.append(_entry({ role: "error", kind: kind, content: detail || "" }));
        turnFinished();
    }

    // Start a new, unsaved chat.
    function clear() {
        stop();
        messages.clear();
        chatId = "";
        title = "";
        favorite = false;
        created = 0;
    }

    // The chat in the service's format: arrays, not JSON text.
    function toChat() {
        const list = [];
        for (let i = 0; i < messages.count; ++i) {
            const m = messages.get(i);
            if (m.streaming) {
                continue;
            }
            const out = {
                role: m.role,
                content: m.content,
            };
            if (m.kind) {
                out.kind = m.kind;
            }
            if (m.thinking) {
                out.thinking = m.thinking;
            }
            const images = JSON.parse(m.images || "[]");
            if (images.length) {
                out.images = images;
            }
            if (m.imageCount && !images.length) {
                out.imageCount = m.imageCount;
            }
            const files = JSON.parse(m.files || "[]");
            if (files.length) {
                out.files = files;
            }
            const sources = JSON.parse(m.sources || "[]");
            if (sources.length) {
                out.sources = sources;
            }
            if (m.searchNote) {
                out.searchNote = m.searchNote;
            }
            if (m.role === "tool") {
                out.toolCallId = m.toolCallId;
                out.toolName = m.toolName;
                out.toolArgs = JSON.parse(m.toolArgs || "{}");
                out.toolState = m.toolState;
            }
            const calls = JSON.parse(m.toolCalls || "[]");
            if (calls.length) {
                out.toolCalls = calls;
            }
            if (m.role === "assistant") {
                out.thinkSeconds = m.thinkSeconds;
                out.tokens = m.tokens;
                out.tokensPerSecond = m.tokensPerSecond;
                out.finishReason = m.finishReason;
            }
            list.push(out);
        }
        const now = Date.now();
        const chat = {
            title: title,
            created: created || now,
            updated: now,
            favorite: favorite,
            messages: list,
        };
        if (chatId) {
            chat.id = chatId;
        }
        return chat;
    }

    function loadChat(chat) {
        stop();
        messages.clear();
        chatId = chat.id || "";
        title = chat.title || "";
        favorite = !!chat.favorite;
        created = chat.created || 0;
        for (const m of chat.messages || []) {
            if (!m || ["user", "assistant", "error", "tool"].indexOf(m.role) < 0) {
                continue;
            }
            // A step that never ran when the chat was saved does not run now.
            const unfinished = m.role === "tool" && m.toolState !== "done" && m.toolState !== "denied";
            const images = Array.isArray(m.images) ? m.images : [];
            const files = Array.isArray(m.files) ? m.files : [];
            const sources = Array.isArray(m.sources) ? m.sources : [];
            messages.append(_entry({
                sources: JSON.stringify(sources),
                searchNote: m.searchNote || "",
                toolCalls: JSON.stringify(Array.isArray(m.toolCalls) ? m.toolCalls : []),
                toolCallId: m.toolCallId || "",
                toolName: m.toolName || "",
                toolArgs: JSON.stringify(m.toolArgs || {}),
                toolState: unfinished ? "denied" : (m.toolState || ""),
                role: m.role,
                kind: m.kind || "",
                content: unfinished ? "Not run." : (m.content || ""),
                thinking: m.thinking || "",
                images: JSON.stringify(images),
                imageCount: images.length || m.imageCount || 0,
                files: JSON.stringify(files),
                thinkSeconds: m.thinkSeconds !== undefined ? m.thinkSeconds : -1,
                tokens: m.tokens !== undefined ? m.tokens : -1,
                tokensPerSecond: m.tokensPerSecond !== undefined ? m.tokensPerSecond : -1,
                finishReason: m.finishReason || "",
            }));
        }
    }

    function checkServer() {
        if (_statusXhr) {
            return;
        }
        const xhr = new XMLHttpRequest();
        _statusXhr = xhr;
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE || session._statusXhr !== xhr) {
                return;
            }
            session._statusXhr = null;
            session._statusTimeout.stop();
            if (xhr.status === 0) {
                session._setServer("offline", "");
            } else if (xhr.status === 503) {
                session._setServer("loading", "");
            } else if (xhr.status < 200 || xhr.status >= 300) {
                session._setServer("error", Protocol.errorFromBody(xhr.status, xhr.responseText));
            } else {
                try {
                    session.serverModel = Protocol.parseModels(xhr.responseText, session.model);
                    session._setServer("ready", "");
                } catch (e) {
                    session._setServer("error", String(e));
                }
            }
        };
        xhr.open("GET", Protocol.statusUrl(serverUrl));
        _statusTimeout.restart();
        xhr.send();
    }

    // For the widget's own config when the D-Bus service is not installed:
    // the last 60 entries, without image data.
    function exportHistory() {
        const chat = toChat();
        for (const m of chat.messages) {
            if (m.images) {
                m.imageCount = m.images.length;
                delete m.images;
            }
            if (m.thinking && m.thinking.length > 8000) {
                m.thinking = m.thinking.substring(0, 8000) + "…";
            }
        }
        chat.messages = chat.messages.slice(-60);
        return JSON.stringify(chat.messages);
    }

    function importHistory(json) {
        if (busy || !json) {
            return;
        }
        let list;
        try {
            list = JSON.parse(json);
        } catch (e) {
            return;
        }
        if (Array.isArray(list)) {
            loadChat({ messages: list });
        }
    }

    // Every entry has every role, so ListModel keeps one type per role.
    function _entry(fields) {
        return Object.assign({
            role: "",
            kind: "",
            content: "",
            thinking: "",
            images: "[]",
            imageCount: 0,
            files: "[]",
            sources: "[]",
            searchNote: "",
            toolCalls: "[]",
            toolCallId: "",
            toolName: "",
            toolArgs: "{}",
            toolState: "",
            streaming: false,
            thinkSeconds: -1,
            tokens: -1,
            tokensPerSecond: -1,
            finishReason: "",
        }, fields);
    }

    // The address changed: forget the answer in flight and ask again.
    function _recheck() {
        if (_statusXhr) {
            const xhr = _statusXhr;
            _statusXhr = null;
            _statusTimeout.stop();
            xhr.abort();
        }
        _setServer("unknown", "");
        checkServer();
    }

    function _setServer(state, error) {
        serverError = error;
        serverState = state;
    }

    function _systemPrompt() {
        if (!systemPrompt) {
            return "";
        }
        return systemPrompt + "\n\nToday is " + Qt.formatDate(new Date(), "dddd, d MMMM yyyy") + ".";
    }

    function _history() {
        const out = [];
        for (let i = 0; i < messages.count; ++i) {
            const m = messages.get(i);
            if (m.role === "user") {
                out.push({
                    role: "user",
                    content: m.content,
                    images: JSON.parse(m.images || "[]"),
                    files: JSON.parse(m.files || "[]"),
                    sources: JSON.parse(m.sources || "[]"),
                });
            } else if (m.role === "assistant" && (m.content || m.toolCalls !== "[]")) {
                // Earlier thinking is not sent back. It costs context and the
                // model card warns about long multi-turn conversations.
                out.push({ role: "assistant", content: m.content, toolCalls: JSON.parse(m.toolCalls || "[]") });
            } else if (m.role === "tool" && (m.toolState === "done" || m.toolState === "denied")) {
                out.push({ role: "tool", toolCallId: m.toolCallId, name: m.toolName, content: m.content });
            }
        }
        return out;
    }

    function _request() {
        const body = Protocol.buildRequest({
            systemPrompt: _systemPrompt(),
            model: model,
            reasoningEffort: reasoningEffort,
            maxTokens: maxTokens,
            temperature: temperature,
            tools: toolsOn && _toolRound < maxToolRounds ? toolDefinitions : [],
        }, _history());

        messages.append(_entry({ role: "assistant", streaming: true }));
        _index = messages.count - 1;
        _parser = new Protocol.StreamParser();
        _aborted = false;
        _dirty = false;
        _thinkStart = 0;
        _thinkEnd = 0;
        lastTurnStarted = Date.now();

        const xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            session._onChatState(xhr);
        };
        xhr.open("POST", Protocol.chatUrl(serverUrl));
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.setRequestHeader("Accept", "text/event-stream");
        _xhr = xhr;
        xhr.send(JSON.stringify(body));
    }

    function _onChatState(xhr) {
        if (xhr !== _xhr) {
            return;
        }
        const ok = xhr.status >= 200 && xhr.status < 300;
        if (xhr.readyState === XMLHttpRequest.LOADING) {
            if (ok && _parser.feed(xhr.responseText)) {
                _progress();
            }
            return;
        }
        if (xhr.readyState !== XMLHttpRequest.DONE) {
            return;
        }
        if (_aborted) {
            _finishTurn("", "");
        } else if (ok) {
            if (_parser.finish(xhr.responseText)) {
                _progress();
            }
            _finishTurn(_parser.error ? "stream" : "", _parser.error);
        } else if (xhr.status === 0) {
            _finishTurn("unreachable", "");
        } else {
            const detail = Protocol.errorFromBody(xhr.status, xhr.responseText);
            _finishTurn(xhr.status === 503 ? "loading" : "server", detail);
        }
    }

    function _progress() {
        const now = Date.now();
        if (_parser.thinking && !_thinkStart) {
            _thinkStart = now;
        }
        if (_parser.content && _thinkStart && !_thinkEnd) {
            _thinkEnd = now;
        }
        _dirty = true;
    }

    function _flush() {
        if (!_dirty || _index < 0 || !_parser) {
            return;
        }
        _dirty = false;
        messages.setProperty(_index, "thinking", _parser.thinking);
        messages.setProperty(_index, "content", _parser.content);
    }

    function _finishTurn(kind, detail) {
        _dirty = true;
        _flush();
        const p = _parser;
        const i = _index;
        const calls = !kind && !_aborted && toolsOn ? p.toolCalls.filter(c => c && c.name) : [];
        if (p.content || p.thinking || calls.length) {
            messages.set(i, {
                streaming: false,
                thinkSeconds: _thinkStart ? ((_thinkEnd || Date.now()) - _thinkStart) / 1000 : -1,
                tokens: p.tokens,
                tokensPerSecond: p.tokensPerSecond,
                finishReason: _aborted ? "stopped" : p.finishReason,
            });
        } else {
            messages.remove(i);
        }
        if (kind) {
            messages.append(_entry({ role: "error", kind: kind, content: detail || "" }));
        }
        lastTurnDuration = Date.now() - lastTurnStarted;
        _xhr = null;
        _parser = null;
        _index = -1;
        _aborted = false;
        if (kind === "unreachable" || kind === "loading") {
            checkServer();
        }
        if (calls.length) {
            _startTools(i, calls);
        }
        turnFinished();
    }

    // One step per tool call. Lookups run at once; the rest wait for approval.
    function _startTools(assistantIndex, calls) {
        messages.setProperty(assistantIndex, "toolCalls", JSON.stringify(calls));
        _toolRound++;
        const waiting = [];
        for (const call of calls) {
            let args = {};
            try {
                args = JSON.parse(call.arguments || "{}");
            } catch (e) {
                args = {};
            }
            const needsApproval = approvalTools.indexOf(call.name) >= 0;
            messages.append(_entry({
                role: "tool",
                toolCallId: call.id || ("call_" + messages.count),
                toolName: call.name,
                toolArgs: JSON.stringify(args),
                toolState: needsApproval ? "approval" : "running",
            }));
            _pendingTools++;
            if (needsApproval) {
                waiting.push(messages.count - 1);
            } else {
                _runTool(messages.count - 1);
            }
        }
        for (const index of waiting) {
            approvalNeeded(index);
        }
    }

    function _runTool(index) {
        const m = messages.get(index);
        messages.setProperty(index, "toolState", "running");
        toolRunner(m.toolName, JSON.parse(m.toolArgs || "{}"), function (output) {
            session._toolDone(index, String(output), "done");
        });
    }

    function _toolDone(index, output, state) {
        if (index >= messages.count) {
            return;
        }
        const now = messages.get(index).toolState;
        if (now !== "running" && now !== "approval") {
            return; // stopped meanwhile
        }
        messages.set(index, { content: output, toolState: state });
        _pendingTools--;
        if (_pendingTools === 0) {
            _requestWhenReady();
        }
    }
}
