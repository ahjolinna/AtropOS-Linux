// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later
//
// org.atropos.Assistant1 on the session bus: downloads, the model server,
// saved chats. D-Bus activation starts the service on the first call.
// Without it (the widget alone, talking to some other server) available
// goes false and the widget keeps its chat in its own config.

import QtQuick

import org.kde.plasma.workspace.dbus as DBus

QtObject {
    id: service

    // null until the first call answers.
    property var available: null
    // The last Status(): { setup: { state, error, progress }, server: { state, error },
    // memGiB, recommendedQuant, quants, diskFree }
    property var status: ({})
    property bool polling: false
    property bool fastPolling: false
    // The last error from a call the person started, for a banner.
    property string lastError: ""

    readonly property string setupState: status.setup ? status.setup.state : "unknown"
    readonly property string serverState: status.server ? status.server.state : "unknown"

    property Timer _poll: Timer {
        interval: service.fastPolling ? 1000 : 4000
        repeat: true
        running: service.polling && service.available !== false
        triggeredOnStart: true
        onTriggered: service.refresh()
    }

    function call(member, args, signature, onDone, onError) {
        const message = {
            service: "org.atropos.Assistant",
            path: "/org/atropos/Assistant",
            iface: "org.atropos.Assistant1",
            member: member,
        };
        if (args && args.length) {
            message.arguments = args;
            message.signature = signature;
        }
        DBus.SessionBus.asyncCall(message, function (reply) {
            service.available = true;
            if (onDone) {
                onDone(reply.value);
            }
        }, function (reply) {
            const name = reply.error ? reply.error.name : "";
            const text = reply.error ? reply.error.message : "";
            if (/ServiceUnknown|NameHasNoOwner|UnknownObject|UnknownMethod/.test(name)) {
                service.available = false;
            }
            if (onError) {
                onError(text || name);
            } else {
                service.lastError = text || name;
            }
        });
    }

    // Parse a JSON reply; "" and bad JSON give fallback.
    function parse(text, fallback) {
        if (!text) {
            return fallback;
        }
        try {
            return JSON.parse(text);
        } catch (e) {
            return fallback;
        }
    }

    function refresh() {
        call("Status", [], "", function (text) {
            service.status = service.parse(text, {});
        }, function () {});
    }

    function download(quant, vision, autostart) {
        call("Download", [quant, vision, autostart], "(sbb)", refresh);
    }

    function cancelDownload() {
        call("CancelDownload", [], "", refresh);
    }

    function startServer(onError) {
        call("StartServer", [], "", refresh, onError);
    }

    function stopServer() {
        call("StopServer", [], "", refresh);
    }
}
