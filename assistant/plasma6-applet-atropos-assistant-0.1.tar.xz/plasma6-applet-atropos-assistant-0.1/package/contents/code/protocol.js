// SPDX-FileCopyrightText: 2026 Alexander Waldemar Ahjolinna
// SPDX-License-Identifier: GPL-2.0-or-later
//
// Request building and stream parsing for OpenAI-compatible chat servers:
// POST /v1/chat/completions with server-sent events. That is llama-server,
// LM Studio and vLLM. llama-server's Inkling handler returns the model's
// thinking in delta.reasoning_content. Nothing here touches QML, so the
// tests can load it on its own.

.pragma library

var EFFORTS = ["minimal", "low", "medium", "high", "xhigh", "max"];

function trimSlash(url) {
    return String(url).replace(/\/+$/, "");
}

function chatUrl(base) {
    return trimSlash(base) + "/v1/chat/completions";
}

function statusUrl(base) {
    return trimSlash(base) + "/v1/models";
}

function prettyModel(id) {
    if (!id) {
        return "";
    }
    if (/inkling[-_ ]?2[-_ ]?mini/i.test(id)) {
        return "Inkling 2 Mini";
    }
    return String(id).replace(/\.gguf$/i, "");
}

function errorText(error) {
    if (typeof error === "string") {
        return error;
    }
    if (error && error.message) {
        return String(error.message);
    }
    return JSON.stringify(error);
}

function errorFromBody(status, body) {
    try {
        var o = JSON.parse(body);
        if (o && o.error) {
            return errorText(o.error);
        }
    } catch (e) {
        // Not JSON. Fall through to the raw text.
    }
    body = String(body || "").trim();
    return body ? body.substring(0, 400) : "HTTP " + status;
}

// Attached text files go in front of the question, each in a fence.
function withFiles(content, files) {
    if (!files || !files.length) {
        return content || "";
    }
    var parts = files.map(function (f) {
        var fence = f.text.indexOf("```") >= 0 ? "~~~~" : "```";
        return "File: " + f.name + "\n" + fence + "\n" + f.text.replace(/\n$/, "") + "\n" + fence;
    });
    if (content) {
        parts.push(content);
    }
    return parts.join("\n\n");
}

// Web search results go right before the question, numbered so the model
// can cite them.
function withSources(content, sources) {
    if (!sources || !sources.length) {
        return content || "";
    }
    var lines = ["Web search results from DuckDuckGo:"];
    for (var i = 0; i < sources.length; ++i) {
        var s = sources[i];
        lines.push("[" + (i + 1) + "] " + s.title + " (" + s.url + ")" + (s.snippet ? "\n" + s.snippet : ""));
    }
    lines.push("", "Use these results where they help and cite them as [1], [2] and so on.");
    if (content) {
        lines.push("", content);
    }
    return lines.join("\n");
}

// Split Markdown into prose and fenced code, so code blocks can have their
// own copy button. An unclosed fence (still streaming) counts as code.
// Returns [{ code: bool, lang: string, text: string }].
function splitMarkdown(md) {
    var lines = String(md || "").split("\n");
    var out = [];
    var buf = [];
    var fence = "";
    var lang = "";
    function flush(code) {
        var text = buf.join("\n");
        if (code || text.trim() !== "") {
            out.push({ code: code, lang: lang, text: code ? text : text.replace(/^\n+|\n+$/g, "") });
        }
        buf = [];
    }
    for (var i = 0; i < lines.length; ++i) {
        var line = lines[i];
        var m = /^\s{0,3}(`{3,}|~{3,})\s*([^`\s]*)/.exec(line);
        if (!fence && m) {
            flush(false);
            fence = m[1];
            lang = m[2] || "";
            continue;
        }
        if (fence && m && m[1].charAt(0) === fence.charAt(0) && m[1].length >= fence.length && line.trim() === m[1]) {
            flush(true);
            fence = "";
            lang = "";
            continue;
        }
        buf.push(line);
    }
    flush(fence !== "");
    return out;
}

// history: [{ role: "user", content, images: [dataUrl], files: [{ name, text }], sources: [{ title, url, snippet }] }
//           | { role: "assistant", content, toolCalls: [{ id, name, arguments }] }
//           | { role: "tool", toolCallId, name, content }]
// opts: { systemPrompt, model, reasoningEffort, maxTokens, temperature, tools: [OpenAI tool definitions] }
function buildRequest(opts, history) {
    var messages = [];
    if (opts.systemPrompt) {
        messages.push({ role: "system", content: opts.systemPrompt });
    }
    for (var i = 0; i < history.length; ++i) {
        var m = history[i];
        if (m.role === "tool") {
            messages.push({ role: "tool", tool_call_id: m.toolCallId, name: m.name, content: m.content || "" });
            continue;
        }
        if (m.role === "assistant" && m.toolCalls && m.toolCalls.length) {
            messages.push({
                role: "assistant",
                content: m.content || "",
                tool_calls: m.toolCalls.map(function (c) {
                    return { id: c.id, type: "function", function: { name: c.name, arguments: c.arguments || "{}" } };
                }),
            });
            continue;
        }
        var images = m.images || [];
        m = { role: m.role, content: withFiles(withSources(m.content, m.sources), m.files), images: images };
        if (images.length) {
            var parts = images.map(function (url) {
                return { type: "image_url", image_url: { url: url } };
            });
            if (m.content) {
                parts.push({ type: "text", text: m.content });
            }
            messages.push({ role: m.role, content: parts });
        } else {
            messages.push({ role: m.role, content: m.content || "" });
        }
    }

    var body = {
        messages: messages,
        stream: true,
        stream_options: { include_usage: true },
        max_tokens: opts.maxTokens,
        temperature: opts.temperature,
        top_p: 1.0,
        // llama-server reads the top-level field. vLLM passes
        // chat_template_kwargs to the template. Both carry the same value.
        reasoning_effort: opts.reasoningEffort,
        chat_template_kwargs: { reasoning_effort: opts.reasoningEffort },
    };
    if (opts.model) {
        body.model = opts.model;
    }
    if (opts.tools && opts.tools.length) {
        body.tools = opts.tools;
    }
    return body;
}

// The model a /v1/models answer names. wantedModel wins. Throws on bad JSON.
function parseModels(body, wantedModel) {
    var o = JSON.parse(body);
    if (wantedModel) {
        return wantedModel;
    }
    var data = o.data || o.models || [];
    return data.length ? String(data[0].id || data[0].name || data[0].model || "") : "";
}

// Feed it the whole response text each time more arrives. It keeps its
// own offset and only reads complete lines.
function StreamParser() {
    this.offset = 0;
    // [{ id, name, arguments }]; arguments arrive as JSON text in pieces.
    this.toolCalls = [];
    this.content = "";
    this.thinking = "";
    this.done = false;
    this.error = "";
    this.finishReason = "";
    this.tokens = -1;
    this.tokensPerSecond = -1;
}

// Returns true when content or thinking grew, or an error arrived.
StreamParser.prototype.feed = function (text) {
    var changed = false;
    var nl;
    while ((nl = text.indexOf("\n", this.offset)) !== -1) {
        var line = text.substring(this.offset, nl).trim();
        this.offset = nl + 1;
        if (line && this._line(line)) {
            changed = true;
        }
    }
    return changed;
};

// Call once the response is complete. Reads a last line with no newline.
StreamParser.prototype.finish = function (text) {
    var changed = this.feed(text);
    if (this.offset < text.length) {
        var line = text.substring(this.offset).trim();
        this.offset = text.length;
        if (line && this._line(line)) {
            changed = true;
        }
    }
    return changed;
};

StreamParser.prototype._line = function (line) {
    // SSE: skip event:, id:, retry: and ": comment" lines.
    if (line.indexOf("data:") !== 0) {
        return false;
    }
    var data = line.substring(5).trim();
    if (data === "[DONE]") {
        this.done = true;
        return false;
    }
    var obj;
    try {
        obj = JSON.parse(data);
    } catch (e) {
        return false;
    }
    if (obj.error) {
        this.error = errorText(obj.error);
        return true;
    }
    return this._chunk(obj);
};

StreamParser.prototype._chunk = function (obj) {
    var changed = false;
    var choice = obj.choices && obj.choices.length ? obj.choices[0] : null;
    if (choice) {
        var delta = choice.delta || choice.message || {};
        var reasoning = delta.reasoning_content || delta.reasoning || "";
        if (reasoning) {
            this.thinking += reasoning;
            changed = true;
        }
        if (delta.content) {
            this.content += delta.content;
            changed = true;
        }
        var calls = delta.tool_calls || [];
        for (var i = 0; i < calls.length; ++i) {
            var c = calls[i];
            var at = c.index !== undefined ? c.index : this.toolCalls.length;
            var call = this.toolCalls[at] || (this.toolCalls[at] = { id: "", name: "", arguments: "" });
            if (c.id) {
                call.id = c.id;
            }
            if (c.function && c.function.name) {
                call.name += c.function.name;
            }
            if (c.function && c.function.arguments) {
                call.arguments += c.function.arguments;
            }
            changed = true;
        }
        if (choice.finish_reason) {
            this.finishReason = choice.finish_reason;
        }
    }
    if (obj.timings && obj.timings.predicted_n !== undefined) {
        this.tokens = obj.timings.predicted_n;
        this.tokensPerSecond = obj.timings.predicted_per_second;
    } else if (obj.usage && obj.usage.completion_tokens !== undefined && this.tokens < 0) {
        this.tokens = obj.usage.completion_tokens;
    }
    return changed;
};
